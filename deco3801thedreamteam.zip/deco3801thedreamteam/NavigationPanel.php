<nav id="mainNav">
    <h2>Actions</h2>
    <a href="?action=">View Paper Levels</a>
    <a href="?action=ViewPath">View Printer Path</a>
    <a disabled=disabled href="?action=ForwardPrediction">Predict Upcoming Paper Levels</a>
</nav>