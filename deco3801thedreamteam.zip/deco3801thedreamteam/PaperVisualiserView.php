<section id="contentPanelWrapper">
    <div id="pageContentPanel">
        <div style="display: none" class="loader" ><span><h2>Loading</h2><img src="img/loader.gif" /></span></div>
        <nav>
          <div id="timeButtonsContainer">
            <a <?= $action == "" ? $selectedTab : "" ?> id="selectCurrentLevels" href="?action=">Current Levels</a><a <?= $action == "PreviousLevels" ? $selectedTab : "" ?> id="selectPreviousLevels
            " href="?action=PreviousLevels" >Previous Levels</a><a disabled=disabled href="?action=ForwardPrediction" id="selectUpcomingLevels">Upcoming Levels</a>
        </div></nav>
        <div id="printerOverviewOverlay">
            <button>X</button>
            <div id="printerMapContainer"></div><div id="printerOverview">
                <h2>Printer ID: </h2>
                <h2>Location: </h2>
                <h2>Paper Level: </h2>
                <a href="">View In Pathfinder</a>
            </div>
            <hr />
            <h3>Paper Usage Over Time</h3>
            <canvas id="currentLineChart"></canvas>
        </div>
        <div id="pagePurposeWrapper">
            <div id="timebarContainer">
                <h3>Results for: </h3>
                <h3 class="<?= ($action == ""  ? "disabled" : ""); ?>" id="dateDisplay"></h3>
                <h3 class="pickerButton <?= ($action == ""  ? "disabled" : ""); ?>" id="dateButton"><input type="text" id="datePicker" data-field="datetime" data-format="yyyy-MM-dd hh:mm:ss" value="<?= date("Y-m-d H:i:s", strtotime($_SESSION["currentDate"])); ?>" readonly /></h3>
            </div>
            <div class="rightContentPanel <?= ($action != "") ? 'style="border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;"' : ''; ?>" id="printerInfoTableContainer">
                <table>
                    <thead><tr><th>Printer ID</th><th>Location</th><th>Paper Level</th><th>Trend</th></tr></thead>
                    <tbody>
                    </tbody>
                </table>
            <script type="text/JavaScript">

                var currentDate = "<?= $_SESSION["currentDate"]; ?>";
                var printerData = [
            <?php
                $paperVisualiserModel = new PaperVisualiserModel();
                if($action != "ForwardPrediction") { // get most recent data
                    $paperVisualiserModel->setDate($_SESSION["currentDate"]);
                    $printers = $paperVisualiserModel->getTodaysPrintersWithTrend();
                }
                if(count($printers) <= 1) {
                    
                } else {
                    $previousPrinter = $printers[0];
                    $lineValues = "";
                    $timeStamps = "";
                    $first = true;
                    $printerContainer = "{";
                    $printerData = "[";
                    
                    foreach($printers as $printer) {
                        if($printer->Printer !== $previousPrinter->Printer) {
                            
                            $printerContainer .= "id: $previousPrinter->Printer, location: \"$previousPrinter->Location\", lat: $previousPrinter->latitude, lng: $previousPrinter->longitude,   printerData: " . substr($printerData, 0, -2) . "], " .
                                "timeStamps: [" . $timeStamps . "\"], " .
                                "lineValues: [" . $lineValues . "]" .
                            "}, {";
                            $timeStamps = "";
                            $lineValues = "";
                            $printerData = "[";
                            $previousPrinter = $printer;
                        }
                        // Generate Data for the Chart
                        $timeStamps .= '"' . (($timeStamps == "" ? "" : ", \"") . $printer->Stamp);
                        $lineValues .= ($lineValues == "" ? "" : ", ") . $printer->Paper;

                        $printerData .= $printer->toJSON() . ", ";
                    }
                    $printerContainer .= "id: $printer->Printer, location: \"$printer->Location\", lat: $printer->latitude, lng: $printer->longitude,   printerData: " . substr($printerData, 0, -2) . "], " .
                                "timeStamps: [" . $timeStamps . "\"], " .
                                "lineValues: [" . $lineValues . "]" .
                            "}";
                    echo $printerContainer;
                }
            ?>];
            var jsController = new PaperVisualisation(printerData);
            jsController.redrawCharts();
            </script>
        </div>

        <script type="text/JavaScript">
            function initMap() {
                
            }
        </script>
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIhXGVQ9UIXHBW2bwJL8oJkEuwRWQUZGU&callback=initMap"></script>
        </div>
    </div>
</section>
