<?php
    $optimalPathModel = new OptimalPathModel();

    $nodes = $optimalPathModel->getTodaysNodes();

    $nodeSelectList = "";
    $nodeList = "";

    $weightedEdges = implode(",", $optimalPathModel->getWeightedEdges());
    foreach($nodes as $n) {
        $nodeSelectList .= "<option value=\"$n\"" . (isset($_GET["startingNode"]) && "$n" === $_GET["startingNode"] ? "selected" : ""). ">$n</option>";
        $nodeList .= $n->toNode() . ", ";
    }
    $nodeList = substr($nodeList, 0, -2);
?>
<section id="contentPanelWrapper">
    <div id="pageContentPanel">
        <div style="display: none" class="loader" ><span><h2>Loading</h2><img src="img/loader.gif" /></span></div>
        <nav><div id="timeButtonsContainer">
            <a <?= $action == "ViewPath" ? $selectedTab : "" ?> id="selectCurrentLevels" href="?action=ViewPath">Current<br>Paths</a><a <?= $action == "ViewPreviousPaths" ? $selectedTab : "" ?> href="?action=ViewPreviousPaths" id="selectPreviousLevels
            ">Previous<br>Paths</a><a disabled=disabled href="?action=OptimalForwardPrediction" id="selectUpcomingLevels">Upcoming<br>Paths</a>
        </div></nav>
        <div id="pagePurposeWrapper">
            <div id="timebarContainer">
                <div id="timeControls">
                    <h3>Results for: </h3>
                    <h3 class="<?= ($action == "ViewPath"  ? "disabled" : ""); ?>" id="dateDisplay"></h3>
                    <h3 class="pickerButton <?= ($action == "ViewPath"  ? "disabled" : ""); ?>" id="dateButton"><input type="text" id="datePicker" data-field="datetime" data-format="yyyy-MM-dd hh:mm:ss" value="<?= date("Y-m-d H:i:s", strtotime($_SESSION["currentDate"])); ?>" readonly /></h3>
                </div><form class="formSelections">
	                 
                    <label for="formStartNode">Starting Location </label>
                    <select name="startNode" id="formStartNode">
                        <?= $nodeSelectList ?>
                    </select>
                </form>
            </div>
            <div class="leftContentPanel">
              <div id="scrollCover"></div>
              <ul id="nodesToVisit">
                <div class="topShadow"></div>
                <div class="buttonWrapper">
                </div>
                <div class="bottomShadow">
                </div>
              </ul>
            </div><div class="rightContentPanel" <?= ($action != "") ? 'style="border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;"' : ''; ?>>
                <div id="map"></div>
            </div>
        </div>
        <script type="text/JavaScript">
            var nodes = {<?= $nodeList; ?>};
            var weightedEdges = [<?= $weightedEdges; ?>];

            var jsController = new OptimalPathFinder(nodes, weightedEdges, "formStartNode");

            function initMap() {
                jsController.initMap();
                jsController.startOptimalPath(jsController.selectBox.value);
            }
        </script>
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIhXGVQ9UIXHBW2bwJL8oJkEuwRWQUZGU&callback=initMap"></script>
    </div>
</section>
