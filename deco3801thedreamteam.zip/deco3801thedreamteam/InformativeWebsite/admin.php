<!DOCTYPE html>
<?php
require_once "uq/auth.php";
auth_require();

include 'admin/Stastics.php';
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Paper Factory - Administrator Page</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<!-- Amchart -->
	<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
	<script src="https://www.amcharts.com/lib/3/serial.js"></script>
	<script src="https://www.amcharts.com/lib/3/pie.js"></script>
	<script src="https://www.amcharts.com/lib/3/xy.js"></script>
	<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
	<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
	<!-- Data Table -->
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js"></script>
	<script src="js/purchaseStastics.js"></script>
	<script src="js/surveyStastics.js"></script>
</head>

<body>
     <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <!-- The main top bar navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="index.php">Paper Factory</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php#home">Home</a>
                    </li>
                    <li>
                        <a href="index.php#about">About</a>
                    </li>
                    <li>
                        <a href="purchase.php">Purchase</a>
                    </li>
                    <li>
                        <a href="admin.php">Administrator Login</a>
                    </li>
                    <li>
                        <a href="index.php#support">Support</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>



    <a name="home"></a>
    <div class="intro-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h1>Administration Page</h1>
                        <!--
                        <hr class="intro-divider">
                        <ul class="list-inline intro-social-buttons">
                            <li>
                                <a href="#" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-user"></i> <span class="network-name">Login</span></a>
                            </li>
                          
                        </ul>-->
                    </div>
                </div>
            </div>

        </div>
    </div>


<a  name="about"></a>
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Statistics</h2>
                
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
	                <div class="clearfix"></div>
	                    <ul id="admin_floatMenu" style="z-index: 100;position: fixed;background: white;" class="nav nav-tabs">
							<li role="presentation"><a href="#home">Top</a></li>
							<li role="presentation"><a href="#adminPurchase">Purchase</a></li>
							<li role="presentation"><a href="#adminSurvey">Survey</a></li>
						</ul>
                </div>
            </div>
             <!------------------------------ Purchase --------------------------------------------------> 
				  <div class="jumbotron" id="adminPurchase">
					<h1>Purchase</h1>
				   	<p>Total Purchase:&nbsp;&nbsp;<?php echo($getTotalPurchase);?></p>
                    <p>Average time to decide to purchase:&nbsp;&nbsp;<?php echo($getAverageDuration);?> Seconds</p>
				  </div>
				  <!-- Purchase Position -->
				   <div class="panel panel-default" style="height: 100%;">
					   <div class="panel-heading">Purchase Position</div>
					   <div class="panel-body">
						  <div class="row">
				                <div class="col-lg-5 col-sm-6">
					                <img src="img/purchaseAB.png" style="height: 100%; width: 100%;" width="300" height="180" alt="Purchase Icon Position">
				                    <img src="img/purchaseCD.png" style="height: 100%; width: 100%;" width="300" height="180" alt="Purchase Icon Position">  
				                </div>
				                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
									<div id="purchasePos" style="width:100%;height: 400px;"></div>
				                </div>
		            	  </div>
					   </div>
				   </div>
            	   <!-- Access Time -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">Purchase Time</div>
	            	    <div class="panel-body">
				            <div id="purchaseTime" style="width:100%;height:400px;"></div> 
				            <div class="clearfix">
					        </div>
	            	    </div>
            	    </div>
            <!------------------------------ Survey --------------------------------------------------> 
				  <div class="jumbotron" id="adminSurvey">
					<h1>Survey</h1>
				   	<p>Total Survey:&nbsp;&nbsp;<?php echo($getTotalSurvey);?></p>
                    <p>Average Survey Mark<small>(Full mark:15)</small>:&nbsp;&nbsp;<?php echo($getAverageMark);?> /15</p>
				  </div>
				  <!-- Q1 -->
				   <div class="panel panel-default" style="height: 100%;">
					   <div class="panel-heading">How nice is our user interface? </div>
					   <div class="panel-body">
						  <div class="row">  
								<div id="Q1_g" style="width:100%;height: 400px; margin-left: auto;margin-right: auto;"></div>
		            	  </div>
					   </div>
				   </div>
            	   <!-- Q2 -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">How useful does PaperFactory! seem for you?</div>
	            	    <div class="panel-body">
				            <div class="row">
								<div id="Q2_g" style="width:100%;height:400px; margin-left: auto;margin-right: auto;"></div>   
				            </div>
	            	    </div>
            	    </div>
            	    <!-- Q3 -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">How likely are you to recommend PaperFactory! to someone?</div>
	            	    <div class="panel-body">
				            <div class="row">
								<div id="Q3_g" style="width:100%;height:400px;  margin-left: auto;margin-right: auto;"></div>   
				            </div>
	            	    </div>
            	    </div>
            	    <!-- Q4 -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">How did you hear about PaperFactory!?</div>
	            	    <div class="panel-body">
				            <div class="row">
								<div id="Q4_g" style="width:100%;height:400px; overflow-y: scroll;"></div> 
				            </div>
	            	    </div>
            	    </div>
            	    <!-- Q5 -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">Do you have any suggestion as to how we can make PaperFactory! better?</div>
	            	    <div class="panel-body">
				            <div class="row">
								  <div id="Q5_g" style="width:100%;height:400px; overflow-y: scroll;"></div> 
				            </div>
	            	    </div>
            	    </div>
            	    <!-- Q6 -->
            	    
            	    <!-- Q7 -->
            	    <div class="panel panel-default" style="height: 100%;">
	            	    <div class="panel-heading">would you like us to send you other emails regarding this product?</div>
	            	    <div class="panel-body">
				            <div class="row">
								<div id="Q7_g" style="width:100%;height:400px; overflow-y: scroll;"></div>   
				            </div>
	            	    </div>
            	    </div>
			</div>
            

    </div>
    <!-- /.content-section-a -->
 <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="index.php#about">About</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="purchase.php">Purchase</a>
                        </li>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="admin.php">Administrator Login</a>
                        </li>


                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; dReam Team 2016. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>

 <!-- jQuery -->
    <script src="js/jquery.js"></script>

 <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>