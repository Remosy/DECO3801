<?php

require_once 'AdminDB.php';
require_once 'AdminManager.php';
//echo($timeStamp.$button.$duration);

$AdminDB = new AdminManager();
$getTotalPurchase = json_encode($AdminDB -> getTotalPurchase()[0][0]); 
$getAverageDuration = json_encode(ceil($AdminDB -> getAverageDuration()[0][0]));
$getPurchasePos = $AdminDB -> getPurchasePos();
$getPurchaseTime = $AdminDB -> getPurchaseTime();
$list_pos=array();
$list_time=array();
foreach($getPurchasePos as $num){
		array_push($list_pos, array("Position"=>$num[0],"Value"=>$num[1]));
}
foreach($getPurchaseTime as $timeStamp){
		array_push($list_time, array("Time"=>$timeStamp["0"],"Value"=>$timeStamp["1"]));
}

if($_GET["name"]=="purchasePos"){
	echo json_encode($list_pos);
}elseif($_GET["name"]=="purchaseTime"){
	echo json_encode($list_time);
}

$getTotalSurvey =json_encode($AdminDB -> getTotalSurvey()[0][0]);
$getAverageMark = json_encode(floor($AdminDB -> getAverageMarks()[0][0]));
$getQ1 = $AdminDB -> getQ1();
$getQ2 = $AdminDB -> getQ2();
$getQ3 = $AdminDB -> getQ3();
$getQ4 = $AdminDB -> getQ4();
$getQ5 = $AdminDB -> getQ5();
$getQ7 = $AdminDB -> getQ7();
$list_q1=array();
$list_q2=array();
$list_q3=array();
$list_q4=array();
$list_q5=array();
$list_q6=array();
$list_q7=array();
foreach($getQ1 as $q1){
		array_push($list_q1, array("Mark"=>$q1[0],"Value"=>$q1[1]));
}
foreach($getQ2 as $q2){
		array_push($list_q2, array("Mark"=>$q2[0],"Value"=>$q2[1]));
}
foreach($getQ3 as $q3){
		array_push($list_q3, array("Mark"=>$q3[0],"Value"=>$q3[1]));
}
foreach($getQ4 as $q4){
		array_push($list_q4, array("Time"=>$q4["0"],"Content"=>$q4["1"]));
}

foreach($getQ5 as $q5){
		array_push($list_q5, array("Time"=>$q5["0"],"Content"=>$q5["1"]));
}
foreach($getQ7 as $q7){
		array_push($list_q7, array("Email"=>$q7["0"],"Content"=>$q7["1"]));
}

switch ($_GET["name"]) {
    case "Q1":
        echo json_encode($list_q1);
        break;
    case "Q2":
        echo json_encode($list_q2);
        break;
    case "Q3":
        echo json_encode($list_q3);
        break;
    case "Q4":
        echo json_encode($list_q4);
        break;
    case "Q5":
        echo json_encode($list_q5);
        break;
    case "Q7":
        echo json_encode($list_q7);
        break;
}


?>