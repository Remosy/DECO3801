<?php    
require_once 'AdminDB.php';
require_once 'AdminManager.php';
$timeStamp = $_GET["timeStamp"];
$button = $_GET["button"];
$duration = $_GET["duration"];
//echo($timeStamp.$button.$duration);

$AdminDB = new AdminManager();
$AdminDB -> addPurchaseStatus($timeStamp,$button,$duration);
if($AdminDB==true){echo("yes");}else{
	echo("You have not finished this purchase");
}
?>