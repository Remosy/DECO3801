<?php
class AdminDB {
    protected $connection;
    
    public function __construct() {
       try 
        { $this->connection = $this->getConnection();
        }
       catch (PDOException $e) 
        {
            $this->connection = null;
            die($e->getMessage());
        }
    }
    
    /*
    *   Gets the MYSQL connection and sets some attributes to make it perform better.
    */
    private function getConnection() {
        
        $dbHost = "localhost";
        $dbName = "InfomativeWebsite_admin";
        //$dbUser = "root";
        //$dbPassword = "root";
        $dbUser = "default_user";
        $dbPassword = "aKmfWXUhyc3HtCB3";
        $connection = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPassword);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $connection->setAttribute(PDO::ATTR_ORACLE_NULLS, PDO::NULL_TO_STRING);
        $connection->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, FALSE);
        $connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);
        $connection->setAttribute(PDO::ATTR_STRINGIFY_FETCHES, FALSE);
        return $connection;
    }
    
}

?>