<?php
require_once 'AdminDB.php';
require_once 'AdminManager.php';
$Q1= $_GET["Q1"];
$Q2= $_GET["Q2"];
$Q3= $_GET["Q3"];
$Q4= $_GET["Q4"];
$Q5= $_GET["Q5"];
$Q6= $_GET["Q6"];
$Q7= $_GET["Q7"];

$AdminDB = new AdminManager();
$timestamp = date('Y-m-d G:i:s');
$AdminDB -> addSurvey($timestamp,$Q1,$Q2,$Q3,$Q4,$Q5,$Q6,$Q7);
if($AdminDB==true){echo("Thank you! You have finished survey");}else{
	echo("Try Again later");
}

?>