<?php

/*
*   A Class to manage Admin Page Stastics
*/
class AdminManager extends AdminDB {
    
   
    public function __construct() {
        parent::__construct();
    }
    
    /*
    *   Returns an number of total of purchase.
    */
    public function getTotalPurchase() {
        $stmt = $this->connection->prepare('
            SELECT COUNT(IdPurchase)
            FROM Purchase');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an number of total of purchase.
    */
    public function getAverageDuration() {
        $stmt = $this->connection->prepare('
            SELECT AVG(Purchase_SessionDuration) 
            FROM Purchase');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of amouunt of each Purchase position(A,B,C,D)
    */
    public function getPurchasePos() {
        $stmt = $this->connection->prepare('
            SELECT distinct Purchase_Button, count(Purchase_Button)
            AS CountOf
            FROM Purchase
            GROUP BY Purchase_Button');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of purchase timestamps
    */
    public function getPurchaseTime() {
        $stmt = $this->connection->prepare('
            SELECT Purchase_TimeStamp,1
            FROM Purchase');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns  an number of total Survey
    */
    public function getTotalSurvey() {
        $stmt = $this->connection->prepare('
           SELECT COUNT(id) 
           FROM Survey');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an number of total of purchase.
    */
    public function getAverageMarks() {
        $stmt = $this->connection->prepare('
            SELECT (AVG(`Q1`)+AVG(`Q2`)+AVG(`Q3`)) 
            FROM Survey');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of Q1.
    */
    public function getQ1() {
        $stmt = $this->connection->prepare('
            SELECT distinct Q1, count(`Q1`) 
            AS CountOf 
            FROM Survey GROUP BY Q1');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of Q2.
    */
    public function getQ2() {
        $stmt = $this->connection->prepare('
            SELECT distinct Q2, count(`Q2`) 
            AS CountOf 
            FROM Survey GROUP BY Q2');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of Q3.
    */
    public function getQ3() {
        $stmt = $this->connection->prepare('
            SELECT distinct Q3, count(`Q3`) 
            AS CountOf 
            FROM Survey GROUP BY Q3');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of Q4.
    */
    public function getQ4() {
        $stmt = $this->connection->prepare('
            SELECT `timeStamp`,`Q4`
            FROM `Survey`');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an array of Q5.
    */
    public function getQ5() {
        $stmt = $this->connection->prepare('
            SELECT `timeStamp`,`Q5`
            FROM `Survey`');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    
    /*
    *   Returns an array of Q7.
    */
    public function getQ7() {
        $stmt = $this->connection->prepare('
            SELECT `Q6`,`Q7`
            FROM `Survey`');
        $stmt->execute();
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        return ($row === false ? null : $row);
    }
    
    public function addPurchaseStatus($timeStamp,$button,$duration) {
	        
        $stmt = $this->connection->prepare('
            INSERT INTO Purchase (IdPurchase, Purchase_TimeStamp, Purchase_Button, Purchase_SessionDuration)
            VALUES(:id, :Purchase_TimeStamp, :Purchase_Button, :Purchase_SessionDuration)');
            
        $result = $stmt->execute(array(
            ':id' => '', 
            ':Purchase_TimeStamp' => $timeStamp,
            ':Purchase_Button' => $button,
            ':Purchase_SessionDuration' => $duration
        ));
      
        return true;
        }   
        
    public function addSurvey($timeStamp,$q1,$q2,$q3,$q4,$q5,$q6,$q7) {
	        
        $stmt = $this->connection->prepare('
            INSERT INTO `Survey`(`id`, `timeStamp`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`, `Q6`, `Q7`) 
            VALUES (:id,:timeStamp,:q1,:q2,:q3,:q4,:q5,:q6,:q7)');
        $result = $stmt->execute(array(
            ':id' => '', 
            ':timeStamp' => $timeStamp,
            ':q1' => $q1,
            ':q2' => $q2,
            ':q3' => $q3,
            ':q4' => $q4,
            ':q5' => $q5,
            ':q6' => $q6,
            ':q7' => $q7
        ));
      
        return true;
        }  
}

?>