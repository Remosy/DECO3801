$( document ).ready(function() {
	var offset = 10* 3600 *1000;//GMT
	var time = new Date().getTime() + offset;
	var timeStamp=new Date(time).toISOString().slice(0, 19).replace('T', ' ');
	timeStamp = String(timeStamp);
	var buttonClicked = "";
	//Set Cookies
	document.cookie ="paperFactoryTimeStamp = "+timeStamp;
	
	$("#purchase_A").click(function(){
		buttonClicked = this.getAttribute("id");
		purchase();
    });
    
    $("#purchase_B").click(function(){
		buttonClicked = this.getAttribute("id");
		purchase();
    });
    
    $("#purchase_C").click(function(){
		buttonClicked = this.getAttribute("id");
		purchase();
    });
    
    $("#purchase_D").click(function(){
		buttonClicked = this.getAttribute("id");
		purchase();
    });
    
    function purchase(){
	    var timeInterval = new Date().getTime() + offset - time;
		var duration = Math.ceil(timeInterval/1000);
	    $.ajax({
		  method: "Get",
		  url: "admin/Session.php",
		  data: {
			  timeStamp:timeStamp,
			  button:buttonClicked,
			  duration:duration
		  }
		}).done(function(reply) {
			if(reply=="yes")$(location).attr("href", 'purchase.php');
		});
    }
	
  	
});