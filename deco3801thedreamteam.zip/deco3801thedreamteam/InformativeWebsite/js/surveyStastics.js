$( document ).ready(function() {
	$( "#submitt" ).click(function() {submittSurvey();});
	//disabled
	function submittSurvey(){
		var flag = true;
		var Q1 = $("#Q1").val();
		var Q2 = $("#Q2").val();
		var Q3 = $("#Q3").val();
		var Q4 = $("#Q4").val();
		var Q5 = $("#Q5").val();
		var Q6 = $("#Q6").val();
		var Q7a = $("#Q7_yes").val();
		var Q7b = $("#Q7_no").val();
		var Q7 = $('input[name="Q7"]:checked').val();
		var emailReg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		flag = emailReg.test(Q6);
					
		if(Q1==null||Q2==null||Q3==null||Q4==null||Q5==null||Q7==null){
			flag = false;
		}		
		//CodeInjection
		for (var i = 0, len = Q4.length; i < len; i++) {
			if(Q4[i]=="<"||Q4[i]==">"||Q4[i]===" &"){
				Q4[i]="-";
			}
		}
		for (var j = 0, len = Q5.length; j < len; j++) {
			if(Q5[j]=="<"||Q5[j]==">"||Q5[i]===" &"){
				Q5[j]="-";
			}
		}	
		if(flag == true){
			$("#submitt").css( "background-color","white");
				$.ajax({
				  method: "Get",
				  url: "admin/Addsurvey.php",
				  data:{
					  Q1:Q1,
					  Q2:Q2,
					  Q3:Q3,
					  Q4:Q4,
					  Q5:Q5,
					  Q6:Q6,
					  Q7:Q7
				  }
				}).done(function(reply) {
					alert(reply);
					$(location).attr('href', 'index.php');
						
				});
		}else{
			$("#submitt").css( "background-color","rgba(255, 99, 132, 0.2)");
		}
	}
	/**********************************Graph***********************************************/
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q1"}
		}).done(function(reply) {
			AmCharts.makeChart( "Q1_g", {
						  "type": "pie",
						  "theme": "light",
						  "dataProvider":JSON.parse(reply),
						  "valueField": "Value",
						  "titleField": "Position",
						  "labelText": "Mark:[[Mark]]",
						  "balloonText": "<div style='margin:5px;'>Mark:<b>[[Mark]]</b><br>Number:<b>[[Value]]</b></div>",
						  "labelRadius": -35,
						   "balloon":{
						   "fixedPosition":true
						  },
						  "export": {
						    "enabled": true
						  }
			});
	});
	
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q2"}
		}).done(function(reply) {
			AmCharts.makeChart( "Q2_g", {
						  "type": "pie",
						  "theme": "light",
						  "dataProvider":JSON.parse(reply),
						  "valueField": "Value",
						  "titleField": "Position",
						  "labelText": "Mark:[[Mark]]",
						  "balloonText": "<div style='margin:5px;'>Mark:<b>[[Mark]]</b><br>Number:<b>[[Value]]</b></div>",
						  "labelRadius": -35,
						   "balloon":{
						   "fixedPosition":true
						  },
						  "export": {
						    "enabled": true
						  }
			});
	});
	
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q3"}
		}).done(function(reply) {
			AmCharts.makeChart( "Q3_g", {
						  "type": "pie",
						  "theme": "light",
						  "dataProvider":JSON.parse(reply),
						  "valueField": "Value",
						  "titleField": "Position",
						  "labelText": "Mark:[[Mark]]",
						  "balloonText": "<div style='margin:5px;'>Mark:<b>[[Mark]]</b><br>Number:<b>[[Value]]</b></div>",
						  "labelRadius": -35,
						   "balloon":{
						   "fixedPosition":true
						  },
						  "export": {
						    "enabled": true
						  }
			});
	});
	/**********************************TEXT***********************************************/
	
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q4"}
		}).done(function(reply) {
			//alert(reply);
			var content ="";
			reply = $.parseJSON(reply);
			$.each(reply, function(i, item) {
			    content+="<small>"+item.Time +"</small>";
			    content+="<p>"+item.Content+"</p>";
			});
			$( "#Q4_g" ).html(content);
		});
		
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q5"}
		}).done(function(reply) {
			//alert(reply);
			var content ="";
			reply = $.parseJSON(reply);
			$.each(reply, function(i, item) {
			    content+="<small>"+item.Time +"</small>";
			    content+="<p>"+item.Content+"</p>";
			});
			$( "#Q5_g" ).html(content);
		});
				
	$.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"Q7"}
		}).done(function(reply) {
			//alert(reply);
			var content ="";
			var answer ="";
			reply = $.parseJSON(reply);
			$.each(reply, function(i, item) {
				if(item.Content == 0){
					answer = "No";
				}else{answer = "Yes"}
			    content+="<p><small>"+item.Email +"</small>"+answer+"</p>";
			});
			$( "#Q7_g" ).html(content);
		});
});