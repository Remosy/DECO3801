$( document ).ready(function() {
	var today = new Date();
	var year = today.getFullYear();
	var month = today.getMonth();
	var day = today.getDate();
	//alert(day);
	 $.ajax({
		  method: "Get",
		  url: "admin/Stastics.php",
		  data:{name:"purchasePos"}
		}).done(function(reply) {
			AmCharts.makeChart( "purchasePos", {
						  "type": "pie",
						  "theme": "light",
						  "dataProvider":JSON.parse(reply),
						  "valueField": "Value",
						  "titleField": "Position",
						  "labelText": "[[Position]]",
						  "labelRadius": -35,
						   "balloon":{
						   "fixedPosition":true
						  },
						  "export": {
						    "enabled": true
						  }
			});
		});
		
	
		$.ajax({
			method: "Get",
			url: "admin/Stastics.php",
			data:{name:"purchaseTime"}
			}).done(function(reply) {
				//alert(reply);
				AmCharts.makeChart("purchaseTime", {
						"type": "xy",
					    "theme": "light",
					    "marginRight": 80,
					    "dataDateFormat": "YYYY-MM-DD JJ:NN:SS",
					    "startDuration": 1.5,
					    "trendLines": [],
					    "balloon": {
					        "adjustBorderColor": false,
					        "shadowAlpha": 0,
					        "fixedPosition":true
					    },
					    "graphs": [{
					        "balloonText": "<div style='margin:5px;'><b>[[x]]</b><br>y:<b>[[y]]</b><br>value:<b>[[value]]</b></div>",
					        "bullet": "round",
					        "id": "AmGraph-1",
					        "lineAlpha": 0,
					        "lineColor": "rgba(54, 162, 235, 0.2)",
					        "fillAlphas": 0,
					        "valueField": "Value",
					        "xField": "Time",
					        "yField": "Value"
					    }],
					    "valueAxes": [{
					        "id": "ValueAxis-1",
					        "axisAlpha": 0
					    }, {
					        "id": "ValueAxis-2",
					        "axisAlpha": 0,
					        "position": "bottom",
					        "type": "date",
					        "minimumDate": new Date(2016, 7, 31),
					        "maximumDate":new Date(year,month,day)
					    }],
					    "allLabels": [],
					    "titles": [],
					    "dataProvider":JSON.parse(reply),
					    "export": {
					        "enabled": true
					    },
					    "chartScrollbar": {
					        "offset": 15,
					        "scrollbarHeight": 5
					    },
					    "chartCursor":{
					       "pan":true,
					       "cursorAlpha":0,
					       "valueLineAlpha":0
					    }
					});	
			});	

});