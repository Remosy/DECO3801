<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Paper Factory - Administrator Page</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link href="css/star-rating.css" media="all" rel="stylesheet" type="text/css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="js/star-rating.js" type="text/javascript"></script>
	<script src="js/surveyStastics.js"></script>
	<script>
		$("#Q1").rating();
		$("#Q2").rating();
		$("#Q3").rating();
	</script>
</head>
<?php
if(!isset($_COOKIE['paperFactoryTimeStamp'])|| $_COOKIE['paperFactoryTimeStamp']==null) {
	setcookie("paperFactoryTimeStamp", "", time() - 3600);
	echo("?><script>$(location).attr('href', 'index.php')</script><?php");
}else{
	setcookie("paperFactoryTimeStamp", "done", time() - 3600);
}
?>
<body>
     <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <!-- The main top bar navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="index.php">Paper Factory</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php#home">Home</a>
                    </li>
                    <li>
                        <a href="index.php#about">About</a>
                    </li>
                    <li>
                        <a href="#purchase">Purchase</a>
                    </li>
                    <li>
                        <a href="admin.php">Administrator Login</a>
                    </li>
                    <li>
                        <a href="index.php#support">Support</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.navigation bar container -->
    </nav>

    <a name="home"></a>
    <div class="intro-header">
        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h1>Paper Factory</h1>
                        <h3>Thank you for supporting our product!</h3>
                        <hr class="intro-divider">
                         <ul class="list-inline banner-social-buttons">                        
                        <li>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                        </li>
                        <li>
                            <a href="https://twitter.com/home?status=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                        </li>
                        <li>
                           <a href="https://www.linkedin.com/shareArticle?mini=true&url=https%3A//thedreamteam.uqcloud.net&title=PaperFactory%20By%20thedReam%20Team&summary=&source=" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">LinkedIn</span></a>
                        </li></ul>
                    </div>
                </div>
            </div>

        </div>
    </div>

        <a  name="about"></a>
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">You have preordered access to Paper Factory:</h2>
                    <p class="lead">Please complete the short survey below</p>
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/Logo_new.png" alt="Logo" style="float:right;padding-top:85px;padding-right:110px;width:300px">
                </div>
            </div>
			<div class="row">
					  <div class="form-group"> 
						  <label for="input-1" class="control-label">
						  How nice is our user interface?
						  </label>
						  <input id="Q1" name="input-1" class="rating rating-loading" value="3" dir="ltr" data-size="sm" data data-step="1"/>
					  </div>
					  <div class="form-group"> 
						  <label for="input-2" class="control-label">
						  How useful does PaperFactory! seem for you?
						  </label>
						  <input id="Q2" name="input-2" class="rating rating-loading" value="3" dir="ltr" data-size="sm" data data-step="1"/>
					  </div>
					  <div class="form-group"> 
						  <label for="input-3" class="control-label">
						  How likely are you to recommend PaperFactory! to someone?
						  </label>
						  <input id="Q3" name="input-3" class="rating rating-loading" value="3" dir="ltr" data-size="sm" data data-step="1"/>
					  </div>
					  
					  <div class="form-group">
					    <label for="exampleInputFile">How did you hear about PaperFactory!?</label>
					    <input id="Q4" type="text" class="form-control" maxlength="200" placeholder="Text input"/>
					  </div>
					  <div class="form-group">
					    <label for="exampleInputFile">Do you have any suggestion as to how we can make PaperFactory! better?</label>
					    <textarea id="Q5" class="form-control" maxlength="500" rows="3"></textarea>
					  </div>
					  <div class="form-group">
					    <label for="exampleInputEmail1">Email address</label>
					    <input type="email" class="form-control" id="Q6" placeholder="[Note:] we will send you an email once the product has been completed"/>
					  </div>
					  <div class="form-group">
					    <label for="exampleInputFile">would you like us to send you other emails regarding this product?</label>
					    <label class="radio-inline">
							<input id="Q7_yes" type="radio" name="Q7" value="1"/> Yes
						</label>
						<label class="radio-inline">
							  <input id="Q7_No" type="radio" name="Q7" value="0"/> No
						</label>

					  </div>
					  
					 <p style="text-align: center;"><input id="submitt"  value="Submit" type="button" class="btn btn-default"></p>
			</div>
        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->

<!-- start of the banner-->
    <a  name="support"></a>
    <div class="banner">

        <div class="container">

            <div class="row">
                <div class="col-sm-6">
                    <h2>Show your interest:</h2>
                </div>
                <div class="col-lg-6">
                    <ul class="list-inline banner-social-buttons">                        
                        <li>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                        </li>
                        <li>
                            <a href="https://twitter.com/home?status=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                        </li>
                        <li>
                           <a href="https://www.linkedin.com/shareArticle?mini=true&url=https%3A//thedreamteam.uqcloud.net&title=PaperFactory%20By%20thedReam%20Team&summary=&source=" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">LinkedIn</span></a>
                        </li>
                        <li>
                            <a href="#purchase" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-usd"></i> <span class="network-name">Purchase</span></a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.banner -->

 
<!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="index.php#about">About</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="admin.php">Administrator Login</a>
                        </li>


                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; dReam Team 2016. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>
 <!-- jQuery -->
    <script src="js/jquery.js"></script>

 <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
