<!DOCTYPE html>
<?php
	
if(isset($_COOKIE['paperFactoryTimeStamp'])) {
	setcookie("paperFactoryTimeStamp", date('Y-m-d G:i:s'),'/');
}else{
	setcookie("paperFactoryTimeStamp", date('Y-m-d G:i:s'),'/');
}
?>

<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Paper Factory - Landing Page</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<!-- getSession Info -->
	<script type="text/javascript" src="js/startSession.js"></script>
	
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="index.php">PaperFactory</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <!-- This is the top nav bar-->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="#home">Home</a>
                    </li>
                    <li>
                        <a href="#about">About</a>
                    </li>
                    <li>
                        <a id="purchase_A">Purchase</a>
                    </li>
                    <li>
                        <a href="admin.php">Administrator Login</a>
                    </li>
                    <li>
                        <a href="#support">Support</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


    <!-- Header -->
    <a name="home"></a>
    <div class="intro-header">
        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h1>Paper Factory</h1>
                        <h3>From The dReam Team</h3>
                        <hr class="intro-divider">
                        <ul class="list-inline intro-social-buttons">
                            <li>
                                <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                            </li>
                            <li>
                                <a href="https://twitter.com/home?status=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/shareArticle?mini=true&url=https%3A//thedreamteam.uqcloud.net&title=PaperFactory%20By%20thedReam%20Team&summary=&source=" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">LinkedIn</span></a>
                            </li>
                            <li>
                                <a id="purchase_B" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-usd"></i> <span class="network-name">Purchase</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <!-- Page Content -->

	<a  name="about"></a>
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">About PaperFactory</h2>
                    <p class="lead">PaperFactory is a software package that helps you monitor your printers, monitor their media consumption, predict future media consumption, and create efficient refill routes to minimise time spent maintaining your printers. All you need is a web browser and your printers - the PaperFactory system does the rest!</p>
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/Logo_new.png" alt="Logo" style="float:right;padding-top:85px;padding-right:110px;width:300px">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->

    <div class="content-section-b">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Features</h2>
										<ul class="lead">
											<li>Visualisations of printer <a href="#printermonitoring">media levels & their history</a></li>
											<li>Visualisations of <a href="#printermonitoring">predicted media levels</a></li>
											<li><a href="#routeplanning">Route planning</a> to plan an optimal route to refill printers within a given time window</li>
											<li>Automatic noise filtering of printer sensor data</li>
											<li>Support for desktop & mobile, so that the site can be used on the go</li>
										</ul>
                </div>
                <div class="col-lg-5 col-sm-pull-6  col-sm-6">
                    <img class="img-responsive" src="img/printer list.png" alt="Printer List">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->

    <div class="content-section-a">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Product Video</h2>
                    <p class="lead">
										</p>
                </div>
                <div class="col-lg-5">
                    <iframe id="mvp" src="https://player.vimeo.com/video/182280661" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->



		<a  name="printermonitoring"></a>
    <div class="content-section-b">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">How it Works: Printer Monitoring & Prediction</h2>
										<p class="lead">The PaperFactory systems collects printer media (Paper/Toner/Ink) data gathered via SNMP and presents it in an easy to use user interface, allowing you to analyse usage patterns and identify printers needing refilling. From this historical data, the system provides predictions of future consumption of each of the different media types, which along with current media levels allows a projection of the stockout date of each media type. For each printer, the earliest media stockout date is identified, and those printers which most urgently need refilling to prevent a stockout are prioritised by the <a href="#routeplanning">route planner</a>.</p>
                </div>
                <div class="col-lg-5 col-sm-pull-6  col-sm-6">
                    <img class="img-responsive" src="img/printermonitoring.png" alt="Printer Monitoring Window">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->


		<a  name="routeplanning"></a>
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">How it Works: Route Planning</h2>
                    <p class="lead">The PaperFactory system identifies those printers that most urgently need refilling based on <a href="#printermonitoring">projected consumption</a> versus current media levels. From these projections, a reward is calculated per printer which is proportional to potential unsatisfied future consumption if the printer is never refilled. Given a time limit, the route planner attempts to identify a restocking route fitting inside the time window which maximises total reward, thus minimising future unsatisfied printer media consumption (print jobs missed). At each next step in the route, the route planner initially uses a <a href="https://en.wikipedia.org/wiki/Greedy_algorithm">greedy method</a> that selects the next best printer to visit which maximises reward per distance travelled; this route is then iteratively improved using a variant of <a href="https://en.wikipedia.org/wiki/Monte_Carlo_tree_search">MCTS/UCB</a> to identify the route with the highest reward within the time window.</p>
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/routeclose.png" alt="Route Planner Close Up">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->



	<a  name="support"></a>
    <div class="banner">

        <div class="container">

            <div class="row">
                <div class="col-sm-6">
                    <h2>Show your interest:</h2>
                </div>
                <div class="col-lg-6">
                    <ul class="list-inline banner-social-buttons">                        
                        <li>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                        </li>
                        <li>
                            <a href="https://twitter.com/home?status=http%3A//thedreamteam.uqcloud.net" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=https%3A//thedreamteam.uqcloud.net&title=PaperFactory%20By%20thedReam%20Team&summary=&source=" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">LinkedIn</span></a>
                        </li>
                        <li>
                            <a id="purchase_C" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-usd"></i> <span class="network-name">Purchase</span></a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.banner -->

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                        <li>
                            <a href="#">Home</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="#about">About</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a id="purchase_D">Purchase</a>
                        </li>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="admin.php">Administrator Login</a>
                        </li>


                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; dReam Team 2016. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
