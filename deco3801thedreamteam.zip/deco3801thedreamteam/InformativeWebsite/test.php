<!DOCTYPE html>
<?php
//require_once "uq/auth.php";
//auth_require();

include 'admin/Stastics.php';
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Paper Factory - Administrator Page</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    <!-- Data Table -->
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js"></script>
	<script type="text/javascript">
		/*
	$(document).ready(function(){
    	$('#paperTable').DataTable();
	});*/
	</script>
	<!-- Amchart -->
	<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
	<script src="https://www.amcharts.com/lib/3/serial.js"></script>
	<script src="https://www.amcharts.com/lib/3/pie.js"></script>
	<script src="https://www.amcharts.com/lib/3/xy.js"></script>
	<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
	<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
	
	<script src="js/purchaseStastics.js"></script>
	<script src="js/surveyStastics.js"></script>
</head>

<body>
     <div id="printerList">
	<ul class="nav nav-pills">
		<li role="presentation"><a>Paper</a></li>
		<li role="presentation"><a>Ink</a></li>
	</ul>
	<div>
		
		
	<table id="paperTable" css="display" cellspacing="0" width="100%">
			        <thead>
			            <tr>
				            <th>Printer Id</th>
			                <th>Location</th>
			                <th>Tray 1</th>
							<th>Tray 2</th>
			                <th>Tray 3</th>
			                <th>Tray 4</th>
			            </tr>
			        </thead>
					<tbody>
			            <tr>
			                <td>1</td>
			                <td>50</td>
			                <td>33</td>
			                <td>61</td>
			                <td>88</td>
			                <td>19</td>
			            </tr>
			            <tr>
			                <td>2</td>
			                <td>49</td>
			                <td>33</td>
			                <td>63</td>
			                <td>22</td>
			                <td>22</td>
			            </tr>
			            <tr>
			                <td>1</td>
			                <td>50</td>
			                <td>33</td>
			                <td>61</td>
			                <td>88</td>
			                <td>19</td>
			            </tr>
			            <tr>
			                <td>2</td>
			                <td>49</td>
			                <td>33</td>
			                <td>63</td>
			                <td>22</td>
			                <td>22</td>
			            </tr>
			            <tr>
			                <td>1</td>
			                <td>50</td>
			                <td>33</td>
			                <td>61</td>
			                <td>88</td>
			                <td>19</td>
			            </tr>
			            <tr>
			                <td>2</td>
			                <td>49</td>
			                <td>33</td>
			                <td>63</td>
			                <td>22</td>
			                <td>22</td>
			            </tr>
			            <tr>
			                <td>1</td>
			                <td>50</td>
			                <td>33</td>
			                <td>61</td>
			                <td>88</td>
			                <td>19</td>
			            </tr>
			            <tr>
			                <td>2</td>
			                <td>49</td>
			                <td>33</td>
			                <td>63</td>
			                <td>22</td>
			                <td>22</td>
			            </tr>
					</tbody>
			        
	</table>
	</div>
	
	<script type="text/javascript">
	$(document).ready(function(){
    $('#paperTable').DataTable();
});
	</script>
</div>
 <!-- jQuery -->
    <script src="js/jquery.js"></script>

 <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>