package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.TimestampedMediaAmount;
import java.util.ArrayList;
import java.util.List;





@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class MediaWithTimestampedAmounts   {
  
  private String mediaType = null;
  private List<TimestampedMediaAmount> amounts = new ArrayList<TimestampedMediaAmount>();

  /**
   * The media type
   **/
  public MediaWithTimestampedAmounts mediaType(String mediaType) {
    this.mediaType = mediaType;
    return this;
  }

  
  @ApiModelProperty(value = "The media type")
  @JsonProperty("media_type")
  public String getMediaType() {
    return mediaType;
  }
  public void setMediaType(String mediaType) {
    this.mediaType = mediaType;
  }

  /**
   **/
  public MediaWithTimestampedAmounts amounts(List<TimestampedMediaAmount> amounts) {
    this.amounts = amounts;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("amounts")
  public List<TimestampedMediaAmount> getAmounts() {
    return amounts;
  }
  public void setAmounts(List<TimestampedMediaAmount> amounts) {
    this.amounts = amounts;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MediaWithTimestampedAmounts mediaWithTimestampedAmounts = (MediaWithTimestampedAmounts) o;
    return Objects.equals(mediaType, mediaWithTimestampedAmounts.mediaType) &&
        Objects.equals(amounts, mediaWithTimestampedAmounts.amounts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(mediaType, amounts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MediaWithTimestampedAmounts {\n");
    
    sb.append("    mediaType: ").append(toIndentedString(mediaType)).append("\n");
    sb.append("    amounts: ").append(toIndentedString(amounts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

