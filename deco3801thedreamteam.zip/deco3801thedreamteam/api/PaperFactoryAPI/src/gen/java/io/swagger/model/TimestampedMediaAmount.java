package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.joda.time.DateTime;

import java.util.Date;





@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class TimestampedMediaAmount   {
  
  private DateTime timestamp = null;
  private Integer amount = null;

  /**
   * The timestamp at which these measurements were taken
   **/
  public TimestampedMediaAmount timestamp(DateTime timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  
  @ApiModelProperty(value = "The timestamp at which these measurements were taken")
  @JsonProperty("timestamp")
  public DateTime getTimestamp() {
    return timestamp;
  }
  public void setTimestamp(DateTime timestamp) {
    this.timestamp = timestamp;
  }

  /**
   * The amount of the media (level or consumption)
   **/
  public TimestampedMediaAmount amount(Integer amount) {
    this.amount = amount;
    return this;
  }

  
  @ApiModelProperty(value = "The amount of the media (level or consumption)")
  @JsonProperty("amount")
  public Integer getAmount() {
    return amount;
  }
  public void setAmount(Integer amount) {
    this.amount = amount;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TimestampedMediaAmount timestampedMediaAmount = (TimestampedMediaAmount) o;
    return Objects.equals(timestamp, timestampedMediaAmount.timestamp) &&
        Objects.equals(amount, timestampedMediaAmount.amount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(timestamp, amount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TimestampedMediaAmount {\n");
    
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

