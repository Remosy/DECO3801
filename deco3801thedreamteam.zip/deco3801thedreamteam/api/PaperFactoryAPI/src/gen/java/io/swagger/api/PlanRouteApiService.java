package io.swagger.api;

import java.math.BigDecimal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public abstract class PlanRouteApiService {
    public abstract Response planRouteGet(Integer timeWindowSeconds,BigDecimal originLat,BigDecimal originLng,Integer computationTime,String planner,SecurityContext securityContext) throws NotFoundException;
}
