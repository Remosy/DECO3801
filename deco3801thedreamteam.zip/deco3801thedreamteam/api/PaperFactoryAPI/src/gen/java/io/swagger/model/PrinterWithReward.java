package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;


@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PrinterWithReward {
  
  private Printer printer = null;
  private Double reward = null;

  /**
   **/
  public PrinterWithReward printer(Printer printer) {
    this.printer = printer;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("printer")
  public Printer getPrinter() {
    return printer;
  }
  public void setPrinter(Printer printer) {
    this.printer = printer;
  }

  /**
   **/
  public PrinterWithReward reward(Double reward) {
    this.reward = reward;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("reward")
  public Double getReward() {
    return reward;
  }
  public void setReward(Double reward) {
    this.reward = reward;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PrinterWithReward printerWithReward = (PrinterWithReward) o;
    return Objects.equals(printer, printerWithReward.printer) &&
        Objects.equals(reward, printerWithReward.reward);
  }

  @Override
  public int hashCode() {
    return Objects.hash(printer, reward);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PrinterWithReward {\n");
    
    sb.append("    printer: ").append(toIndentedString(printer)).append("\n");
    sb.append("    reward: ").append(toIndentedString(reward)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

