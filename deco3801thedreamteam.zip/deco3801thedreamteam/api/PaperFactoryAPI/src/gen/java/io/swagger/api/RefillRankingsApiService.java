package io.swagger.api;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public abstract class RefillRankingsApiService {
    public abstract Response refillRankingsGet(SecurityContext securityContext) throws NotFoundException;
}
