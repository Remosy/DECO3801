package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import io.swagger.model.Printer;
import io.swagger.model.ErrorResponse;
import io.swagger.model.MediaAndCapacity;
import java.math.BigDecimal;
import io.swagger.model.MediaWithTimestampedAmounts;
import java.util.Date;

import java.util.List;
import io.swagger.api.NotFoundException;
import org.joda.time.DateTime;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public abstract class PrintersApiService {
    public abstract Response printersListGet(SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaCapacitiesGet(BigDecimal printerId,SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaConsumptionGet(BigDecimal printerId, DateTime startDate, DateTime endDate, SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaConsumptionPredictedGet(BigDecimal printerId,BigDecimal lookAheadDays,SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaLevelsGet(BigDecimal printerId,DateTime startDate,DateTime endDate,Boolean rawData,SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaLevelsPredictedGet(BigDecimal printerId,BigDecimal lookAheadDays,SecurityContext securityContext) throws NotFoundException;
    public abstract Response printersPrinterIdMediaTypesGet(BigDecimal printerId,SecurityContext securityContext) throws NotFoundException;
}
