package io.swagger.api;

import org.joda.time.DateTime;

import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

/**
 * Created by robert.sharp on 1/09/2016.
 */
@Provider
public class ISO8601JodaDateTimeParamConverterProvider implements ParamConverterProvider {

    @Override
    public <T> ParamConverter<T> getConverter(Class<T> aClass, Type type, Annotation[] annotations) {
        if (type.equals(DateTime.class)) {
            return (ParamConverter<T>) new ISO8601JodaDateTimeParamConverter();
        } else {
            return null;
        }
    }
}
