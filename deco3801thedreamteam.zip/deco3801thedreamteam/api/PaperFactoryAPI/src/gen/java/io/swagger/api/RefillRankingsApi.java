package io.swagger.api;

import io.swagger.api.factories.RefillRankingsApiServiceFactory;

import io.swagger.model.PrinterWithReward;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;

@Path("/refill_rankings")

@Produces({ "application/json" })
@io.swagger.annotations.Api(description = "the refill_rankings API")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class RefillRankingsApi  {
   private final RefillRankingsApiService delegate = RefillRankingsApiServiceFactory.getRefillRankingsApi();

    @GET
    
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets the rankings associated with each printer", notes = "A higher reward indicates that it's more likely that if the printer is not refilled today, more print jobs will be missed in the future. Rankings are based on forward predictions of printer consumption based on historical consumption. ", response = PrinterWithReward.class, responseContainer = "List", tags={ "Prediction", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An ordered (by reward descending) array of printers with their associated rankings", response = PrinterWithReward.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = PrinterWithReward.class, responseContainer = "List") })
    public Response refillRankingsGet(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.refillRankingsGet(securityContext);
    }
}
