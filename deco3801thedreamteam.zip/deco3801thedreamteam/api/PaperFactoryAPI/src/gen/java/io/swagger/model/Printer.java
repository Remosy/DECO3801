package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Location;





@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class Printer   {
  
  private Integer printerId = null;
  private String buildingName = null;
  private String printerName = null;
  private Location location = null;

  /**
   * Unique integer identifier for a printer
   **/
  public Printer printerId(Integer printerId) {
    this.printerId = printerId;
    return this;
  }

  
  @ApiModelProperty(value = "Unique integer identifier for a printer")
  @JsonProperty("printer_id")
  public Integer getPrinterId() {
    return printerId;
  }
  public void setPrinterId(Integer printerId) {
    this.printerId = printerId;
  }

  /**
   * Descriptive name of the building
   **/
  public Printer buildingName(String buildingName) {
    this.buildingName = buildingName;
    return this;
  }

  
  @ApiModelProperty(value = "Descriptive name of the building")
  @JsonProperty("building_name")
  public String getBuildingName() {
    return buildingName;
  }
  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  /**
   * Descriptive name to identify the printer in the building
   **/
  public Printer printerName(String printerName) {
    this.printerName = printerName;
    return this;
  }

  
  @ApiModelProperty(value = "Descriptive name to identify the printer in the building")
  @JsonProperty("printer_name")
  public String getPrinterName() {
    return printerName;
  }
  public void setPrinterName(String printerName) {
    this.printerName = printerName;
  }

  /**
   **/
  public Printer location(Location location) {
    this.location = location;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("location")
  public Location getLocation() {
    return location;
  }
  public void setLocation(Location location) {
    this.location = location;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Printer printer = (Printer) o;
    return Objects.equals(printerId, printer.printerId) &&
        Objects.equals(buildingName, printer.buildingName) &&
        Objects.equals(printerName, printer.printerName) &&
        Objects.equals(location, printer.location);
  }

  @Override
  public int hashCode() {
    return Objects.hash(printerId, buildingName, printerName, location);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Printer {\n");
    
    sb.append("    printerId: ").append(toIndentedString(printerId)).append("\n");
    sb.append("    buildingName: ").append(toIndentedString(buildingName)).append("\n");
    sb.append("    printerName: ").append(toIndentedString(printerName)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

