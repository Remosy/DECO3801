package io.swagger.api;

import org.joda.time.DateTime;
import org.joda.time.format.ISODateTimeFormat;

import javax.ws.rs.ext.ParamConverter;

/**
 * Created by robert.sharp on 1/09/2016.
 */
public class ISO8601JodaDateTimeParamConverter implements ParamConverter<DateTime> {

    @Override
    public DateTime fromString(String s) {
        try {
            return ISODateTimeFormat.dateTimeParser().parseDateTime(s);
        } catch (Exception e) {
            return null; //if we don't return null, Tomcat will just 404 the req
        }

    }

    @Override
    public String toString(DateTime dateTime) {
        return ISODateTimeFormat.dateTimeParser().print(dateTime);
    }
}
