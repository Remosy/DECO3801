package io.swagger.api;

import io.swagger.api.factories.PlanRouteApiServiceFactory;

import io.swagger.annotations.ApiParam;

import java.math.BigDecimal;
import io.swagger.model.TravelTimePrinterAndReward;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;

@Path("/plan_route")

@Produces({ "application/json" })
@io.swagger.annotations.Api(description = "the plan_route API")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PlanRouteApi  {
   private final PlanRouteApiService delegate = PlanRouteApiServiceFactory.getPlanRouteApi();

    @GET
    
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets a route plan based on the current set of printers and their refill rankings.", notes = "Route planning will assume a fixed refill time of one minute, and will attempt to maximise the sum of the ranks of the printers that are visited, while keeping the route travel & refill time within the time window. ", response = TravelTimePrinterAndReward.class, responseContainer = "List", tags={ "Routes","Prediction", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An ordered array of printers to visit, associated with the travel times to reach that printer", response = TravelTimePrinterAndReward.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = TravelTimePrinterAndReward.class, responseContainer = "List") })
    public Response planRouteGet(@ApiParam(value = "The time window in seconds allowed for route traversal",required=true) @QueryParam("time_window_seconds") Integer timeWindowSeconds
,@ApiParam(value = "The route start & end point latitude",required=true) @QueryParam("origin_lat") BigDecimal originLat
,@ApiParam(value = "The route start & end point longitude",required=true) @QueryParam("origin_lng") BigDecimal originLng
,@ApiParam(value = "The maximum allowed computation time, in seconds. Note that this is server-side time only and does not consider network transit time") @QueryParam("computation_time") Integer computationTime
,@ApiParam(value = "The name of the route planner to invoke",required = false) @QueryParam("planner") String planner
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.planRouteGet(timeWindowSeconds,originLat,originLng,computationTime,planner,securityContext);
    }
}
