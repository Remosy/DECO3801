package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.PrintersApiService;
import io.swagger.api.factories.PrintersApiServiceFactory;

import io.swagger.annotations.ApiParam;

import io.swagger.model.Printer;
import io.swagger.model.ErrorResponse;
import io.swagger.model.MediaAndCapacity;
import java.math.BigDecimal;
import io.swagger.model.MediaWithTimestampedAmounts;
import java.util.Date;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.joda.time.DateTime;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;

@Path("/printers")

@Produces({ "application/json" })
@io.swagger.annotations.Api(description = "the printers API")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PrintersApi  {
   private final PrintersApiService delegate = PrintersApiServiceFactory.getPrintersApi();

    @GET
    @Path("/list")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Lists the available printers", notes = "TODO ", response = Printer.class, responseContainer = "List", tags={ "Printers", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of printers", response = Printer.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = Printer.class, responseContainer = "List") })
    public Response printersListGet(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersListGet(securityContext);
    }
    @GET
    @Path("/{printer_id}/media_capacities")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets the expected maximum inventory of each media type the printer holds", notes = "TODO", response = MediaAndCapacity.class, responseContainer = "List", tags={ "Printers", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of media types with associated max inventory levels", response = MediaAndCapacity.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = MediaAndCapacity.class, responseContainer = "List") })
    public Response printersPrinterIdMediaCapacitiesGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaCapacitiesGet(printerId,securityContext);
    }
    @GET
    @Path("/{printer_id}/media_consumption")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets printer media consumption per day in the last 7 days or for a date range", notes = "TODO ", response = MediaWithTimestampedAmounts.class, responseContainer = "List", tags={ "Printers", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of timestamped sets of media values", response = MediaWithTimestampedAmounts.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = MediaWithTimestampedAmounts.class, responseContainer = "List") })
    public Response printersPrinterIdMediaConsumptionGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@ApiParam(value = "Start date (inclusive) for media consumption query") @QueryParam("start_date") DateTime startDate
,@ApiParam(value = "End date (inclusive) for media consumption query") @QueryParam("end_date") DateTime endDate
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaConsumptionGet(printerId,startDate,endDate,securityContext);
    }
    @GET
    @Path("/{printer_id}/media_consumption_predicted")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets predicted printer consumption per day", notes = "TODO", response = MediaWithTimestampedAmounts.class, responseContainer = "List", tags={ "Printers","Prediction", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of timestamped sets of media consumption per day", response = MediaWithTimestampedAmounts.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = MediaWithTimestampedAmounts.class, responseContainer = "List") })
    public Response printersPrinterIdMediaConsumptionPredictedGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@ApiParam(value = "The number of future days to get predictions for") @QueryParam("look_ahead_days") BigDecimal lookAheadDays
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaConsumptionPredictedGet(printerId,lookAheadDays,securityContext);
    }
    @GET
    @Path("/{printer_id}/media_levels")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets printer media levels in the last 24 hours or for a date range", notes = "TODO ", response = MediaWithTimestampedAmounts.class, responseContainer = "List", tags={ "Printers", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of timestamped sets of media levels", response = MediaWithTimestampedAmounts.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = MediaWithTimestampedAmounts.class, responseContainer = "List") })
    public Response printersPrinterIdMediaLevelsGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@ApiParam(value = "Start date (inclusive) for media levels query") @QueryParam("start_date") DateTime startDate
,@ApiParam(value = "End date (inclusive) for media levels query") @QueryParam("end_date") DateTime endDate
,@ApiParam(value = "Whether to return the raw (pre noise filter) data") @QueryParam("raw_data") Boolean rawData
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaLevelsGet(printerId,startDate,endDate,rawData,securityContext);
    }
    @GET
    @Path("/{printer_id}/media_levels_predicted")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets predicted printer levels per day", notes = "Note that the predicted printer levels are based on current printers levels along with predicted consumption, and assume that no future stock refills will occur for the printer", response = MediaWithTimestampedAmounts.class, responseContainer = "List", tags={ "Printers","Prediction", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of timestamped sets of media levels", response = MediaWithTimestampedAmounts.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = MediaWithTimestampedAmounts.class, responseContainer = "List") })
    public Response printersPrinterIdMediaLevelsPredictedGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@ApiParam(value = "The number of future days to get predictions for") @QueryParam("look_ahead_days") BigDecimal lookAheadDays
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaLevelsPredictedGet(printerId,lookAheadDays,securityContext);
    }
    @GET
    @Path("/{printer_id}/media_types")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Gets the media types supported by this printer", notes = "TODO", response = String.class, responseContainer = "List", tags={ "Printers", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "An array of media types", response = String.class, responseContainer = "List"),
        
        @io.swagger.annotations.ApiResponse(code = 200, message = "Unexpected error", response = String.class, responseContainer = "List") })
    public Response printersPrinterIdMediaTypesGet(@ApiParam(value = "The id of the printer.",required=true) @PathParam("printer_id") BigDecimal printerId
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.printersPrinterIdMediaTypesGet(printerId,securityContext);
    }
}
