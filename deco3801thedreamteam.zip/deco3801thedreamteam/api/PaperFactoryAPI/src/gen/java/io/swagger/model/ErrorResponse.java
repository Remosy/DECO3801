package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;





@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class ErrorResponse   {
  
  private Integer errorCode = null;
  private String userMessage = null;
  private String debugMessage = null;

  /**
   **/
  public ErrorResponse errorCode(Integer errorCode) {
    this.errorCode = errorCode;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("error_code")
  public Integer getErrorCode() {
    return errorCode;
  }
  public void setErrorCode(Integer errorCode) {
    this.errorCode = errorCode;
  }

  /**
   **/
  public ErrorResponse userMessage(String userMessage) {
    this.userMessage = userMessage;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("user_message")
  public String getUserMessage() {
    return userMessage;
  }
  public void setUserMessage(String userMessage) {
    this.userMessage = userMessage;
  }

  /**
   **/
  public ErrorResponse debugMessage(String debugMessage) {
    this.debugMessage = debugMessage;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("debug_message")
  public String getDebugMessage() {
    return debugMessage;
  }
  public void setDebugMessage(String debugMessage) {
    this.debugMessage = debugMessage;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorResponse errorResponse = (ErrorResponse) o;
    return Objects.equals(errorCode, errorResponse.errorCode) &&
        Objects.equals(userMessage, errorResponse.userMessage) &&
        Objects.equals(debugMessage, errorResponse.debugMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(errorCode, userMessage, debugMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorResponse {\n");
    
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    userMessage: ").append(toIndentedString(userMessage)).append("\n");
    sb.append("    debugMessage: ").append(toIndentedString(debugMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

