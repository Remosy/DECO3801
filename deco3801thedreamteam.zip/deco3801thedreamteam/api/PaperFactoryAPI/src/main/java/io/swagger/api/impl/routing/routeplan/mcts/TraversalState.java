package io.swagger.api.impl.routing.routeplan.mcts;

import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteEntry;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;

import java.util.*;

/**
 * Created by rob on 27/08/16.
 *
 * Represents a step in the traversal tree, which has a set of vertices that
 * have been visited so far, an average reward for traversals which were rooted
 * at this state, and the number of traversals performed from the state.
 */
public class TraversalState<T extends VertexWithReward> {

    /***
     * Epsilon hyperparameter for UCB explore/exploit statistical
     * confidence function.
     */
    private static final double EPSILON_C = 10;

    /***
     * The vertex being visited in this state in the graph traversal tree
     */
    private final T vertexBeingVisited;

    /***
     * Shared data used by all states in a traversal
     */
    private final TraversalShared<T> traversalShared;

    /***
     * The nearest neighbour lookup gives us an iterator that goes through each
     * of the nearest neighbour vertices of this vertex, allowing us to go
     * through each of them in order per state.
     */
    private Iterator<T> nearestNeighbourVerticesIterator;

    /***
     * The child states (states following this one in the traversal) which
     * have already been evaluated.
     *
     * These are initialised during the first traversal of this state - other-
     * wise this will be null.
     */
    private List<TraversalState> evaluatedChildTraversalStates;

    /***
     * The average reward of all traversals rooted at this state, which
     * incorporates reward of this vertex and the sum of all child vertex
     * rewards.
     *
     * Float to save space.
     */
    private float averageTraversalReward;

    /***
     * The average distance of all traversals rooted at this state, which
     * incorporates the distance from this vertex to its immediate children.
     *
     * Float to save space.
     */
    private float averageTraversalDistance;

    /***
     * The number of traversals performed which were rooted at this state.
     */
    private int traversalsPerformed;

    /***
     * Set true if there are no child states to explore from this one, or if
     * all of the child states of this state are also fully explored. This way
     * we can speed up the UCB explorations as well as decide when the route
     * planning is complete.
     */
    private boolean fullyExplored;

    public boolean isFullyExplored() {
        return fullyExplored;
    }

    public TraversalState(
            TraversalShared<T> traversalShared,
            T vertexBeingVisited) {
        this.vertexBeingVisited = vertexBeingVisited;

        //prealloc space for child pointers
        this.evaluatedChildTraversalStates =
                new ArrayList<>(traversalShared.getAllVertices().size());
        this.fullyExplored = false;
        this.traversalShared = traversalShared;
        this.averageTraversalReward = 0;
        this.traversalsPerformed = 0;
        this.nearestNeighbourVerticesIterator =
                traversalShared
                        .getNearestNeighbourLookup()
                        .getNearestNeighbourEnumerator(vertexBeingVisited);
    }

    public void singleMonteCarloTraversal(
            double timeSpentAlready,
            HashSet<T> alreadyVisited,
            Route routeSoFar) {

        T selectedVertex = null;
        TraversalState<T> childState = null;
        RouteEntry.VertexSelectionMethod vertexSelectionMethod;

        //add this vertex to already visited
        alreadyVisited.add(vertexBeingVisited);

        //pre-calculate the return to start travel time once
        double thisVertexTravelTimeReturnToStart =
                this.vertexBeingVisited.travelTimeTo(
                        traversalShared.getStartEndVertex());

        //determine how many potential vertices there are that we could explore
        // but haven't yet
        int remainingVerticesToExplore =
                traversalShared.getAllVertices().size()
                        - alreadyVisited.size();

        //we've run out of vertices to explore (visited all) before even
        // exhausting our time window, so stop traversal
        if(remainingVerticesToExplore == 0) {
            this.setFullyExplored(); //nowhere to go, so fully explored

            //add this vertex and a return to start to the route, then
            // return - route complete
            appendTerminalRouteEntry(
                    routeSoFar, thisVertexTravelTimeReturnToStart);
            return;
        }

        //select the next nearest neighbour vertex that hasn't been visited.
        // this should always return a vertex we haven't seen yet, or null if
        // the nearest neighbour iterator has exhausted all other vertices.
        selectedVertex = nearestNeighbourSelector(alreadyVisited);

        if(selectedVertex != null) {

            vertexSelectionMethod =
                    RouteEntry.VertexSelectionMethod.NEAREST_NEIGHBOUR;

            //got a vertex to evaluate as a child - create child state
            childState = new TraversalState<T>(
                    traversalShared, selectedVertex);

            //need to link it as a child
            evaluatedChildTraversalStates.add(childState);
        } else {

            vertexSelectionMethod =
                    RouteEntry.VertexSelectionMethod.UPPER_CONFIDENCE_BOUND;

            //otherwise select next vertex based on upper confidence bound
            // (UCB1), considering child states
            childState = ucbSelector();
        }

        //if we've exhausted nearest neighbours and UCB didn't return any
        // children, all child states must be fully explored
        if (childState == null) {

            //all children are fully explored! so set this as fully explored
            // as well, to avoid searching it next time
            this.setFullyExplored();

            //NOTE: since we've already fully explored this subtree, there's
            // no chance that there's a better route here (because we've seen
            // all potential routes in these branches!), so stop.
            return;
        }

        //if we did UCB, we need to pull the vertex out of the state
        selectedVertex = childState.vertexBeingVisited;

        //calculate time spent going from next vertex back to start
        double selectedVertexTravelTimeToStart =
                selectedVertex.travelTimeTo(
                        traversalShared.getStartEndVertex());

        /////now do the traversal calculations and potential recursion!
        double traversalReward = vertexBeingVisited.getReward();

        //calculate time spent for traversal to this next vertex
        double timeSpentNextTraversal =
                vertexBeingVisited.travelTimeTo(selectedVertex);

        //calculate the current time spent plus the time to next vertex, which
        // represents the new route traversal time less the return to start
        double timeSpentAlreadyPlusNext =
                timeSpentAlready
                        + timeSpentNextTraversal
                        + traversalShared
                            .getRouteTimingConfig()
                            .getVertexVisitTime();

        //calculate total time for this new prospective route extension,
        // including the return to start
        double totalTimeSpentIncludingReturn =
                + timeSpentAlreadyPlusNext + selectedVertexTravelTimeToStart;

        //if potential time spent exceeds max route time, the route is over,
        // so stop the traversal and return just the reward for this vertex
        if (totalTimeSpentIncludingReturn
                >= traversalShared.getRouteTimingConfig().getMaxRouteTime()) {
            recordSubTraversalStats(
                    traversalReward, selectedVertexTravelTimeToStart);

            //also mark it as fully explored, because it's a terminal state -
            // it can't be visited because its over the max route time
            childState.setFullyExplored();

            //add this vertex reward and a return to start to the route, then
            // return - route complete
            appendTerminalRouteEntry(routeSoFar, selectedVertexTravelTimeToStart);
            return;
        }

        //store current route reward so that we can determine how much the
        // child subtree adds to the reward
        double preChildReward = routeSoFar.getRewardSoFar();
        double preChildDistance = routeSoFar.getTravelTime();

        //by this point we know we can visit this vertex and the child vertex,
        // so add this vertex and the child vertex
        RouteEntry<T> routeEntry =
                new RouteEntry(timeSpentNextTraversal,
                        selectedVertex, vertexSelectionMethod);
        routeSoFar.add(routeEntry);

        //do child traversal
        childState.singleMonteCarloTraversal(
                timeSpentAlreadyPlusNext,
                alreadyVisited,
                routeSoFar);

        //get route reward after child traversal
        double postChildReward = routeSoFar.getRewardSoFar();
        double postChildDistance = routeSoFar.getTravelTime();

        //calculate child sub traversal reward
        double childSubTraversalReward = postChildReward - preChildReward;
        double childSubTraversalDistance = postChildDistance - preChildDistance;

        //return our reward - it's the child reward plus the reward at
        // this vertex
        traversalReward += childSubTraversalReward;
        recordSubTraversalStats(traversalReward, childSubTraversalDistance);
    }

    /***
     * Selects a random element from a list of elements
     */
    private T nearestNeighbourSelector(
            Set<T> exclude) {
        while(nearestNeighbourVerticesIterator.hasNext()) {
            T nextNearestNeighbour = nearestNeighbourVerticesIterator.next();
            if(exclude.contains(nextNearestNeighbour)) {
                continue; //skip
            }
            return nextNearestNeighbour;
        }

        return null; //nearest neighbours exhausted - now use UCB!
    }

    private void appendTerminalRouteEntry(
            Route<T> routeSoFar, double timeToReturnToStart) {

        //add this vertex and a return to start to the route, then
        // return - route complete
        RouteEntry<T> routeEntry = new RouteEntry<>(
                timeToReturnToStart, traversalShared.getStartEndVertex(),
                RouteEntry.VertexSelectionMethod.ENDPOINT_VERTEX);
        routeSoFar.add(routeEntry);
    }

    private void setFullyExplored() {

        this.fullyExplored = true;

        //since this state is fully explored, we can remove the child states,
        // because they must all be fully explored as well
        this.evaluatedChildTraversalStates = null;
    }

    private TraversalState ucbSelector() {

        //UCB is described here:
        // https://jeffbradberry.com/posts/2015/09/intro-to-monte-carlo-tree-search/

        //we only need to calculate this once
        double logTraversals = Math.log(this.traversalsPerformed);

        List<TraversalState> bestRewardUcbStates =
                selectBestRewardUcbSubset(logTraversals);

        return selectBestUcbDistance(logTraversals, bestRewardUcbStates);
    }

    private TraversalState selectBestUcbDistance(
            double logTraversals,
            List<TraversalState> bestRewardUcbStates) {

        //now get best distance UCB from the reward UCB set
        double currentBestDistanceUcb = Double.POSITIVE_INFINITY;
        TraversalState currentBestTraversalState = null;

        for(TraversalState candidateState : bestRewardUcbStates) {

            double distanceUcb = distanceUcb(logTraversals, candidateState);

            //minimise distance - refer to distanceUcb() impl as well
            if(distanceUcb < currentBestDistanceUcb) {
                currentBestDistanceUcb = distanceUcb;
                currentBestTraversalState = candidateState;
            }
        }

        return currentBestTraversalState;
    }

    private List<TraversalState> selectBestRewardUcbSubset(double logTraversals) {

        //calculate upper confidence bound for all child states
        double currentBestRewardUcb = Double.NEGATIVE_INFINITY;

        //collect all states that have equivalent reward UCBs - if there's
        // more than one, we'll then do distance UCB
        List<TraversalState> bestRewardUcbStates =
                new ArrayList<>(this.evaluatedChildTraversalStates.size());

        for(TraversalState candidateState : evaluatedChildTraversalStates) {

            if(candidateState.fullyExplored) {
                continue; //skip fully explored states
            }

            double rewardUcb = rewardUcb(
                    logTraversals, candidateState);

            double rewardUcbVersusBest = rewardUcb / currentBestRewardUcb;

            boolean significantRewardUcbImprovement =
                    rewardUcbVersusBest >= 1.01;

            boolean ucbWithinBestUcbRange =
                    rewardUcbVersusBest > 0.99
                            && rewardUcbVersusBest < 1.01;

            if(significantRewardUcbImprovement
                    || currentBestRewardUcb == Double.NEGATIVE_INFINITY) {

                //set new best reward
                currentBestRewardUcb = rewardUcb;

                //new best UCB - reset to just include this state
                bestRewardUcbStates.clear();
                bestRewardUcbStates.add(candidateState);
            } else if (ucbWithinBestUcbRange){

                //within same range as current best UCB - just add state
                // to current set
                bestRewardUcbStates.add(candidateState);
            }
        }

        return bestRewardUcbStates;
    }

    private double distanceUcb(
            double logTraversals,
            TraversalState candidateState) {

        //we want to explore vertices with potential shorter distance
        return (- candidateState.averageTraversalDistance)
                * (1 + EPSILON_C * Math.sqrt(
                (2 * logTraversals)
                        / candidateState.traversalsPerformed));
    }

    private double rewardUcb(
            double logTraversals,
            TraversalState candidateState) {

        //UCB1 is described here:
        // https://jeffbradberry.com/posts/2015/09/intro-to-monte-carlo-tree-search/

        //otherwise default is to do UCB on reward
        return candidateState.averageTraversalReward
                * (1 + EPSILON_C * Math.sqrt(
                (2 * logTraversals)
                        / candidateState.traversalsPerformed));
    }

    /***
     * Records the reward of a traversal rooted at this state
     */
    private void recordSubTraversalStats(
            double subTraversalReward, double subTraversalDistance) {

        //rolling averages
        traversalsPerformed++;

        averageTraversalReward +=
                (subTraversalReward - averageTraversalReward)
                        / traversalsPerformed;

        averageTraversalDistance +=
                (subTraversalDistance - averageTraversalDistance)
                        / traversalsPerformed;
    }
}
