package io.swagger.api.impl.routing.routeplan;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by Robert.Sharp on 22/08/2016.
 */
public class Route<T extends VertexWithReward> implements Iterable<RouteEntry<T>> {

    private ArrayList<RouteEntry<T>> path;
    private double rewardSoFar;
    private double distanceSoFar;

    public Route() {
        this.path = new ArrayList<>();
    }

    public int size() {
        return path.size();
    }

    public void writePathToCsv(String filename)
            throws FileNotFoundException, UnsupportedEncodingException {

        //FOR DEBUGGING/TESTING

        PrintWriter writer = new PrintWriter(filename, "UTF-8");

        writer.println("lat,lng,travel_time,reward");

        for(RouteEntry entry : path) {

            writer.println(entry.getVertex().toString()
                    + "," + entry.getTravelTimeToVertex()
                    + "," + entry.getVertex().getReward());
        }

        writer.close();
    }

    public void add(RouteEntry<T> routeEntry) {
        this.path.add(routeEntry);
        this.rewardSoFar += routeEntry.getVertex().getReward();
        this.distanceSoFar += routeEntry.getTravelTimeToVertex();
    }

    public double getRewardSoFar() {
        return rewardSoFar;
    }

    public double getTravelTime() {
        return distanceSoFar;
    }

    public void incrementMetricsForTerminalTruncatedSubTree(
            float averageTraversalReward, float averageTraversalDistance) {
        rewardSoFar += averageTraversalReward;
        distanceSoFar += averageTraversalDistance;
    }

    @Override
    public Iterator<RouteEntry<T>> iterator() {
        return path.iterator();
    }
}
