package io.swagger.api.impl.routing.routeplan;

/**
 * Created by Robert.Sharp on 22/08/2016.
 */
public interface VertexWithReward extends Vertex {

    /***
     * Returns the reward of this Vertex, where a larger reward indicates
     * that route planners should prioritise this Vertex
     * @return
     */
    double getReward();
}
