package io.swagger.api.impl.routing.routeplan.mcts;

import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;
import io.swagger.api.impl.routing.routeplan.nearestneighbours.VertexNearestNeighbourLookup;

import java.util.ArrayList;

/**
 * Created by rob on 8/09/16.
 */
public class TraversalShared<T extends VertexWithReward> {

    private final RouteTimingConfig routeTimingConfig;
    private final T startEndVertex;
    private final ArrayList<T> allVertices;
    private final VertexNearestNeighbourLookup<T> nearestNeighbourLookup;

    public TraversalShared(RouteTimingConfig routeTimingConfig,
                           T startEndVertex,
                           ArrayList<T> allVertices,
                           VertexNearestNeighbourLookup<T> nearestNeighbourLookup) {
        this.routeTimingConfig = routeTimingConfig;
        this.startEndVertex = startEndVertex;
        this.allVertices = allVertices;
        this.nearestNeighbourLookup = nearestNeighbourLookup;
    }

    public RouteTimingConfig getRouteTimingConfig() {
        return routeTimingConfig;
    }

    public T getStartEndVertex() {
        return startEndVertex;
    }

    public ArrayList<T> getAllVertices() {
        return allVertices;
    }

    public VertexNearestNeighbourLookup<T> getNearestNeighbourLookup() {
        return nearestNeighbourLookup;
    }
}
