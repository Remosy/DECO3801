package io.swagger.api.impl.routing.routeplan.dp;
import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteEntry;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Kai on 10/3/2016.
 */
public class DPRoutePlanner {

    ///Note: the timeFrame is sensitive to the precision and max route scale,
    // which in turn determines the size of arrays
    private static int PRECISION = 10;

    public static <T extends VertexWithReward> Route planRoute(
            T startEndVertex,
            ArrayList<T> allVertices,
            RouteTimingConfig routeTimingConfig) {

        //we need the start/end in allVertices, recreate the list with it
        // included
        allVertices = new ArrayList<>(allVertices);
        allVertices.add(startEndVertex);

        int size = allVertices.size();
        int timeFrame = (int)Math.ceil(routeTimingConfig.getMaxRouteTime() * PRECISION);
        State[][] states = new State[timeFrame][size];
        for (int i = 0; i < timeFrame; i++) {
            for (int j =0; j < size; j++) {
                states[i][j] = null;
            }
        }
        int start = allVertices.indexOf(startEndVertex);
        states[0][start] = new State();
        states[0][start].visited.add(startEndVertex);
        states[0][start].totalReward = startEndVertex.getReward();
        states[0][start].currentVertex = startEndVertex;
        for (int i = 0; i < timeFrame; i++) {
            for (int j = 0; j < size; j++) {
                int maxIndex = -1;
                Double maxReward = 0.0;
                int framesBack = 0;
                VertexWithReward v2 = allVertices.get(j);
                if (v2.getReward() != 0) {
                    for (int k = 0; k < size; k++) {
                        if (j != k) {
                            VertexWithReward v1 = allVertices.get(k);
                            int frames = (int) Math.ceil((v1.travelTimeTo(v2) + routeTimingConfig.getVertexVisitTime()) * PRECISION);
                            if (i - frames >= 0) {
                                if (states[i - frames][k] != null &&
                                        !states[i - frames][k].visited.contains(allVertices.get(j))) {
                                    double reward = states[i - frames][k].totalReward + v2.getReward();
                                    if (reward > maxReward) {
                                        maxReward = reward;
                                        maxIndex = k;
                                        framesBack = frames;
                                    }
                                }
                            }
                        }
                    }
                    if (maxIndex != -1) {
                        states[i][j] = new State(states[i - framesBack][maxIndex], allVertices.get(maxIndex));
                    }
                }
            }
        }
        State maxState = new State();
        for (int i = 0; i < timeFrame; i++) {
            for (int j = 0; j < size; j++) {
                int framesBack = (int) Math.ceil(allVertices.get(start).travelTimeTo(allVertices.get(j)) * PRECISION);
                if (i - framesBack >= 0) {
                    if (states[i - framesBack][j] != null &&
                            states[i - framesBack][j].totalReward > maxState.totalReward) {
                        maxState = states[i - framesBack][j];
                    }
                }
            }
        }
        System.out.println(maxState.totalReward);
        List<VertexWithReward> vertexStack = new ArrayList<VertexWithReward>();
        State currentState = maxState;
        while (currentState != null) {
            vertexStack.add(currentState.currentVertex);
            currentState = currentState.previous;
        }
        Route route = new Route();
        for (int i = vertexStack.size() - 2; i > 0; i--) {
            RouteEntry entry =
                    new RouteEntry(
                            vertexStack.get(i).travelTimeTo(vertexStack.get(i + 1)),
                            vertexStack.get(i),
                            RouteEntry.VertexSelectionMethod.DP);
            route.add(entry);
        }
        return route;
    }

    private static class State {
        public Set<VertexWithReward> visited;
        public double totalReward;
        public State previous;
        public VertexWithReward currentVertex;

        public State() {
            visited = new HashSet<VertexWithReward>();
            totalReward = 0.0;
            previous = null;
            currentVertex = null;
        }

        public State(
                State prevState,
                VertexWithReward newVertex) {
            visited = new HashSet<VertexWithReward>();
            visited.addAll(prevState.visited);
            visited.add(newVertex);
            totalReward = prevState.totalReward + newVertex.getReward();
            previous = prevState;
            currentVertex = newVertex;
        }
    }

}
