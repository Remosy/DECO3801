package io.swagger.api.impl.prediction;

import io.swagger.model.MediaWithTimestampedAmounts;
import io.swagger.model.TimestampedMediaAmount;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by rob on 22/10/16.
 */
public class NaiveAveragePredictionTest {

    @Test
    public void testAverageConsumptionSpread() {

        //create two fake media types with daily averages
        Map<String, Integer> fakeMediaWithAvgs = new HashMap<>();
        fakeMediaWithAvgs.put("Media1", 50);
        fakeMediaWithAvgs.put("Media2", 20);

        //create lookahead days in a range that's 3 days long
        List<DateTime> lookAheadDays =
                NaiveAveragePrediction.createDailyTimestamps(
                        new DateTime(), new DateTime().plusDays(2));

        List<MediaWithTimestampedAmounts> averageAmountsSpreadOverDays =
                NaiveAveragePrediction.spreadAverageMediaConsumptionAcrossDays(
                        fakeMediaWithAvgs, lookAheadDays);

        //both media types should be represented, with 3 day entries, each
        // having the same average consumption per the above values
        boolean media1Correct = false;
        boolean media2Correct = false;

        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts :
                averageAmountsSpreadOverDays) {

            switch (mediaWithTimestampedAmounts.getMediaType()) {
                case "Media1":
                    if(media1Correct) { Assert.fail("duplicate media entry"); }
                    media1Correct = 3 == mediaWithTimestampedAmounts.getAmounts().size();
                    assertAmounts(mediaWithTimestampedAmounts.getAmounts(), 50);
                    break;
                case "Media2":
                    if(media2Correct) { Assert.fail("duplicate media entry"); }
                    media2Correct = 3 == mediaWithTimestampedAmounts.getAmounts().size();
                    assertAmounts(mediaWithTimestampedAmounts.getAmounts(), 20);
                    break;
                default:
                    Assert.fail("Got unexpected media type - cosmic rays?");
            }
        }

        Assert.assertTrue("Missing media or number of entries incorrect", media1Correct);
        Assert.assertTrue("Missing media or number of entries incorrect", media2Correct);
    }

    private void assertAmounts(
            List<TimestampedMediaAmount> amounts,
            int expectedAmt) {

        for(TimestampedMediaAmount amount : amounts) {
            Assert.assertEquals("Average media consumption amount not expected",
                    (int)amount.getAmount(), expectedAmt);
        }
    }
}
