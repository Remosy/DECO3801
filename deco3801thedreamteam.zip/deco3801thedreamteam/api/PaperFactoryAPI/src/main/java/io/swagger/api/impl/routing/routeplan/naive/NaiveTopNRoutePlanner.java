package io.swagger.api.impl.routing.routeplan.naive;

import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteEntry;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/**
 * Created by rob on 3/10/16.
 */
public class NaiveTopNRoutePlanner {

    public static <T extends VertexWithReward> Route planRoute(
            T startEndVertex,
            ArrayList<T> allVertices,
            RouteTimingConfig routeTimingConfig) {

        Collections.sort(allVertices, new Comparator<T>() {
            @Override
            public int compare(T v1, T v2) {
                Double d1 = v1.getReward();
                Double d2 = v2.getReward();

                //reverse sort order so we get descending by reward (highest
                // first)
                return d2.compareTo(d1);
            }
        });

        Route<T> route = new Route<>();

        //go through vertices calculating travel and visit distance, and
        // stop when we can't go any further
        Iterator<T> vertexIter = allVertices.iterator();
        double travelTimeUsed = 0;
        T previous = startEndVertex;
        while(vertexIter.hasNext()) {

            T visiting = vertexIter.next();

            //get travel time if we visit it, without the return time
            double travelTimeFromPrevious = previous.travelTimeTo(visiting);
            double travelTimeBeforeReturn =
                    travelTimeUsed +
                    routeTimingConfig.getVertexVisitTime() +
                    travelTimeFromPrevious;

            //now calc total travel time with return to start
            double travelTimeWithReturn =
                    travelTimeBeforeReturn +
                    visiting.travelTimeTo(startEndVertex);

            if(travelTimeWithReturn > routeTimingConfig.getMaxRouteTime()) {
                break; //can't visit - outside route time limit
            }

            //visit - so new travel time is visit to this vertex, and
            // it's the new previous
            travelTimeUsed = travelTimeBeforeReturn;
            previous = visiting;
            route.add(
                    new RouteEntry<>(
                            travelTimeFromPrevious,
                            visiting,
                            RouteEntry.VertexSelectionMethod.NAIVE_TOP_N));

        }

        return route;
    }
}
