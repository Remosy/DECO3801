package io.swagger.api.impl.routing.test;

import io.swagger.api.impl.routing.EuclideanVertex2DWithReward;
import io.swagger.api.impl.routing.routeplan.RoutingScenario;

/**
 * Created by Robert.Sharp on 13/09/2016.
 *
 * Parses routing scenarios (test instances) for the route planner. The format
 * is based on a format used by a number of Orienteering problem test instances
 * that have been published alongside different papers.
 *
 * From here: http://www.mech.kuleuven.be/en/cib/op#section-2
 *
 * The first line contains the following data:

 Tmax P

 Where
 Tmax 	= available time budget per path
 P	= number of paths (=1)


 The remaining lines contain the data of each point.
 For each point, the line contains the following data:

 x y S

 Where
 x	= x coordinate
 y	= y coordinate
 S	= score

 * REMARKS *
 - The first point is the starting point.
 - The second point is the ending point.
 - The Euclidian distance is used.
 */
public class RoutingScenarioParser {

    public static RoutingScenario<EuclideanVertex2DWithReward> readRoutingScenario(
            String fileName) {
        return null; //TODO
    }

}
