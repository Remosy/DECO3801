package io.swagger.api.impl.ranking;

import io.swagger.model.TimestampedMediaAmount;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rob on 22/10/16.
 */
public class DecayRankerTest {

    /***
     * Tests that if the predicted printer levels have no unsatisfied (less
     * than zero) amounts, the calculated unsatisfied consumption level is
     * zero.
     */
    @Test
    public void testNoUnsatisfiedConsumption() {

        List<TimestampedMediaAmount> predictedPaperLevels =
                new ArrayList<>();
        predictedPaperLevels.add(
                new TimestampedMediaAmount().amount(100).timestamp(
                        new DateTime()));
        predictedPaperLevels.add(
                new TimestampedMediaAmount().amount(90).timestamp(
                        new DateTime().plusDays(1)));
        predictedPaperLevels.add(
                new TimestampedMediaAmount().amount(70).timestamp(
                        new DateTime().plusDays(2)));

        Assert.assertEquals("No unsatisfied consumption should yield 0 rank", 0.0,
                PredictionWindowDecayRanker.calcUnsatisfiedMediaConsumption(predictedPaperLevels),
                0);
    }

    /***
     * Tests that a printer A with more unsatisfied consumption than a printer
     * B has a higher rank/reward
     */
    @Test
    public void testUnsatisfiedConsumptionRelationship() {

        List<TimestampedMediaAmount> highlyUnsatisfiedPrinter =
                new ArrayList<>();
        highlyUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-20).timestamp(
                        new DateTime()));
        highlyUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-90).timestamp(
                        new DateTime().plusDays(1)));
        highlyUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-70).timestamp(
                        new DateTime().plusDays(2)));

        List<TimestampedMediaAmount> lessUnsatisfiedPrinter =
                new ArrayList<>();
        lessUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-20).timestamp(
                        new DateTime()));
        lessUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-80).timestamp(
                        new DateTime().plusDays(1)));
        lessUnsatisfiedPrinter.add(
                new TimestampedMediaAmount().amount(-70).timestamp(
                        new DateTime().plusDays(2)));

        double highlyUnsatisfiedRank =
                PredictionWindowDecayRanker.calcUnsatisfiedMediaConsumption(
                        highlyUnsatisfiedPrinter);

        double lessUnsatisfiedRank =
                PredictionWindowDecayRanker.calcUnsatisfiedMediaConsumption(
                        lessUnsatisfiedPrinter);

        Assert.assertTrue(
                "Printer with most unsatisfied consumption should have higher rank",
                highlyUnsatisfiedRank > lessUnsatisfiedRank);
    }
}
