package io.swagger.api.impl.prediction;

import io.swagger.api.impl.dao.mysql.PrinterDb;
import io.swagger.model.MediaWithTimestampedAmounts;
import io.swagger.model.TimestampedMediaAmount;
import org.joda.time.DateTime;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Robert.Sharp on 4/09/2016.
 *
 * Predicts daily media levels based on a consumption prediction and the last
 * recorded media levels
 */
public class LevelsPredictor {

    private PrinterDb printerDb;
    private ConsumptionPredictor consumptionPredictor;

    public LevelsPredictor(PrinterDb printerDb,
                           ConsumptionPredictor consumptionPredictor) {
        this.printerDb = printerDb;
        this.consumptionPredictor = consumptionPredictor;
    }

    public List<MediaWithTimestampedAmounts> predictFutureLevels(
            int lookAheadDays,
            int printerId,
            boolean projectBelowZero) throws SQLException {

        //predict consumption
        List<MediaWithTimestampedAmounts> consumptionPrediction =
                consumptionPredictor.predictFutureConsumptionPerDay(
                        lookAheadDays, printerId);

        //get latest levels
        List<MediaWithTimestampedAmounts> latestMediaLevels =
                printerDb.getLatestMediaLevels(printerId);

        List<MediaWithTimestampedAmounts> resultingLevelsPredictions =
                new ArrayList<>();

        //project levels forward based on consumption predictions
        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts
                : latestMediaLevels) {

            String mediaType = mediaWithTimestampedAmounts.getMediaType();
            MediaWithTimestampedAmounts consumption =
                    getByMediaType(consumptionPrediction, mediaType);

            //if no consumption of this media, just return an empty set of lvls
            if(mediaWithTimestampedAmounts.getAmounts().size() == 0) {
                MediaWithTimestampedAmounts thisMediaWithProjectedLevels =
                        new MediaWithTimestampedAmounts();
                thisMediaWithProjectedLevels.setMediaType(mediaType);
                thisMediaWithProjectedLevels.setAmounts(new ArrayList<TimestampedMediaAmount>(0));
                resultingLevelsPredictions.add(thisMediaWithProjectedLevels);
                continue;
            }

            //should be exactly one amount
            Integer startingLevel =
                    mediaWithTimestampedAmounts.getAmounts().get(0).getAmount();

            List<TimestampedMediaAmount> projected =
                    projectLevelsForward(
                            startingLevel, consumption, projectBelowZero);

            MediaWithTimestampedAmounts thisMediaWithProjectedLevels =
                    new MediaWithTimestampedAmounts();
            thisMediaWithProjectedLevels.setMediaType(mediaType);
            thisMediaWithProjectedLevels.setAmounts(projected);
            resultingLevelsPredictions.add(thisMediaWithProjectedLevels);
        }

        return resultingLevelsPredictions;
    }

    private List<TimestampedMediaAmount> projectLevelsForward(
            Integer startingLevel,
            MediaWithTimestampedAmounts consumption,
            boolean projectBelowZero) {

        List<TimestampedMediaAmount> projectedLevels =
                new ArrayList<>();

        int currentLevel = startingLevel;
        for(TimestampedMediaAmount consumptionInstant
                : consumption.getAmounts()) {

            //adjust level based on whether we are projecting below zero
            int consumptionAmt = consumptionInstant.getAmount();
            if(projectBelowZero) {
                currentLevel -= consumptionAmt;
            } else {
                currentLevel = Math.max(0, currentLevel - consumptionAmt);
            }

            TimestampedMediaAmount levelAfterConsumption =
                    new TimestampedMediaAmount();
            levelAfterConsumption.setTimestamp(
                    consumptionInstant.getTimestamp());
            levelAfterConsumption.setAmount(currentLevel);
            projectedLevels.add(levelAfterConsumption);
        }

        return projectedLevels;
    }

    private MediaWithTimestampedAmounts getByMediaType(
            List<MediaWithTimestampedAmounts> consumptionPrediction,
            String mediaType) {
        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts
                : consumptionPrediction) {
            if(mediaType.equals(mediaWithTimestampedAmounts.getMediaType())) {
                return mediaWithTimestampedAmounts;
            }
        }

        throw new RuntimeException("getByMediaType: Media type not found");
    }
}
