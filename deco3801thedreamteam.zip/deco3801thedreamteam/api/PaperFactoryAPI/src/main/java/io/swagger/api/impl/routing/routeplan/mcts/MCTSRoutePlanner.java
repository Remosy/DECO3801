package io.swagger.api.impl.routing.routeplan.mcts;

import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RoutingScenario;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;
import io.swagger.api.impl.routing.routeplan.nearestneighbours.InMemoryRewardPerDistanceNearestNeighbour;
import io.swagger.api.impl.routing.routeplan.nearestneighbours.VertexNearestNeighbourLookup;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Created by rob on 27/08/16.
 *
 * Performs MCTS/UCT route planning given a vertex that defines a reward
 * and distance metric.
 */
public class MCTSRoutePlanner {

    private static final boolean SAVE_TRAVERSAL_ROUTE_REWARDS = false;

    public static <T extends VertexWithReward> Route<T> planRoute(
            T startEndVertex,
            ArrayList<T> allVertices,
            RouteTimingConfig routeTimingConfig,
            int allowedComputeTimeMilliSeconds) throws FileNotFoundException {

        //make the problem easier - remove vertices with no reward!
        ArrayList<T> allVerticesWithReward = new ArrayList<>();
        for(T vertex : allVertices) {
            if(vertex.getReward() > 0.0) {
                allVerticesWithReward.add(vertex);
            }
        }

        //we have a limited computation time, so timestamp it first
        long startTimeMillis = System.currentTimeMillis();

        //setup precompute for NxN nearest neighbours sort
        // [ O(n log n) time, O(n^2) space ]
        VertexNearestNeighbourLookup<T> nearestNeighbourLookup
                = new InMemoryRewardPerDistanceNearestNeighbour<>(
                        allVerticesWithReward);

        TraversalShared<T> traversalShared =
                new TraversalShared<T>(
                        routeTimingConfig,
                        startEndVertex,
                        allVerticesWithReward,
                        nearestNeighbourLookup);

        //////// START TRAVERSAL

        TraversalState<T> root = new TraversalState<>(
                traversalShared, startEndVertex);

        //keep track of best route generated so far
        double currentBestPlayoutReward = Double.NEGATIVE_INFINITY;
        double currentShortestTravelTime = Double.POSITIVE_INFINITY;
        Route currentBestRoute = null;

        PrintWriter routeRewardsFileWriter;
        if(SAVE_TRAVERSAL_ROUTE_REWARDS) {
            routeRewardsFileWriter =
                    new PrintWriter("traversal_route_rewards.csv");
        }

        //compute for as long as allowed
        long elapsed = 0;
        long totalTraversals = 0;
        do {

            //on each monte carlo step we generate a route - if it's the best
            // route we've had so far, we store it.
            Route route = new Route();

            //do monte carlo to build MCTS tree
            root.singleMonteCarloTraversal(
                    0, //timeSpentAlready
                    new HashSet<T>(), //alreadyVisited
                    route);

            double reward = route.getRewardSoFar();
            double travelTime = route.getTravelTime();

            totalTraversals++;

            if(SAVE_TRAVERSAL_ROUTE_REWARDS) {
                routeRewardsFileWriter.println(reward);
            }

            //store time elapsed so far
            elapsed = System.currentTimeMillis() - startTimeMillis;

            //we get propagated precision issues with the reward accumulation,
            // so to avoid overriding lower travel time routes for the same
            // set of vertices, we only accept a new best route if it's a
            // significant (at least 1%) improvement of route reward

            double rewardChange = reward / currentBestPlayoutReward;

            boolean significantRouteRewardImprovement =
                    rewardChange >= 1.01;

            boolean routeWithinSamenessErrorDelta =
                    rewardChange > 0.99
                    && rewardChange < 1.01;

            if(significantRouteRewardImprovement
                    || currentBestPlayoutReward == Double.NEGATIVE_INFINITY) {

                currentBestRoute = route;
                currentBestPlayoutReward = reward;
                currentShortestTravelTime = travelTime;

                //output time elapsed vs reward, so we can keep track of
                // convergence
                System.out.println("New best route - elapsed (ms): " + elapsed + ", traversals: " + totalTraversals + ", route reward: " + reward + ", travel time: " + currentShortestTravelTime);
            } else if (routeWithinSamenessErrorDelta
                    && travelTime < currentShortestTravelTime) {

                //got new route with same reward but shorter total travel time
                // - use it instead
                currentBestRoute = route;
                currentShortestTravelTime = travelTime;

                System.out.println("New shorter route - elapsed (ms): " + elapsed + ", traversals: " + totalTraversals + ", route reward: " + reward + ", travel time: " + currentShortestTravelTime);
            }

            //if fully explored, we can stop so we don't waste computation time
            if(root.isFullyExplored()) {
                break;
            }

        } while (elapsed < allowedComputeTimeMilliSeconds);

        if(SAVE_TRAVERSAL_ROUTE_REWARDS) {
            routeRewardsFileWriter.close();
        }

        return currentBestRoute;
    }
}
