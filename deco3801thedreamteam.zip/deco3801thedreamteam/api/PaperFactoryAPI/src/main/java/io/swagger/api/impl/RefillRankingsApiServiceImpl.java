package io.swagger.api.impl;

import io.swagger.api.*;

import io.swagger.model.PrinterWithReward;

import java.sql.SQLException;
import java.util.*;

import io.swagger.api.NotFoundException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import static io.swagger.api.impl.ApiImplShared.*;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class RefillRankingsApiServiceImpl extends RefillRankingsApiService {

    @Override
    public Response refillRankingsGet(SecurityContext securityContext)
            throws NotFoundException {

        try {

            List<PrinterWithReward> printersWithRanking =
                    printerRanker.getPrintersWithReward();

            //order these by reward
            Collections.sort(printersWithRanking,
                    new Comparator<PrinterWithReward>() {
                @Override
                public int compare(
                        PrinterWithReward pr1,
                        PrinterWithReward pr2) {

                    Double rank1 = pr1.getReward();
                    Double rank2 = pr2.getReward();

                    //rank descending order
                    return rank2.compareTo(rank1);
                }
            });

            return Response.ok()
                    .entity(printersWithRanking)
                    .build();

        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }
}
