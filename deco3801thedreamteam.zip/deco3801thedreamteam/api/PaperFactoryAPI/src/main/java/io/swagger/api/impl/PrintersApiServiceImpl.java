package io.swagger.api.impl;

import io.swagger.api.*;

import io.swagger.model.MediaAndCapacity;
import java.math.BigDecimal;
import io.swagger.model.MediaWithTimestampedAmounts;

import java.sql.SQLException;

import java.util.List;
import io.swagger.api.NotFoundException;

import org.joda.time.DateTime;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import static io.swagger.api.impl.ApiImplShared.*;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PrintersApiServiceImpl extends PrintersApiService {

    @Override
    public Response printersListGet(
            SecurityContext securityContext) throws NotFoundException {

        try {
            return Response.ok()
                    .entity(printerDb.getAllPrinters())
                    .build();
        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }

    @Override
    public Response printersPrinterIdMediaCapacitiesGet(
            BigDecimal printerId,
            SecurityContext securityContext) throws NotFoundException {

        try {
            return Response.ok()
                    .entity(printerDb.getMediaCapacities(
                            printerId.intValue()))
                    .build();
        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }

    @Override
    public Response printersPrinterIdMediaConsumptionGet(
            BigDecimal printerId,
            DateTime startDate,
            DateTime endDate,
            SecurityContext securityContext) throws NotFoundException {

        try {

            DateTime latestDataTimestampMidnight =
                    printerDb.getLastPrinterDataTimestamp(printerId.intValue())
                            .withTimeAtStartOfDay();

            //if no start date, use 7 days from last data point
            if(startDate == null) {
                startDate = latestDataTimestampMidnight.minusDays(7);
            }

            //if no end date, use midnight on last data point day
            if(endDate == null) {
                endDate = latestDataTimestampMidnight;
            }

            //TODO: note that the printer consumption information is currently
            // based on non-filtered data - we'll need to fix this.
            return Response.ok()
                    .entity(printerDb.getMediaConsumptionPerDay(
                            printerId.intValue(), startDate, endDate))
                    .build();
        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }

    @Override
    public Response printersPrinterIdMediaConsumptionPredictedGet(
            BigDecimal printerId,
            BigDecimal lookAheadDays,
            SecurityContext securityContext) throws NotFoundException {

        try {

            //default 7 look ahead days
            int lookAheadDaysInt = 7;
            if(lookAheadDays != null) {
                lookAheadDaysInt = lookAheadDays.intValue();
            }

            int printerIdInt = printerId.intValue();

            //consumption prediction logic is in the consumptionPredictor
            List<MediaWithTimestampedAmounts> averageAmountsSpread7Days =
                    consumptionPredictor.predictFutureConsumptionPerDay(
                            lookAheadDaysInt, printerIdInt);

            return Response.ok()
                    .entity(averageAmountsSpread7Days)
                    .build();
        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }

    @Override
    public Response printersPrinterIdMediaLevelsGet(
            BigDecimal printerId,
            DateTime startDate,
            DateTime endDate,
            Boolean rawData,
            SecurityContext securityContext) throws NotFoundException {

        //if rawData not set, use filtered data as default
        boolean filteredData;
        if(rawData == null) {
            filteredData = true;
        } else {
            filteredData = !rawData;
        }

        try {
            DateTime latestDataTimestamp =
                    printerDb.getLastPrinterDataTimestamp(printerId.intValue());

            //if no start date, use 7 days before last data timestamp
            if(startDate == null) {
                startDate = latestDataTimestamp.minusDays(7);
            }

            //if no end date, use last data timestamp
            if(endDate == null) {
                endDate = latestDataTimestamp.plusSeconds(1);
            }

            return Response.ok()
                    .entity(printerDb.getMediaLevels(
                            printerId.intValue(), startDate, endDate, filteredData))
                    .build();
        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }

    @Override
    public Response printersPrinterIdMediaLevelsPredictedGet(
            BigDecimal printerId,
            BigDecimal lookAheadDays,
            SecurityContext securityContext) throws NotFoundException {

        try {

            //default 7 look ahead days
            int lookAheadDaysInt = 7;
            if(lookAheadDays != null) {
                lookAheadDaysInt = lookAheadDays.intValue();
            }

            List<MediaWithTimestampedAmounts> predictedLevels =
                    levelsPredictor.predictFutureLevels(
                            lookAheadDaysInt,
                            printerId.intValue(),
                            false);

            return Response.ok()
                    .entity(predictedLevels)
                    .build();

        } catch (SQLException se) {
            return formatErrorResponse(se);
        }
    }

    @Override
    public Response printersPrinterIdMediaTypesGet(
            BigDecimal printerId,
            SecurityContext securityContext) throws NotFoundException {

        //TODO: this is a bit of a hack, maybe improve post MVP
        try {
            List<MediaAndCapacity> mediaAndCapacities =
                    printerDb.getMediaCapacities(printerId.intValue());

            String[] mediaTypes = new String[mediaAndCapacities.size()];
            for(int i = 0; i < mediaAndCapacities.size(); i++) {
                mediaTypes[i] = mediaAndCapacities.get(i).getMediaType();
            }

            return Response.ok().entity(mediaTypes).build();

        } catch (SQLException e) {
            return formatErrorResponse(e);
        }
    }
}
