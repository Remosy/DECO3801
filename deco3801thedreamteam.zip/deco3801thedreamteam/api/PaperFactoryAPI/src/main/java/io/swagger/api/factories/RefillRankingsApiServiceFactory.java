package io.swagger.api.factories;

import io.swagger.api.RefillRankingsApiService;
import io.swagger.api.impl.RefillRankingsApiServiceImpl;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class RefillRankingsApiServiceFactory {
    private final static RefillRankingsApiService service = new RefillRankingsApiServiceImpl();

    public static RefillRankingsApiService getRefillRankingsApi() {
        return service;
    }
}
