package io.swagger.api.impl;

import io.swagger.api.impl.dao.mysql.PrinterDb;
import io.swagger.api.impl.prediction.ConsumptionPredictor;
import io.swagger.api.impl.prediction.LevelsPredictor;
import io.swagger.api.impl.prediction.NaiveAveragePrediction;
import io.swagger.api.impl.ranking.PredictionWindowDecayRanker;
import io.swagger.api.impl.ranking.PrinterRanker;
import io.swagger.model.ErrorResponse;

import javax.ws.rs.core.Response;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

/**
 * Created by robert.sharp on 3/09/2016.
 *
 * Singletons shared across different APIs, and shared methods
 */
public class ApiImplShared {

    static PrinterDb printerDb;
    static ConsumptionPredictor consumptionPredictor;
    static LevelsPredictor levelsPredictor;
    static PrinterRanker printerRanker;

    static {
        try {

            //TODO: move this out into a config parameter
            printerDb = new PrinterDb(
                    "jdbc:mysql://localhost/printer?user=printer&password=printer");

            consumptionPredictor = new NaiveAveragePrediction(printerDb);

            levelsPredictor =
                    new LevelsPredictor(printerDb, consumptionPredictor);

            printerRanker =
                    new PredictionWindowDecayRanker(
                            printerDb, levelsPredictor);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
    }

    public static Response formatErrorResponse(Exception e) {
        ErrorResponse er = new ErrorResponse();
        er.setErrorCode(1);
        er.setUserMessage("Internal Server Error");

        //format stack trace string as the debug message
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        er.setDebugMessage(sw.toString()); // stack trace as a string

        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                .entity(er)
                .build();
    }
}
