package io.swagger.api.impl.routing.routeplan;

/**
 * Created by Robert.Sharp on 22/08/2016.
 */
public class RouteEntry<T extends VertexWithReward> {

    public enum VertexSelectionMethod {
        NEAREST_NEIGHBOUR,
        UPPER_CONFIDENCE_BOUND,
        NAIVE_TOP_N,
        DP,
        ENDPOINT_VERTEX
    }

    private double travelTimeToVertex;
    private T vertex;
    private VertexSelectionMethod vertexSelectionMethod;

    public RouteEntry(double travelTimeToVertex,
                      T vertex,
                      VertexSelectionMethod vertexSelectionMethod) {
        this.travelTimeToVertex = travelTimeToVertex;
        this.vertex = vertex;
        this.vertexSelectionMethod = vertexSelectionMethod;
    }

    public double getTravelTimeToVertex() {
        return travelTimeToVertex;
    }

    public T getVertex() {
        return vertex;
    }

    public VertexSelectionMethod getVertexSelectionMethod() {
        return vertexSelectionMethod;
    }
}
