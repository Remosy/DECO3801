package io.swagger.api.factories;

import io.swagger.api.PrintersApiService;
import io.swagger.api.impl.PrintersApiServiceImpl;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PrintersApiServiceFactory {
    private final static PrintersApiService service = new PrintersApiServiceImpl();

    public static PrintersApiService getPrintersApi() {
        return service;
    }
}
