package io.swagger.api.impl.routing.routeplan.nearestneighbours;

import io.swagger.api.impl.routing.routeplan.Vertex;

import java.util.Iterator;

/**
 * Created by Robert.Sharp on 28/08/2016.
 *
 * An interface implemented by a data structure that allows looking up
 * nearest neighbours of a vertex
 */
public interface VertexNearestNeighbourLookup<T extends Vertex> {

    /***
     * Gets an enumerator that enumerates through the vertices that are near
     * the given vertex
     * @param vertex
     * @return
     */
    public Iterator<T> getNearestNeighbourEnumerator(T vertex);
}
