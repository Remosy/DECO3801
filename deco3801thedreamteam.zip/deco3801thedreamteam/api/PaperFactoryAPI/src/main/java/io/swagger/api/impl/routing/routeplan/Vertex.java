package io.swagger.api.impl.routing.routeplan;

/**
 * Created by Robert.Sharp on 22/08/2016.
 */
public interface Vertex {

    /***
     * The travel time from this Vertex to another Vertex in the graph
     * @param other
     * @return
     */
    double travelTimeTo(Vertex other);
}
