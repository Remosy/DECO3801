package io.swagger.api.impl.routing.routeplan.nearestneighbours;

import io.swagger.api.impl.routing.routeplan.Vertex;
import io.swagger.api.impl.routing.routeplan.VertexWithReward;

import java.util.*;

/**
 * Created by robert.sharp on 17/09/2016.
 *
 * Instead of a true nearest neighbour, returns vertices ordered by reward
 * per distance travelled
 */
public class InMemoryRewardPerDistanceNearestNeighbour<T extends VertexWithReward>
        implements VertexNearestNeighbourLookup<T> {

    private ArrayList<T> otherVerticesToConsider;
    private Map<T, ArrayList<T>> vertexToNearestNeighboursInOrder;

    public InMemoryRewardPerDistanceNearestNeighbour(ArrayList<T> vertices) {
        this.otherVerticesToConsider = vertices;
        buildNeighboursMap();
    }

    private void buildNeighboursMap() {
        this.vertexToNearestNeighboursInOrder =
                new HashMap<>(otherVerticesToConsider.size());

        for(T vertex : otherVerticesToConsider) {
            addNeighboursToMap(vertex);
        }
    }

    private void addNeighboursToMap(T vertex) {
        //create a list copy of all vertices
        ArrayList<T> otherVertices =
                copyWithout(otherVerticesToConsider, vertex);

        //sort new list by neighbour distance to this vertex
        sortByRewardPerDistance(vertex, otherVertices);

        //add to vertex-> ordered neighbours list map
        this.vertexToNearestNeighboursInOrder.put(vertex, otherVertices);
    }

    private void sortByRewardPerDistance(
            final T vertex, ArrayList<T> otherVertices) {

        Collections.sort(otherVertices, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {

                //get distance from our current vertex to either, and compare
                // the distances. this will be executed
                Double rewardPerDistance1 =
                        o1.getReward() / vertex.travelTimeTo(o1);
                Double rewardPerDistance2 =
                        o2.getReward() / vertex.travelTimeTo(o2);

                //reverse (descending) order - we want highest reward per
                // distance first
                return rewardPerDistance2.compareTo(rewardPerDistance1);
            }
        });
    }

    private ArrayList<T> copyWithout(ArrayList<T> list, T exclude) {
        ArrayList<T> newList = new ArrayList<>(list.size() - 1);
        for(T item : list) {
            if(item != exclude) {
                newList.add(item);
            }
        }
        return newList;
    }

    @Override
    public Iterator<T> getNearestNeighbourEnumerator(T vertex) {

        ArrayList<T> nearestNeighbours =
                vertexToNearestNeighboursInOrder.get(vertex);

        if(nearestNeighbours != null) {
            return nearestNeighbours.iterator();
        } else {

            //we haven't seen this vertex yet - so calc distances once and
            // store, but don't add it as a vertex to consider. then go again
            addNeighboursToMap(vertex);
            return getNearestNeighbourEnumerator(vertex);
        }
    }
}

