package io.swagger.api.impl.ranking;

import io.swagger.model.PrinterWithReward;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Robert.Sharp on 4/09/2016.
 */
public interface PrinterRanker {

    double getPrinterReward(int printerId) throws SQLException;

    List<PrinterWithReward> getPrintersWithReward() throws SQLException;
}
