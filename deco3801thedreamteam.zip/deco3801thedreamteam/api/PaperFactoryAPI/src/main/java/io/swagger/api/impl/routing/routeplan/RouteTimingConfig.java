package io.swagger.api.impl.routing.routeplan;

/**
 * Created by rob on 28/08/16.
 */
public class RouteTimingConfig {

    private final double vertexVisitTime;
    private final double maxRouteTime;

    public RouteTimingConfig(double vertexVisitTime, double maxRouteTime) {
        this.vertexVisitTime = vertexVisitTime;
        this.maxRouteTime = maxRouteTime;
    }

    public double getVertexVisitTime() {
        return vertexVisitTime;
    }

    public double getMaxRouteTime() {
        return maxRouteTime;
    }
}
