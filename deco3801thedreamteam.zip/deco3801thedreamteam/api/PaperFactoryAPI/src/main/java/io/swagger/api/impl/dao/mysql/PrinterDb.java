package io.swagger.api.impl.dao.mysql;

import io.swagger.model.*;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import java.sql.*;
import java.sql.Date;
import java.util.*;

/**
 * Created by rob on 1/09/16.
 *
 * General operations on the Db
 */
public class PrinterDb {

    private static final String[] MEDIA_TYPES = {
            "Tray1",
            "Tray2",
            "Tray3",
            "Tray4",
            "TonerBlack",
            "TonerCyan",
            "TonerMagenta",
            "TonerYellow",
            "InkCyan",
            "InkMagenta",
            "InkYellow",
            "InkGray",
            "InkMatteBlack",
            "InkPhotoBlack",
            "HeadGrayPhotoBlack",
            "HeadMatteBlackYellow",
            "HeadMagentaCyan"
    };

    //TODO: right now the 400+ ids are reserved IDs that the previous
    // implementation used to define special starting points
    private static final String PRINTER_IDS_SELECT_SQL =
            "SELECT id, buildingName, printerName, latitude, longitude FROM nodes WHERE id < 400";

    private static final String INVENTORY_RAW_SELECT_SQL =
            "SELECT Stamp AS Timestamp, " +
                    "COALESCE(Tray1, 0) AS Tray1, COALESCE(Tray2, 0) AS Tray2, COALESCE(Tray3, 0) AS Tray3, COALESCE(Tray4, 0) AS Tray4, " +
                    "TonerBlack, TonerCyan, TonerMagenta, TonerYellow, InkCyan, InkMagenta, InkYellow, InkGray, InkMatteBlack, InkPhotoBlack, HeadGrayPhotoBlack, HeadMatteBlackYellow, HeadMagentaCyan " +
                    "FROM snmphistory\n" +
                    "WHERE Printer = ? \n" +
                    "AND Stamp BETWEEN ? AND ? \n" +
                    "ORDER BY Stamp ASC";

    private static final String INVENTORY_FILTERED_SELECT_SQL =
            "SELECT Time AS Timestamp, Level FROM filtered_data " +
                    "WHERE filtered_data.Printer = ? " +
                    "AND Time BETWEEN ? AND ? " +
                    "AND Media = ?" +
                    "ORDER BY Time ASC";

    private static final String INVENTORY_FILTERED_LAST_READING_SELECT_SQL =
            "SELECT Level FROM filtered_data " +
                    "WHERE filtered_data.Printer = ? " +
                    "AND Media = ? " +
                    "ORDER BY Time DESC LIMIT 1";

    private static final String INVENTORY_PREDICTED_SELECT_SQL =
            "SELECT Time AS Timestamp, Level FROM filtered_data " +
                    "WHERE filtered_data.Printer = ? " +
                    "AND Time BETWEEN ? AND ? " +
                    "ORDER BY Time ASC";

    private static final String MEDIA_CAPACITIES_SQL =
            "SELECT MAX(COALESCE(Tray1, 0)) AS Tray1Paper, MAX(COALESCE(Tray2, 0)) AS Tray2Paper, MAX(COALESCE(Tray3, 0)) AS Tray3Paper, MAX(COALESCE(Tray4, 0)) AS Tray4Paper, " +
                    "MAX(TonerBlack) AS TonerBlack, MAX(TonerCyan) AS TonerCyan, MAX(TonerMagenta) AS TonerMagenta, MAX(TonerYellow) AS TonerYellow, MAX(InkCyan) AS InkCyan, MAX(InkMagenta) AS InkMagenta, MAX(InkYellow) AS InkYellow, MAX(InkGray) AS InkGray, MAX(InkMatteBlack) AS InkMatteBlack, MAX(InkPhotoBlack) AS InkPhotoBlack, MAX(HeadGrayPhotoBlack) AS HeadGrayPhotoBlack, MAX(HeadMatteBlackYellow) AS HeadMatteBlackYellow, MAX(HeadMagentaCyan) AS HeadMagentaCyan " +
                    "FROM snmphistory\n" +
                    "WHERE Printer = ? \n";

    private static final String LAST_PRINTER_DATA_TIME_SQL =
            "SELECT MAX(Stamp) FROM snmphistory WHERE Printer = ?";

    private Connection dbCon;
    private final String jdbcConnnectionString;

    public PrinterDb(String jdbcConnnectionString)
            throws ClassNotFoundException, SQLException,
            IllegalAccessException, InstantiationException {
        // The newInstance() call is a work around for some
        // broken Java implementations
        Class.forName("com.mysql.jdbc.Driver").newInstance();

        this.jdbcConnnectionString = jdbcConnnectionString;

        dbCon = DriverManager.getConnection(jdbcConnnectionString);
    }

    /***
     * Gets all printer IDs that are in the DB
     * @return
     */
    public synchronized List<Printer> getAllPrinters() throws SQLException {

        CheckOrResetDbCon();

        ResultSet resultSet =
                dbCon.createStatement().executeQuery(PRINTER_IDS_SELECT_SQL);

        List<Printer> printers = new ArrayList<>();
        while(resultSet.next()) {
            Printer printer = new Printer();
            printer.setPrinterId(resultSet.getInt(1));
            printer.setBuildingName(resultSet.getString(2));
            printer.setPrinterName(resultSet.getString(3));

            Location location = new Location();
            location.setLat(resultSet.getBigDecimal(4));
            location.setLng(resultSet.getBigDecimal(5));
            printer.setLocation(location);

            printers.add(printer);

        }

        return printers;
    }

    /***
     * Checks if the DB connection is still OK, and resets it if required
     * @throws SQLException
     */
    private void CheckOrResetDbCon() throws SQLException {
        if(!dbCon.isValid(1000)) {
            dbCon = DriverManager.getConnection(jdbcConnnectionString);
        }
    }

    /***
     * Gets the timestamp of the latest update for this printer
     * @param printerId
     * @return
     * @throws SQLException
     */
    public synchronized DateTime getLastPrinterDataTimestamp(int printerId)
            throws SQLException {

        CheckOrResetDbCon();

        PreparedStatement stmt =
                dbCon.prepareStatement(LAST_PRINTER_DATA_TIME_SQL);

        stmt.setInt(1, printerId);

        ResultSet rs = stmt.executeQuery();

        //should be exactly one result
        rs.next();

        return fromSqlDate(rs.getTimestamp(1));
    }

    public synchronized List<MediaAndCapacity> getMediaCapacities(int printerId) throws SQLException {

        CheckOrResetDbCon();

        PreparedStatement stmt =
                dbCon.prepareStatement(MEDIA_CAPACITIES_SQL);

        stmt.setInt(1, printerId);

        ResultSet rs = stmt.executeQuery();

        //TODO: this is a bit of a hack. improve after MVP?
        //get nmedia column names and use them as the media
        // type names
        ResultSetMetaData rsMeta = rs.getMetaData();
        String[] mediaColumnNames = new String[rsMeta.getColumnCount()];
        for(int i = 1; i < rsMeta.getColumnCount(); i++) {
            mediaColumnNames[i] = rsMeta.getColumnName(i);
        }

        List<MediaAndCapacity> mediaAndCapacities = new ArrayList<>();

        while(rs.next()) {
            for(int colIdx = 1; colIdx < mediaColumnNames.length; colIdx++) {
                String mediaColName = mediaColumnNames[colIdx];

                int mediaAmount = rs.getInt(colIdx);
                //http://stackoverflow.com/questions/2920364/checking-for-a-null-int-value-from-a-java-resultset
                if(!rs.wasNull()) {
                    MediaAndCapacity mediaAndCapacity = new MediaAndCapacity();
                    mediaAndCapacity.setMediaType(mediaColName);
                    mediaAndCapacity.setCapacity(mediaAmount);
                    mediaAndCapacities.add(mediaAndCapacity);
                }
            }
        }

        rs.close();
        stmt.close();

        return mediaAndCapacities;
    }

    public synchronized List<MediaWithTimestampedAmounts> getMediaLevels(
            int printerId,
            DateTime startDateInclusive,
            DateTime endDateInclusive,
            boolean filtered) throws SQLException {

        CheckOrResetDbCon();

        if(filtered) {
            return getMediaLevelsFiltered(
                    printerId, startDateInclusive, endDateInclusive);
        } else {
            return getMediaLevelsRaw(
                    printerId, startDateInclusive, endDateInclusive);
        }
    }

    private List<MediaWithTimestampedAmounts> getMediaLevelsFiltered(
            int printerId,
            DateTime startDateInclusive,
            DateTime endDateInclusive) throws SQLException {

        //get all media types, then query them to get the media
        // levels for each during the time period - can then be put
        // directly into API return classes
        List<MediaWithTimestampedAmounts> allMediaWithTimestampedAmounts =
                new ArrayList<>();

        //there will be values if the start timestamp is not beyond the last
        // recorded data timestamp in the raw data table. we need to check
        // this because the filtered table just stores value changes p/media
        DateTime lastPrinterDataTimestamp =
                getLastPrinterDataTimestamp(printerId);

        boolean withinMeasurementRange =
                lastPrinterDataTimestamp
                        .compareTo(startDateInclusive) >= 0;

        for(String mediaType : MEDIA_TYPES) {

            PreparedStatement stmt = dbCon.prepareStatement(
                    INVENTORY_FILTERED_SELECT_SQL);

            stmt.setInt(1, printerId);
            stmt.setTimestamp(2, toSqlTimestamp(startDateInclusive));
            stmt.setTimestamp(3, toSqlTimestamp(endDateInclusive));
            stmt.setString(4, mediaType);

            ResultSet rs = stmt.executeQuery();

            List<TimestampedMediaAmount> timestampedMediaAmounts =
                    new ArrayList<>();
            while(rs.next()) {

                DateTime timestamp = fromSqlDate(rs.getTimestamp(1));
                int mediaAmount = rs.getInt(2);

                TimestampedMediaAmount timestampedMediaAmount =
                        new TimestampedMediaAmount();
                timestampedMediaAmount.setTimestamp(timestamp);
                timestampedMediaAmount.setAmount(mediaAmount);

                timestampedMediaAmounts.add(timestampedMediaAmount);
            }

            rs.close();
            stmt.close();

            //since the filtered media levels only includes changes, we
            // might end up with no readings within the time period - in that case
            // we need to get the latest reading for that media type if it exists,
            // and set its timestamp to the start of the period
            if(withinMeasurementRange &&
                    timestampedMediaAmounts.size() == 0) {

                Integer amount =
                        getLastReadingForMediaType(printerId, mediaType);

                if(amount != null) {

                    //set level at start
                    TimestampedMediaAmount precedingMeasurement =
                            new TimestampedMediaAmount();
                    precedingMeasurement.setTimestamp(startDateInclusive.plusSeconds(1));
                    precedingMeasurement.setAmount(amount);

                    timestampedMediaAmounts.add(precedingMeasurement);
                }
            }

            //now append a level at the start of the valid printer data period,
            // so we always have at least two entries (for deltas and charting)
            if(timestampedMediaAmounts.size() > 0) {

                TimestampedMediaAmount currentStart =
                        timestampedMediaAmounts.get(0);

                TimestampedMediaAmount newStart =
                        new TimestampedMediaAmount();
                newStart.setTimestamp(
                        startDateInclusive);
                //amount is same as first entry
                newStart.setAmount(
                        currentStart.getAmount());

                timestampedMediaAmounts.add(0, newStart);
            }

            MediaWithTimestampedAmounts mediaWithTimestampedAmounts =
                    new MediaWithTimestampedAmounts();
            mediaWithTimestampedAmounts.setMediaType(mediaType);
            mediaWithTimestampedAmounts.setAmounts(timestampedMediaAmounts);

            allMediaWithTimestampedAmounts.add(mediaWithTimestampedAmounts);
        }

        return allMediaWithTimestampedAmounts;
    }

    private Integer getLastReadingForMediaType(int printerId, String mediaType)
        throws SQLException {

        PreparedStatement stmt = dbCon.prepareStatement(
                INVENTORY_FILTERED_LAST_READING_SELECT_SQL);

        stmt.setInt(1, printerId);
        stmt.setString(2, mediaType);

        ResultSet rs = stmt.executeQuery();

        if(!rs.next()) {
            return null; //no reading for media type, ever
        }

        return rs.getInt(1);
    }

    private List<MediaWithTimestampedAmounts> getMediaLevelsRaw(
            int printerId,
            DateTime startDateInclusive,
            DateTime endDateInclusive) throws SQLException {

        PreparedStatement stmt = dbCon.prepareStatement(
                INVENTORY_RAW_SELECT_SQL);

        stmt.setInt(1, printerId);
        stmt.setTimestamp(2, toSqlTimestamp(startDateInclusive));
        stmt.setTimestamp(3, toSqlTimestamp(endDateInclusive));

        ResultSet rs = stmt.executeQuery();

        //TODO: this is a bit of a hack. improve after MVP?
        //get non-timestamp media column names and use them as the media
        // type names
        ResultSetMetaData rsMeta = rs.getMetaData();
        String[] mediaColumnNames = new String[rsMeta.getColumnCount()];
        for (int i = 2; i < rsMeta.getColumnCount(); i++) {
            mediaColumnNames[i] = rsMeta.getColumnName(i);
        }

        //we only store lists where that media type was actually available
        // for the given printer (so not all nulls in the media column)
        Map<String, List<TimestampedMediaAmount>> mediaTypeToAmounts =
                new HashMap<>();

        //get timestamped media amounts into the map
        while (rs.next()) {
            DateTime timestamp = fromSqlDate(rs.getTimestamp(1));

            for (int colIdx = 2; colIdx < mediaColumnNames.length; colIdx++) {
                String mediaColName = mediaColumnNames[colIdx];

                int mediaAmount = rs.getInt(colIdx);
                //http://stackoverflow.com/questions/2920364/checking-for-a-null-int-value-from-a-java-resultset
                if (!rs.wasNull()) {

                    //we got a new timestamped media level - store it
                    List<TimestampedMediaAmount> mediaLevelsThisMediaType;

                    if (mediaTypeToAmounts.containsKey(mediaColName)) {
                        mediaLevelsThisMediaType =
                                mediaTypeToAmounts.get(mediaColName);
                    } else {
                        mediaLevelsThisMediaType = new ArrayList<>();
                        mediaTypeToAmounts.put(
                                mediaColName, mediaLevelsThisMediaType);
                    }

                    TimestampedMediaAmount timestampedMediaAmount =
                            new TimestampedMediaAmount();
                    timestampedMediaAmount.setTimestamp(timestamp);
                    timestampedMediaAmount.setAmount(mediaAmount);

                    mediaLevelsThisMediaType.add(timestampedMediaAmount);
                }
            }
        }

        rs.close();
        stmt.close();

        //create model type from map for all media types we got amounts for
        List<MediaWithTimestampedAmounts> mediaWithTimestampedAmounts =
                new ArrayList<>();

        for (Map.Entry<String, List<TimestampedMediaAmount>> pair
                : mediaTypeToAmounts.entrySet()) {

            MediaWithTimestampedAmounts thisMediaTimestampedAmounts =
                    new MediaWithTimestampedAmounts();
            thisMediaTimestampedAmounts.setMediaType(pair.getKey());
            thisMediaTimestampedAmounts.setAmounts(pair.getValue());

            mediaWithTimestampedAmounts.add(thisMediaTimestampedAmounts);
        }

        return mediaWithTimestampedAmounts;
    }

    public synchronized List<MediaWithTimestampedAmounts> getMediaConsumption(
            int printerId,
            DateTime startDateInclusive,
            DateTime endDateInclusive) throws SQLException {

        //we're going to get the levels first, then we'll calculate the
        // consumption figures based on cumulative deltas
        List<MediaWithTimestampedAmounts> mediaLevels =
                getMediaLevels(printerId, startDateInclusive, endDateInclusive,
                        true); //media consumption always uses filtered data

        List<MediaWithTimestampedAmounts> mediaConsumptionResult =
                new ArrayList<>();

        //go through each media type
        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts
                : mediaLevels) {

            List<TimestampedMediaAmount> levelAmounts =
                    mediaWithTimestampedAmounts.getAmounts();

            List<TimestampedMediaAmount> thisMediaConsumptionAmounts =
                    getConsumptionDeltas(levelAmounts);

            MediaWithTimestampedAmounts consumptionThisMedia =
                    new MediaWithTimestampedAmounts();
            consumptionThisMedia.setMediaType(mediaWithTimestampedAmounts.getMediaType());
            consumptionThisMedia.setAmounts(thisMediaConsumptionAmounts);
            mediaConsumptionResult.add(consumptionThisMedia);
        }

        return mediaConsumptionResult;
    }

    private static List<TimestampedMediaAmount> getConsumptionDeltas(
            List<TimestampedMediaAmount> levelAmounts) {

        List<TimestampedMediaAmount> thisMediaConsumptionAmounts =
                new ArrayList<>();

        //if only one record in time period, no delta - just return 0
        if(levelAmounts.size() == 1) {
            TimestampedMediaAmount zeroConsumptionAmt =
                new TimestampedMediaAmount();
            zeroConsumptionAmt.setTimestamp(
                    levelAmounts.get(0).getTimestamp());
            zeroConsumptionAmt.setAmount(0);
            thisMediaConsumptionAmounts.add(zeroConsumptionAmt);
            return thisMediaConsumptionAmounts;
        }

        //keep track of the last level for delta
        int lastLevel = 0;

        //go through each level
        for(TimestampedMediaAmount timestampedMediaAmount : levelAmounts) {

            //calculate consumption as delta from last
            int levelDelta =
                    lastLevel - timestampedMediaAmount.getAmount();

            //store for next iteration
            lastLevel = timestampedMediaAmount.getAmount();

            //only keep consumption or no change (0) deltas
            if(levelDelta >= 0) {
                TimestampedMediaAmount consumptionAmount =
                        new TimestampedMediaAmount();
                consumptionAmount.setAmount(levelDelta);
                consumptionAmount.setTimestamp(
                        timestampedMediaAmount.getTimestamp());
                thisMediaConsumptionAmounts.add(consumptionAmount);
            }
        }
        return thisMediaConsumptionAmounts;
    }

    public synchronized List<MediaWithTimestampedAmounts> getMediaConsumptionPerDay(
            int printerId,
            DateTime startDateInclusive,
            DateTime endDateInclusive) throws SQLException {

        List<MediaWithTimestampedAmounts> mediaConsumption =
                getMediaConsumption(
                        printerId, startDateInclusive, endDateInclusive);

        List<MediaWithTimestampedAmounts> accumulatedByDayPerMedia =
                new ArrayList<>();

        //go through each media type and group per day
        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts
            : mediaConsumption) {

            //group and sum per day
            List<TimestampedMediaAmount> accumulatedByDay =
                    accumulateByDay(
                            mediaWithTimestampedAmounts.getAmounts());

            MediaWithTimestampedAmounts accumulatedMedia =
                    new MediaWithTimestampedAmounts();
            accumulatedMedia.setMediaType(
                    mediaWithTimestampedAmounts.getMediaType());
            accumulatedMedia.setAmounts(accumulatedByDay);
            accumulatedByDayPerMedia.add(accumulatedMedia);
        }

        return accumulatedByDayPerMedia;
    }

    private static List<TimestampedMediaAmount> accumulateByDay(
            List<TimestampedMediaAmount> amounts) {

        LinkedHashMap<LocalDate, List<TimestampedMediaAmount>> groupedByDay =
                groupByDay(amounts);

        //sum by day
        List<TimestampedMediaAmount> accumulatedByDay =
                new ArrayList<>(groupedByDay.size());

        for(Map.Entry<LocalDate, List<TimestampedMediaAmount>> pair
                : groupedByDay.entrySet()) {

            int accumulatedAmount = 0;
            for(TimestampedMediaAmount timestampedMediaAmount
                    : pair.getValue()) {
                accumulatedAmount += timestampedMediaAmount.getAmount();
            }

            TimestampedMediaAmount groupedByDayTimestampedAmount =
                    new TimestampedMediaAmount();
            groupedByDayTimestampedAmount.setTimestamp(
                    pair.getKey().toDateTimeAtStartOfDay());
            groupedByDayTimestampedAmount.setAmount(accumulatedAmount);
            accumulatedByDay.add(groupedByDayTimestampedAmount);
        }

        return accumulatedByDay;
    }

    private static LinkedHashMap<LocalDate, List<TimestampedMediaAmount>> groupByDay(
            List<TimestampedMediaAmount> amounts) {

        //we use a linked hash map to maintain day ordering - the amounts
        // that come in should be ordered, so this will maintain a stable
        // order in the groups.
        LinkedHashMap<LocalDate, List<TimestampedMediaAmount>> groupedByDay
                = new LinkedHashMap<>();

        for(TimestampedMediaAmount amount : amounts) {

            LocalDate day = amount.getTimestamp().toLocalDate();

            List<TimestampedMediaAmount> mediaAmountsThisDay;
            if(groupedByDay.containsKey(day)) {
                mediaAmountsThisDay = groupedByDay.get(day);
            } else {
                mediaAmountsThisDay = new ArrayList<>();
                groupedByDay.put(day, mediaAmountsThisDay);
            }

            mediaAmountsThisDay.add(amount);
        }
        return groupedByDay;
    }

    private static DateTime fromSqlDate(java.util.Date date) {
        return new DateTime(date.getTime());
    }

    private static java.sql.Timestamp toSqlTimestamp(DateTime jodaDate) {
        long millis = jodaDate.getMillis();
        java.sql.Timestamp sqlTimestamp = new Timestamp(millis);
        return sqlTimestamp;
    }

    public List<MediaWithTimestampedAmounts> getLatestMediaLevels(
            int printerId) throws SQLException {

        DateTime latestLevelsTimestamp =
                getLastPrinterDataTimestamp(printerId);

        List<MediaWithTimestampedAmounts> levels =
                getMediaLevels(
                    printerId,
                     //TODO: improve this post MVP - it's a hack to get latest
                     // - we should do it in SQL.
                    latestLevelsTimestamp.minusMillis(1),
                    latestLevelsTimestamp.plusMillis(1),
                        true); //latest levels should always be filtered

        return levels;
    }
}
