package io.swagger.api.impl.routing;

import io.swagger.api.impl.routing.routeplan.VertexWithReward;

/**
 * Created by robert.sharp on 15/09/2016.
 */
public class EuclideanVertex2DWithReward extends EuclideanVertex2D
        implements VertexWithReward {
    @Override
    public double getReward() {
        return 0; //TODO
    }
}
