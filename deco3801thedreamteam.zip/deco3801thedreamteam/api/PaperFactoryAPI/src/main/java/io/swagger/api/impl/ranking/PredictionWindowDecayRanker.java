package io.swagger.api.impl.ranking;

import io.swagger.api.impl.dao.mysql.PrinterDb;
import io.swagger.api.impl.prediction.LevelsPredictor;
import io.swagger.model.MediaWithTimestampedAmounts;
import io.swagger.model.Printer;
import io.swagger.model.PrinterWithReward;
import io.swagger.model.TimestampedMediaAmount;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Seconds;
import org.junit.Assert;
import org.junit.Test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by robert.sharp on 4/09/2016.
 *
 * Returns rankings which are the sum of predicted consumption per day, with
 * a linear decay per day in the prediction period
 *
 */
public class PredictionWindowDecayRanker implements PrinterRanker {

    private static int PREDICTION_WINDOW_SIZE_DAYS = 30;

    private final PrinterDb printerDb;
    private final LevelsPredictor levelsPredictor;

    public PredictionWindowDecayRanker(
            PrinterDb printerDb,
            LevelsPredictor levelsPredictor) {
        this.printerDb = printerDb;
        this.levelsPredictor = levelsPredictor;
    }

    public double getPrinterReward(int printerId) throws SQLException {

        //use levels predictor and predict below zero

        List<MediaWithTimestampedAmounts> levelPredictions =
                levelsPredictor.predictFutureLevels(
                        PREDICTION_WINDOW_SIZE_DAYS,
                        printerId,
                        true);

        //use paper levels as a proxy for total print jobs
        List<TimestampedMediaAmount> paperLevels =
                getPaperLevels(levelPredictions);

        return calcUnsatisfiedMediaConsumption(paperLevels);
    }

    static double calcUnsatisfiedMediaConsumption(
            List<TimestampedMediaAmount> predictedPaperLevels) {
        //to calculate decay we use an offset from the first day
        DateTime firstTimestamp = predictedPaperLevels.get(0).getTimestamp();

        //sum paper levels below zero with associated decay - that will be
        // our rank
        double totalUnsatisfiedPaperConsumption = 0;
        for(TimestampedMediaAmount timestampedPaperAmount
                : predictedPaperLevels) {

            double dayNumberFromStart =
                    1.0 + (double) Seconds.secondsBetween(
                            firstTimestamp, timestampedPaperAmount.getTimestamp())
                            .getSeconds() / (double)86400;

            //adjust linear decay
            double decay = (1.0 / dayNumberFromStart);

            int amount = timestampedPaperAmount.getAmount();

            if(amount < 0) {
                totalUnsatisfiedPaperConsumption -= (decay * (double)amount);
            }
        }
        return totalUnsatisfiedPaperConsumption;
    }

    public List<PrinterWithReward> getPrintersWithReward() throws SQLException {
        List<Printer> printers = printerDb.getAllPrinters();

        List<PrinterWithReward> printersWithRanking
                = new ArrayList<>();

        for(Printer printer : printers) {

            double ranking =
                    getPrinterReward(printer.getPrinterId());

            PrinterWithReward printerWithReward =
                    new PrinterWithReward();
            printerWithReward.setPrinter(printer);
            printerWithReward.setReward(ranking);

            printersWithRanking.add(printerWithReward);
        }
        return printersWithRanking;
    }

    /***
     * Gets all measurements of paper levels from the level predictions - note
     * that this will have multiple levels entries for different printers
     * on the same day
     * @param levelPredictions
     * @return
     */
    private List<TimestampedMediaAmount> getPaperLevels(
            List<MediaWithTimestampedAmounts> levelPredictions) {

        //get all paper media then put all timestamped amounts in one big list
        List<TimestampedMediaAmount> allPaperMediaAmounts = new ArrayList<>();
        for(MediaWithTimestampedAmounts candidateMedia
                : levelPredictions) {
            if(candidateMedia.getMediaType().toLowerCase().contains("tray")) {
                allPaperMediaAmounts.addAll(candidateMedia.getAmounts());
            }
        }

        return allPaperMediaAmounts;
    }
}
