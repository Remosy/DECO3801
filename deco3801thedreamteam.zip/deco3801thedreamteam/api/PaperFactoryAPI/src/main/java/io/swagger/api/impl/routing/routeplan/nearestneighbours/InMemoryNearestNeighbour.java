package io.swagger.api.impl.routing.routeplan.nearestneighbours;

import io.swagger.api.impl.routing.routeplan.Vertex;

import java.util.*;

/**
 * Created by robert.sharp on 7/09/2016.
 *
 * Precomputes the nearest neighbour list for each of the N vertices and keeps
 * it in memory. Nearest neighbour enumerators therefore just go through the
 * lists in memory.
 *
 * Results in NxN memory usage, but is totally fine for small problem sizes.
 */
public class InMemoryNearestNeighbour<T extends Vertex>
        implements VertexNearestNeighbourLookup<T> {

    private ArrayList<T> otherVerticesToConsider;
    private Map<T, ArrayList<T>> vertexToNearestNeighboursInOrder;

    public InMemoryNearestNeighbour(ArrayList<T> vertices) {
        this.otherVerticesToConsider = vertices;
        buildNeighboursMap();
    }

    private void buildNeighboursMap() {
        this.vertexToNearestNeighboursInOrder =
                new HashMap<>(otherVerticesToConsider.size());

        for(T vertex : otherVerticesToConsider) {
            addNeighboursToMap(vertex);
        }
    }

    private void addNeighboursToMap(T vertex) {
        //create a list copy of all vertices
        ArrayList<T> otherVertices =
                copyWithout(otherVerticesToConsider, vertex);

        //sort new list by neighbour distance to this vertex
        sortByDistance(vertex, otherVertices);

        //add to vertex-> ordered neighbours list map
        this.vertexToNearestNeighboursInOrder.put(vertex, otherVertices);
    }

    private void sortByDistance(final T vertex, ArrayList<T> otherVertices) {

        Collections.sort(otherVertices, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {

                //get distance from our current vertex to either, and compare
                // the distances. this will be executed
                Double distance1 = vertex.travelTimeTo(o1);
                Double distance2 = vertex.travelTimeTo(o2);
                return distance1.compareTo(distance2);
            }
        });
    }

    private ArrayList<T> copyWithout(ArrayList<T> list, T exclude) {
        ArrayList<T> newList = new ArrayList<>(list.size() - 1);
        for(T item : list) {
            if(item != exclude) {
                newList.add(item);
            }
        }
        return newList;
    }

    @Override
    public Iterator<T> getNearestNeighbourEnumerator(T vertex) {

        ArrayList<T> nearestNeighbours =
                vertexToNearestNeighboursInOrder.get(vertex);

        if(nearestNeighbours != null) {
            return nearestNeighbours.iterator();
        } else {

            //we haven't seen this vertex yet - so calc distances once and
            // store, but don't add it as a vertex to consider. then go again
            addNeighboursToMap(vertex);
            return getNearestNeighbourEnumerator(vertex);
        }
    }
}
