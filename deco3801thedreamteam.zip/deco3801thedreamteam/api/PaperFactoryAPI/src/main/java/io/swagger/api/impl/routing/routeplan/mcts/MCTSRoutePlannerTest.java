package io.swagger.api.impl.routing.routeplan.mcts;

import io.swagger.api.impl.routing.RoutingPrinterWithRanking;
import io.swagger.api.impl.routing.StartEndPointVertex;
import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteEntry;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.model.Location;
import io.swagger.model.Printer;
import org.junit.Assert;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by rob on 22/10/16.
 */
public class MCTSRoutePlannerTest {

    /***
     * Tests that in a small routing scenario with a known best route, that
     * the route planner converges to that best route and returns it, and
     * that the route planner terminates (we give it an effectively infinite
     * computation time to complete - the route planner is designed to return
     * once it knows it has the best solution)
     */
    @Test
    public void routingScenarioOptimumTest() throws FileNotFoundException {

        //starting point for route
        StartEndPointVertex origin = new StartEndPointVertex(0, 0);

        //printers will be at (.001, .001), (.002, .002) and (.003, .003)
        // and so on
        ArrayList<RoutingPrinterWithRanking> testPrinters =
                createTestPrinters(5);

        RouteTimingConfig routeTimingConfig =
                new RouteTimingConfig(0, 1500);

        //plan the route
        Route<RoutingPrinterWithRanking> route = MCTSRoutePlanner
                .planRoute(origin, testPrinters,
                        routeTimingConfig,
                        Integer.MAX_VALUE); //allowed compute time (ms)

        //route should be through first three printers only
        int i = 0;
        for(RouteEntry<RoutingPrinterWithRanking> routeEntry : route) {
            i++;

            //the printers should be in distance order, so (.001, .001),
            // (.002, .002) and so on
            Assert.assertEquals("Route ordering not as expected",
                    routeEntry.getVertex().getPrinter()
                    .getLocation().getLat(), new BigDecimal(i / 1000.00));
            Assert.assertEquals("Route ordering not as expected",
                    routeEntry.getVertex().getPrinter()
                    .getLocation().getLng(), new BigDecimal(i / 1000.00));
        }

        Assert.assertEquals("Route should only include 3 printers in distance constraint", 3, i);
        Assert.assertEquals("Route reward not as expected", 6.0, route.getRewardSoFar(), 0);
        Assert.assertEquals("Route travel time not as expected", 673, route.getTravelTime(), 1);
    }

    private static ArrayList<RoutingPrinterWithRanking> createTestPrinters(int count) {

        ArrayList<RoutingPrinterWithRanking> printers = new ArrayList<>(count);
        for(int i = 0; i < count; i++) {

            double lat = i / 1000.0;
            double lng = i / 1000.0;

            Printer fakePrinter = new Printer();
            fakePrinter.setPrinterName("printername");
            fakePrinter.setBuildingName("buildname");
            fakePrinter.setPrinterId(i);

            Location fakePrinterLocation = new Location();
            fakePrinterLocation.setLat(new BigDecimal(lat));
            fakePrinterLocation.setLng(new BigDecimal(lng));

            fakePrinter.setLocation(fakePrinterLocation);

            double reward = i;

            RoutingPrinterWithRanking printer =
                    new RoutingPrinterWithRanking(fakePrinter, reward);
            printers.add(printer);
        }

        return printers;
    }
}
