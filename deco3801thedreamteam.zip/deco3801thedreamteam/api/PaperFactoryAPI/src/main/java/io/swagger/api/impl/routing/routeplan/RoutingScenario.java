package io.swagger.api.impl.routing.routeplan;

import java.util.ArrayList;

/**
 * Created by Robert.Sharp on 14/09/2016.
 */
public class RoutingScenario<T extends VertexWithReward> {

    private T startEndVertex;
    private ArrayList<T> allVertices;
    private RouteTimingConfig routeTimingConfig;

    public RoutingScenario(
            T startEndVertex,
            ArrayList<T> allVertices,
            RouteTimingConfig routeTimingConfig) {
        this.startEndVertex = startEndVertex;
        this.allVertices = allVertices;
        this.routeTimingConfig = routeTimingConfig;
    }

    public T getStartEndVertex() {
        return startEndVertex;
    }

    public ArrayList<T> getAllVertices() {
        return allVertices;
    }

    public RouteTimingConfig getRouteTimingConfig() {
        return routeTimingConfig;
    }
}
