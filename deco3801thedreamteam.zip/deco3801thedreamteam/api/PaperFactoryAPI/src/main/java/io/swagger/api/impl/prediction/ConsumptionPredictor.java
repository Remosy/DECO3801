package io.swagger.api.impl.prediction;

import io.swagger.model.MediaWithTimestampedAmounts;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Robert.Sharp on 4/09/2016.
 */
public interface ConsumptionPredictor {

    public List<MediaWithTimestampedAmounts> predictFutureConsumptionPerDay(
            int lookAheadDaysInt, int printerIdInt) throws SQLException;
}
