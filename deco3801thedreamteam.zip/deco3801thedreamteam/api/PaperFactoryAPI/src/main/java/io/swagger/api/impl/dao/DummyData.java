package io.swagger.api.impl.dao;

import io.swagger.model.*;
import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by s4140294 on 29/08/2016.
 */
public class DummyData {

    public static List<Printer> getPrinters() {

        Printer p1 = new Printer();
        p1.setBuildingName("GP South");
        p1.setPrinterId(1);
        p1.setPrinterName("Basement lab");
        Location p1Loc = new Location();
        p1Loc.setLat(new BigDecimal("-27.500080"));
        p1Loc.setLng(new BigDecimal("153.014838"));
        p1.setLocation(p1Loc);

        Printer p2 = new Printer();
        p2.setBuildingName("Hawken");
        p2.setPrinterId(1);
        p2.setPrinterName("S102");
        Location p2Loc = new Location();
        p2Loc.setLat(new BigDecimal("-27.500156"));
        p2Loc.setLng(new BigDecimal("153.013708"));
        p2.setLocation(p2Loc);

        ArrayList<Printer> printers = new ArrayList<>();
        printers.add(p1);
        printers.add(p2);
        return printers;
    }

    public static List<MediaAndCapacity> getMediaAndCapacities() {

        List<MediaAndCapacity> mediaAndCapacities = new ArrayList<>();

        List<String> mediaTypes = getMediaTypes();
        for(int i = 0; i < mediaTypes.size(); i++) {

            MediaAndCapacity mediaAndCapacity = new MediaAndCapacity();
            mediaAndCapacity.setCapacity(100 * i);
            mediaAndCapacity.setMediaType(mediaTypes.get(i));

            mediaAndCapacities.add(mediaAndCapacity);
        }

        return mediaAndCapacities;
    }

    public static List<MediaWithTimestampedAmounts> getMediaConsumption(
            DateTime startDate,
            DateTime endDate) {
        //for each of the days, just return some dummy number
        DateTime currentDate = startDate;
        List<TimestampedMediaAmount> amountsBlackInk = new ArrayList<>();
        List<TimestampedMediaAmount> amountsPaper = new ArrayList<>();

        while(currentDate.isBefore(endDate)
                || currentDate.equals(endDate)) {

            //go forward one day each time
            currentDate = currentDate.plusDays(1);

            //always return 50 for paper
            TimestampedMediaAmount mediaAmountPaper =
                    new TimestampedMediaAmount();
            mediaAmountPaper.setAmount(50);
            mediaAmountPaper.setTimestamp(currentDate);
            amountsPaper.add(mediaAmountPaper);

            //always return 97 for black ink
            TimestampedMediaAmount mediaAmountBlackInk =
                    new TimestampedMediaAmount();
            mediaAmountBlackInk.setAmount(97);
            mediaAmountBlackInk.setTimestamp(currentDate);
            amountsBlackInk.add(mediaAmountBlackInk);
        }

        MediaWithTimestampedAmounts blackInk =
                new MediaWithTimestampedAmounts();
        blackInk.setAmounts(amountsBlackInk);
        blackInk.setMediaType("Black Ink");

        MediaWithTimestampedAmounts paper =
                new MediaWithTimestampedAmounts();
        paper.setAmounts(amountsPaper);
        paper.setMediaType("Paper");

        List<MediaWithTimestampedAmounts> allMediaWithAmounts =
                new ArrayList<>();

        allMediaWithAmounts.add(blackInk);
        allMediaWithAmounts.add(paper);
        return allMediaWithAmounts;
    }

    public static List<MediaWithTimestampedAmounts> getMediaLevels(
            DateTime startDate,
            DateTime endDate) {

        //for each of the days, just return some dummy number
        DateTime currentDate = startDate;
        List<TimestampedMediaAmount> amountsBlackInk = new ArrayList<>();
        List<TimestampedMediaAmount> amountsPaper = new ArrayList<>();

        while(currentDate.isBefore(endDate)
                || currentDate.equals(endDate)) {

            //go forward one minute each time
            currentDate = currentDate.plusMinutes(1);

            //always return 50 for paper
            TimestampedMediaAmount mediaAmountPaper =
                    new TimestampedMediaAmount();
            mediaAmountPaper.setAmount(50);
            mediaAmountPaper.setTimestamp(currentDate);
            amountsPaper.add(mediaAmountPaper);

            //always return 97 for black ink
            TimestampedMediaAmount mediaAmountBlackInk =
                    new TimestampedMediaAmount();
            mediaAmountBlackInk.setAmount(97);
            mediaAmountBlackInk.setTimestamp(currentDate);
            amountsBlackInk.add(mediaAmountBlackInk);
        }

        MediaWithTimestampedAmounts blackInk =
                new MediaWithTimestampedAmounts();
        blackInk.setAmounts(amountsBlackInk);
        blackInk.setMediaType("Black Ink");

        MediaWithTimestampedAmounts paper =
                new MediaWithTimestampedAmounts();
        paper.setAmounts(amountsPaper);
        paper.setMediaType("Paper");

        List<MediaWithTimestampedAmounts> allMediaWithAmounts =
                new ArrayList<>();

        allMediaWithAmounts.add(blackInk);
        allMediaWithAmounts.add(paper);
        return allMediaWithAmounts;
    }

    public static List<String> getMediaTypes() {

        //TODO: these might not match the DB - we'll need to check
        ArrayList<String> mediaTypes = new ArrayList<>();
        mediaTypes.add("Paper");
        mediaTypes.add("Black Ink");
        return mediaTypes;
    }
}
