package io.swagger.api.impl.routing;

import io.swagger.api.impl.routing.routeplan.VertexWithReward;
import io.swagger.model.Printer;

/**
 * Created by robert.sharp on 23/08/2016.
 *
 * A point in 2D space, with an associated refill reward to be used as a
 * reward in a route planner
 */
public class RoutingPrinterWithRanking
        extends HumanWalkLatLngVertex implements VertexWithReward {

    private double refillRanking;
    private Printer printer;

    public RoutingPrinterWithRanking(
            Printer printer, double refillRanking) {
        super(printer.getLocation().getLat().doubleValue(),
                printer.getLocation().getLng().doubleValue());
        this.refillRanking = refillRanking;
        this.printer = printer;
    }

    /***
     * Special constructor for a start/end point in route planning
     * @param lat
     * @param lng
     */
    protected RoutingPrinterWithRanking(double lat, double lng) {
        super(lat, lng);
    }

    @Override
    public double getReward() {
        return refillRanking;
    }

    public Printer getPrinter() {
        return printer;
    }
}
