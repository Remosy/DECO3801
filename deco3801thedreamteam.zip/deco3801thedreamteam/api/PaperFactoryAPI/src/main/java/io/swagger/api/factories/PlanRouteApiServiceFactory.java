package io.swagger.api.factories;

import io.swagger.api.PlanRouteApiService;
import io.swagger.api.impl.PlanRouteApiServiceImpl;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PlanRouteApiServiceFactory {
    private final static PlanRouteApiService service = new PlanRouteApiServiceImpl();

    public static PlanRouteApiService getPlanRouteApi() {
        return service;
    }
}
