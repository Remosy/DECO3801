package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.api.impl.routing.RoutingPrinterWithRanking;
import io.swagger.api.impl.routing.StartEndPointVertex;
import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteEntry;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.api.impl.routing.routeplan.dp.DPRoutePlanner;
import io.swagger.api.impl.routing.routeplan.mcts.MCTSRoutePlanner;
import io.swagger.api.impl.routing.routeplan.naive.NaiveTopNRoutePlanner;
import io.swagger.model.*;

import java.math.BigDecimal;
import io.swagger.model.TravelTimePrinterAndReward;

import java.util.ArrayList;
import java.util.List;
import io.swagger.api.NotFoundException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import static io.swagger.api.impl.ApiImplShared.*;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-08-25T20:15:52.814+10:00")
public class PlanRouteApiServiceImpl extends PlanRouteApiService {

    private static final int PRINTER_REFILL_VISIT_TIME_SECONDS = 60;

    //note that route planning is synchronised so we only allow one route
    // plan to occur at once to avoid blowing our memory
    @Override
    public synchronized Response planRouteGet(
            Integer timeWindowSeconds,
            BigDecimal originLat,
            BigDecimal originLng,
            Integer computationTime,
            String planner,
            SecurityContext securityContext) throws NotFoundException {

        //unpack args
        double originLatD = originLat.doubleValue();
        double originLngD = originLng.doubleValue();

        int computationTimeMilliSeconds = 10000; //default 10 seconds
        if(computationTime != null) {
            computationTimeMilliSeconds = 1000 * computationTime.intValue();
        }

        int travelTimeWindowSeconds = timeWindowSeconds;

        try {

            //get printers (these are API native types)
            List<PrinterWithReward> printerWithRewards =
                    printerRanker.getPrintersWithReward();

            //convert to route planner types (these subclass AWT for help with
            // the geometry)
            ArrayList<RoutingPrinterWithRanking> routingPrinterWithRankings =
                    convertToRoutingPrinterTypesForRouting(
                            printerWithRewards);

            //starting/ending point for route is the origin point
            StartEndPointVertex origin =
                    new StartEndPointVertex(originLatD, originLngD);

            RouteTimingConfig routeTimingConfig =
                    new RouteTimingConfig(
                            PRINTER_REFILL_VISIT_TIME_SECONDS,
                            travelTimeWindowSeconds);

            //plan the route
            Route<RoutingPrinterWithRanking> route;

            //case insensitive string switch
            if(planner == null) {
                planner = "null";
            }
            switch (planner.toLowerCase()) {
                case "naive_top_n":
                    route = NaiveTopNRoutePlanner
                            .planRoute(origin, routingPrinterWithRankings,
                                    routeTimingConfig);
                    break;
                case "dp":
                    route = DPRoutePlanner
                            .planRoute(origin, routingPrinterWithRankings,
                                    routeTimingConfig);
                    break;
                case "mcts":
                default:
                    route = MCTSRoutePlanner
                            .planRoute(origin, routingPrinterWithRankings,
                                    routeTimingConfig,
                                    computationTimeMilliSeconds);
                    break;
            }

            //convert route output to a route for the API to return
            List<TravelTimePrinterAndReward> apiReturnRoute = new ArrayList<>();
            for(RouteEntry<RoutingPrinterWithRanking> routeEntry : route) {

                //ignore route entries without printers (should be just the
                // end point)
                if(routeEntry.getVertex().getPrinter() == null) {
                    continue;
                }

                TravelTimePrinterAndReward travelTimePrinterAndReward =
                        new TravelTimePrinterAndReward();
                travelTimePrinterAndReward.setPrinter(
                        routeEntry.getVertex().getPrinter());
                travelTimePrinterAndReward.setTravelTimeSeconds(
                        (int)routeEntry.getTravelTimeToVertex());
                travelTimePrinterAndReward
                        .setReward(routeEntry.getVertex().getReward());
                apiReturnRoute.add(travelTimePrinterAndReward);
            }

            //we're done!
            return Response.ok().entity(apiReturnRoute).build();

        } catch (Exception e) {
            return formatErrorResponse(e);
        }
    }

    private ArrayList<RoutingPrinterWithRanking> convertToRoutingPrinterTypesForRouting(
            List<PrinterWithReward> printerWithRewards) {

        ArrayList<RoutingPrinterWithRanking> routingPrinterWithRankings
                = new ArrayList<>();

        for(PrinterWithReward printerWithReward : printerWithRewards) {

            RoutingPrinterWithRanking routingPrinterWithRanking =
                    new RoutingPrinterWithRanking(
                            printerWithReward.getPrinter(),
                            printerWithReward.getReward());

            routingPrinterWithRankings.add(routingPrinterWithRanking);
        }

        return routingPrinterWithRankings;
    }
}
