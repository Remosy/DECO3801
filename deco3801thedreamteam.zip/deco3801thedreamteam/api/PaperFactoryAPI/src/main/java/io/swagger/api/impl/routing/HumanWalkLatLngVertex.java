package io.swagger.api.impl.routing;

import io.swagger.api.impl.routing.routeplan.Vertex;

/**
 * Created by robert.sharp on 23/08/2016.
 *
 * A Vertex which is a point in 2D space, where euclidean distance multiplied
 * by human walking speed is used as a measure of travel time.
 */
public class HumanWalkLatLngVertex implements Vertex {

    //https://en.wikipedia.org/wiki/Preferred_walking_speed
    // scaled down by half because obstacles etc - we can't assume euclidean
    // distance
    private static final double HUMAN_WALK_SPEED_METRES_P_SEC = 0.7;
    private static final double HUMAN_WALK_SPEED_SECONDS_P_METRE =
            1 / HUMAN_WALK_SPEED_METRES_P_SEC;

    private final double lat;
    private final double lng;

    public HumanWalkLatLngVertex(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }

    @Override
    public double travelTimeTo(Vertex other) {

        if(other instanceof HumanWalkLatLngVertex) {
            HumanWalkLatLngVertex otherPrinter = (HumanWalkLatLngVertex)other;
            return this.humanWalkTravelTimeBasedOnDistance(otherPrinter);
        } else {
            //allow asymmetry
            return other.travelTimeTo(this);
        }
    }

    private double humanWalkTravelTimeBasedOnDistance(
            HumanWalkLatLngVertex otherPrinter) {
        double distanceMetres = latLngdistance(
                this.lat, otherPrinter.lat, this.lng, otherPrinter.lng, 0, 0);
        return distanceMetres * HUMAN_WALK_SPEED_SECONDS_P_METRE;
    }

    /*
     * Calculate distance between two points in latitude and longitude taking
     * into account height difference. If you are not interested in height
     * difference pass 0.0. Uses Haversine method as its base.
     *
     * lat1, lon1 Start point lat2, lon2 End point el1 Start altitude in meters
     * el2 End altitude in meters
     * @returns Distance in Meters
     */
    public static double latLngdistance(double lat1, double lat2, double lon1,
                                  double lon2, double el1, double el2) {

        final int R = 6371; // Radius of the earth

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c * 1000; // convert to meters

        double height = el1 - el2;

        distance = Math.pow(distance, 2) + Math.pow(height, 2);

        return Math.sqrt(distance);
    }

    @Override
    public String toString() {
        return this.lat + "," + this.lng;
    }
}
