package io.swagger.api.impl.routing.routeplan.mcts;

import io.swagger.api.impl.routing.RoutingPrinterWithRanking;
import io.swagger.api.impl.routing.StartEndPointVertex;
import io.swagger.api.impl.routing.routeplan.Route;
import io.swagger.api.impl.routing.routeplan.RouteTimingConfig;
import io.swagger.model.Location;
import io.swagger.model.Printer;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by rob on 22/10/16.
 */
public class MCTSRoutePlannerSimulation {

    private static final Random prng = new Random();

    @Test
    public void longRunningRoutingSimulation()
            throws FileNotFoundException, UnsupportedEncodingException {

        //starting point for route
        StartEndPointVertex origin = new StartEndPointVertex(0, 0);

        //now create a bunch of printers in the route, with different
        // rankings
        ArrayList<RoutingPrinterWithRanking> testPrinters =
                createTestPrinters(40);

        RouteTimingConfig routeTimingConfig =
                new RouteTimingConfig(0, 300000);

        //plan the route
        Route route = MCTSRoutePlanner
                .planRoute(origin, testPrinters,
                        routeTimingConfig,
                        10000); //allowed compute time (ms)
    }

    private static ArrayList<RoutingPrinterWithRanking> createTestPrinters(int count) {

        ArrayList<RoutingPrinterWithRanking> printers = new ArrayList<>(count);
        for(int i = 0; i < count; i++) {

            double lat = prng.nextDouble();
            double lng = prng.nextDouble();

            Printer fakePrinter = new Printer();
            fakePrinter.setPrinterName("printername");
            fakePrinter.setBuildingName("buildname");
            fakePrinter.setPrinterId(i);

            Location fakePrinterLocation = new Location();
            fakePrinterLocation.setLat(new BigDecimal(lat));
            fakePrinterLocation.setLng(new BigDecimal(lng));

            fakePrinter.setLocation(fakePrinterLocation);

            double reward = Math.abs(prng.nextGaussian());

            //pick lat, lng and reward in range 0-1
            RoutingPrinterWithRanking printer =
                    new RoutingPrinterWithRanking(fakePrinter, reward);
            printers.add(printer);
        }

        return printers;
    }
}
