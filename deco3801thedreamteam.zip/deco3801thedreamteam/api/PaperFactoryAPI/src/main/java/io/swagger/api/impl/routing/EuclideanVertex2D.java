package io.swagger.api.impl.routing;

import io.swagger.api.impl.routing.routeplan.Vertex;

import java.awt.geom.Point2D;

/**
 * Created by Robert.Sharp on 14/09/2016.
 */
public class EuclideanVertex2D extends Point2D.Double implements Vertex {


    @Override
    public double travelTimeTo(Vertex other) {
        return 0; //TODO
    }
}
