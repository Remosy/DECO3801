package io.swagger.api.impl.prediction;

import io.swagger.api.impl.dao.mysql.PrinterDb;
import io.swagger.model.MediaWithTimestampedAmounts;
import io.swagger.model.TimestampedMediaAmount;
import org.joda.time.DateTime;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Robert.Sharp on 4/09/2016.
 *
 * A naive predictor that takes the last N days of consumption, averages it,
 * and returns that as the future consumption
 */
public class NaiveAveragePrediction implements ConsumptionPredictor {

    private static final int LOOKBACK_WINDOW_DAYS = 7;

    private PrinterDb printerDb;

    public NaiveAveragePrediction(PrinterDb printerDb) {
        this.printerDb = printerDb;
    }

    public List<MediaWithTimestampedAmounts> predictFutureConsumptionPerDay(
            int lookAheadDaysInt, int printerIdInt) throws SQLException {
        //get midnight at the start of the day where we have our latest data
        // point
        DateTime latestDataTimestampMidnight =
                printerDb.getLastPrinterDataTimestamp(printerIdInt)
                        .withTimeAtStartOfDay();

        //calculate N days before that - this will be our average consump
        // period
        DateTime lookbackDaysPreviousMidnight =
                latestDataTimestampMidnight
                        .minusDays(LOOKBACK_WINDOW_DAYS)
                        .withTimeAtStartOfDay();

        //get the per day consumption over the last 7 days of data
        List<MediaWithTimestampedAmounts> lastNDaysDataConsumptionPerDay
                = printerDb.getMediaConsumptionPerDay(
                printerIdInt,
                lookbackDaysPreviousMidnight,
                latestDataTimestampMidnight);

        //get average daily consumption per media type
        Map<String, Integer> mediaToDailyAverage =
                averageMediaWithAmounts(lastNDaysDataConsumptionPerDay);

        //now use those avg amounts and spread across all N days, starting
        // from the timestamp of the last data point, plus one day
        List<DateTime> lookaheadDaysTimestamps =
                createDailyTimestamps(
                        latestDataTimestampMidnight.plusDays(1),
                        latestDataTimestampMidnight.plusDays(lookAheadDaysInt));

        return spreadAverageMediaConsumptionAcrossDays(
                mediaToDailyAverage, lookaheadDaysTimestamps);
    }

    static List<MediaWithTimestampedAmounts> spreadAverageMediaConsumptionAcrossDays(
            Map<String, Integer> mediaToDailyAverage,
            List<DateTime> lookaheadDaysTimestamps) {
        List<MediaWithTimestampedAmounts> averageAmountsSpread7Days
                = new ArrayList<>();

        for(Map.Entry<String, Integer> mediaWithDailyAverage
                : mediaToDailyAverage.entrySet()) {

            List<TimestampedMediaAmount> timestampedAmountsThisMedia
                    = new ArrayList<>();

            for(DateTime timestamp : lookaheadDaysTimestamps) {

                TimestampedMediaAmount timestampedMediaAmount
                        = new TimestampedMediaAmount();
                timestampedMediaAmount.setAmount(
                        mediaWithDailyAverage.getValue());
                timestampedMediaAmount.setTimestamp(timestamp);
                timestampedAmountsThisMedia.add(timestampedMediaAmount);
            }

            MediaWithTimestampedAmounts mediaWithTimestampedAmounts =
                    new MediaWithTimestampedAmounts();
            mediaWithTimestampedAmounts.setMediaType(
                    mediaWithDailyAverage.getKey());
            mediaWithTimestampedAmounts.setAmounts(
                    timestampedAmountsThisMedia);

            averageAmountsSpread7Days.add(mediaWithTimestampedAmounts);
        }

        return averageAmountsSpread7Days;
    }

    static List<DateTime> createDailyTimestamps(
            DateTime startDate,
            DateTime endDate) {

        DateTime currentDate = startDate;

        List<DateTime> dates = new ArrayList<>();
        while (currentDate.isBefore(endDate)
                || currentDate.equals(endDate)) {

            dates.add(currentDate);

            //go forward one day each time
            currentDate = currentDate.plusDays(1);
        }

        return dates;
    }

    static Map<String, Integer> averageMediaWithAmounts(
            List<MediaWithTimestampedAmounts> lastSevenDaysDataConsumptionPerDay) {

        //now average the collections of amounts
        Map<String, Integer> mediaToAverageAmounts = new HashMap<>();

        for(MediaWithTimestampedAmounts mediaWithTimestampedAmounts
                : lastSevenDaysDataConsumptionPerDay) {

            int sum = 0;
            for(TimestampedMediaAmount amount
                    : mediaWithTimestampedAmounts.getAmounts()) {
                sum += amount.getAmount();
            }

            int average;
            if(mediaWithTimestampedAmounts.getAmounts().size() == 0) {
                //if no consumption entries, average is zero
                average = 0;
            } else {
                average = sum / mediaWithTimestampedAmounts.getAmounts().size();
            }

            mediaToAverageAmounts.put(
                    mediaWithTimestampedAmounts.getMediaType(), average);
        }

        return mediaToAverageAmounts;
    }
}
