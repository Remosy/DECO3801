package io.swagger.api.impl.routing;

/**
 * Created by Robert.Sharp on 28/08/2016.
 */
public class StartEndPointVertex extends RoutingPrinterWithRanking {
    public StartEndPointVertex(double lat, double lng) {
        super(lat, lng);
    }
}
