<?php

//require_once ("uq/auth.php");
//auth_require();
//echo "<pre">
//print_r(auth_get_payload());
//echo "</pre>";





session_start();
/*
if(basename($_SERVER['PHP_SELF']) != "login.php" && auth_get_payload() === false) {
    header("Location: login.php");
}
*/

if(!isset($_SESSION["currentDate"])) {
    $_SESSION["currentDate"] = "2013-03-01 12:00:00";
}

?>