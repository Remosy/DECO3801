<?php
/*
*   Fetches all printer data between startDate and endDate.
*   Specify individual printers with &printers=1,34,3,6. Optional
*/
require_once("../includes.php");
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

if(isset($_GET["startDate"]) && isset($_GET["endDate"])) {
    $paperVisualiserModel = new PaperVisualiserModel();
    $paperVisualiserModel->setDate($_GET["startDate"]);
    
    $i = 0;
    $printerInfo = [];
    $printerID = isset($_GET["printers"]) ? $_GET["printers"] : "";

    $numPrinters = 28;
    
    echo "{\"data\": {";

    if($printerID != "") {
        $printersToGet = explode(",", $printerID);
    } else {
        $printersToGet = $paperVisualiserModel->getAllPrinterIDs();
    }
    
    $firstFlag = true;
    $numberIndexes = count($printersToGet);
    
    foreach($printersToGet as $p) {
        echo "\"$p\": [";
        $printers = $paperVisualiserModel->getPrintersUpToDate($_GET["endDate"], $p);
        $prevPrinter = null;
        foreach($printers as $printer) {
            if($prevPrinter != null) {
                echo ", ";
            }
            echo $printer->toJSON($prevPrinter);
            $prevPrinter = $printer;
        }
        echo "]";
        if($p != $printersToGet[$numberIndexes-1])
            echo ",";
    }
    echo "}}";
}


?>
