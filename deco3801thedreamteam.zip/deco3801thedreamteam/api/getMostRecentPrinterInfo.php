<?php
require_once("../includes.php");
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
session_start();

if(isset($_GET["date"]) && $_GET["date"] !== "") {
    $paperVisualiserModel = new PaperVisualiserModel();
    $paperVisualiserModel->setDate($_GET["date"]);

    $printers = $paperVisualiserModel->getTodaysPrintersWithTrend();
    if(count($printers) <= 1) {
        echo "[]";
        exit;
    }
    $previousPrinter = $printers[0];
    $lineValues = "";
    $timeStamps = "";
    $first = true;
    $printerContainer = "{";
    $printerData = "[";
    echo "[";
    foreach($printers as $printer) {
        if($printer->Printer !== $previousPrinter->Printer) {
            
            $printerContainer .= "\"id\": \"$previousPrinter->Printer\", \"location\": \"$previousPrinter->Location\", \"lat\": $previousPrinter->latitude, \"lng\": $previousPrinter->longitude, \"printerData\": " . substr($printerData, 0, -2) . "], " .
                "\"timeStamps\": [" . $timeStamps . "\"], " .
                "\"lineValues\": [" . $lineValues . "]" .
            "}, {";
            $timeStamps = "";
            $lineValues = "";
            $printerData = "[";
            $previousPrinter = $printer;
        }
        // Generate Data for the Chart
        $timeStamps .= '"' . (($timeStamps == "" ? "" : ", \"") . $printer->Stamp);
        $lineValues .= ($lineValues == "" ? "" : ", ") . '"' . $printer->Paper . '"';

        $printerData .= $printer->toJSON() . ", ";
    }
    $printerContainer .= "\"id\": \"$printer->Printer\", \"location\": \"$printer->Location\", \"lat\": $printer->latitude, \"lng\": $printer->longitude, \"printerData\": " . substr($printerData, 0, -2) . "], " .
                "\"timeStamps\": [" . $timeStamps . "\"], " .
                "\"lineValues\": [" . $lineValues . "]" .
            "}";
            
    echo $printerContainer;
    echo "]";
}
?>
