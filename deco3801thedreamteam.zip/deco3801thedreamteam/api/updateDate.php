<?php
require_once("../includes.php");
session_start();

if(isset($_GET["newDate"]) && isset($_GET["newTime"])) {
    $_SESSION["currentDate"] = $_GET["newDate"] . " " . $_GET["newTime"];
    echo $_SESSION["currentDate"];
}

?>
