var mv = require("mv");mv('Tests/reports/JS/lcov-report/', 'Tests/reports/JS/', {clobber: false}, function(err) {
    if(err) console.log(err);
});