-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: localhost    Database: printer
-- ------------------------------------------------------
-- Server version	5.7.15-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `SNMPHistory`
--

DROP TABLE IF EXISTS `SNMPHistory`;
/*!50001 DROP VIEW IF EXISTS `SNMPHistory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `SNMPHistory` AS SELECT 
 1 AS `Printer`,
 1 AS `Location`,
 1 AS `Stamp`,
 1 AS `Uptime`,
 1 AS `Status`,
 1 AS `TonerBlack`,
 1 AS `TonerCyan`,
 1 AS `TonerMagenta`,
 1 AS `TonerYellow`,
 1 AS `Tray1`,
 1 AS `Tray2`,
 1 AS `Tray3`,
 1 AS `Tray4`,
 1 AS `InkCyan`,
 1 AS `InkMagenta`,
 1 AS `InkYellow`,
 1 AS `InkGray`,
 1 AS `InkMatteBlack`,
 1 AS `InkPhotoBlack`,
 1 AS `HeadGrayPhotoBlack`,
 1 AS `HeadMatteBlackYellow`,
 1 AS `HeadMagentaCyan`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `current_date`
--

DROP TABLE IF EXISTS `current_date`;
/*!50001 DROP VIEW IF EXISTS `current_date`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `current_date` AS SELECT 
 1 AS `Time`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `filtered_data`
--

DROP TABLE IF EXISTS `filtered_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filtered_data` (
  `Media` enum('Tray1','Tray2','Tray3','Tray4','TonerBlack','TonerCyan','TonerMagenta','TonerYellow') NOT NULL,
  `Printer` int(10) unsigned NOT NULL DEFAULT '0',
  `Time` datetime NOT NULL,
  `Level` int(3) NOT NULL,
  `Consumption` int(11) NOT NULL,
  PRIMARY KEY (`Media`,`Printer`,`Time`),
  KEY `fk_filtered` (`Printer`),
  CONSTRAINT `fk_filtered` FOREIGN KEY (`Printer`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_distances`
--

DROP TABLE IF EXISTS `node_distances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_distances` (
  `startNode` int(10) unsigned NOT NULL,
  `endNode` int(10) unsigned NOT NULL,
  `distanceTime` double unsigned NOT NULL,
  `distanceMeters` double unsigned NOT NULL,
  PRIMARY KEY (`startNode`,`endNode`),
  KEY `fk_endnode` (`endNode`),
  CONSTRAINT `fk_endnode` FOREIGN KEY (`endNode`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_startnode` FOREIGN KEY (`startNode`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodes` (
  `id` int(10) unsigned NOT NULL,
  `buildingName` varchar(16) NOT NULL,
  `printerName` varchar(16) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `predicted_data`
--

DROP TABLE IF EXISTS `predicted_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `predicted_data` (
  `Media` enum('Tray1','Tray2','Tray3','Tray4','TonerBlack','TonerCyan','TonerMagenta','TonerYellow') NOT NULL,
  `Printer` int(10) unsigned NOT NULL DEFAULT '0',
  `Time` datetime NOT NULL,
  `Created` datetime NOT NULL,
  `Consumption` int(11) NOT NULL,
  PRIMARY KEY (`Media`,`Printer`,`Time`),
  KEY `fk_predicted` (`Printer`),
  CONSTRAINT `fk_predicted` FOREIGN KEY (`Printer`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `snmp_data`
--

DROP TABLE IF EXISTS `snmp_data`;
/*!50001 DROP VIEW IF EXISTS `snmp_data`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `snmp_data` AS SELECT 
 1 AS `Printer`,
 1 AS `Location`,
 1 AS `Stamp`,
 1 AS `Uptime`,
 1 AS `TonerBlack`,
 1 AS `TonerCyan`,
 1 AS `TonerMagenta`,
 1 AS `TonerYellow`,
 1 AS `Tray1`,
 1 AS `Tray2`,
 1 AS `Tray3`,
 1 AS `Tray4`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `snmphistory`
--

DROP TABLE IF EXISTS `snmphistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snmphistory` (
  `Printer` int(10) unsigned NOT NULL,
  `Location` varchar(16) NOT NULL DEFAULT '',
  `Stamp` datetime NOT NULL,
  `Uptime` int(10) unsigned DEFAULT NULL,
  `Status` varchar(32) DEFAULT NULL,
  `TonerBlack` int(11) DEFAULT NULL,
  `TonerCyan` int(11) DEFAULT NULL,
  `TonerMagenta` int(11) DEFAULT NULL,
  `TonerYellow` int(11) DEFAULT NULL,
  `Tray1` int(11) DEFAULT NULL,
  `Tray2` int(11) DEFAULT NULL,
  `Tray3` int(11) DEFAULT NULL,
  `Tray4` int(11) DEFAULT NULL,
  `InkCyan` int(11) DEFAULT NULL,
  `InkMagenta` int(11) DEFAULT NULL,
  `InkYellow` int(11) DEFAULT NULL,
  `InkGray` int(11) DEFAULT NULL,
  `InkMatteBlack` int(11) DEFAULT NULL,
  `InkPhotoBlack` int(11) DEFAULT NULL,
  `HeadGrayPhotoBlack` int(11) DEFAULT NULL,
  `HeadMatteBlackYellow` int(11) DEFAULT NULL,
  `HeadMagentaCyan` int(11) DEFAULT NULL,
  PRIMARY KEY (`Printer`,`Stamp`),
  KEY `Stamp` (`Stamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Final view structure for view `SNMPHistory`
--

/*!50001 DROP VIEW IF EXISTS `SNMPHistory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `SNMPHistory` AS select `snmphistory`.`Printer` AS `Printer`,`snmphistory`.`Location` AS `Location`,`snmphistory`.`Stamp` AS `Stamp`,`snmphistory`.`Uptime` AS `Uptime`,`snmphistory`.`Status` AS `Status`,`snmphistory`.`TonerBlack` AS `TonerBlack`,`snmphistory`.`TonerCyan` AS `TonerCyan`,`snmphistory`.`TonerMagenta` AS `TonerMagenta`,`snmphistory`.`TonerYellow` AS `TonerYellow`,`snmphistory`.`Tray1` AS `Tray1`,`snmphistory`.`Tray2` AS `Tray2`,`snmphistory`.`Tray3` AS `Tray3`,`snmphistory`.`Tray4` AS `Tray4`,`snmphistory`.`InkCyan` AS `InkCyan`,`snmphistory`.`InkMagenta` AS `InkMagenta`,`snmphistory`.`InkYellow` AS `InkYellow`,`snmphistory`.`InkGray` AS `InkGray`,`snmphistory`.`InkMatteBlack` AS `InkMatteBlack`,`snmphistory`.`InkPhotoBlack` AS `InkPhotoBlack`,`snmphistory`.`HeadGrayPhotoBlack` AS `HeadGrayPhotoBlack`,`snmphistory`.`HeadMatteBlackYellow` AS `HeadMatteBlackYellow`,`snmphistory`.`HeadMagentaCyan` AS `HeadMagentaCyan` from `snmphistory` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `current_date`
--

/*!50001 DROP VIEW IF EXISTS `current_date`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `current_date` AS select max(`filtered_data`.`Time`) AS `Time` from `filtered_data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `snmp_data`
--

/*!50001 DROP VIEW IF EXISTS `snmp_data`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `snmp_data` AS select `snmphistory`.`Printer` AS `Printer`,`snmphistory`.`Location` AS `Location`,`snmphistory`.`Stamp` AS `Stamp`,`snmphistory`.`Uptime` AS `Uptime`,`snmphistory`.`TonerBlack` AS `TonerBlack`,`snmphistory`.`TonerCyan` AS `TonerCyan`,`snmphistory`.`TonerMagenta` AS `TonerMagenta`,`snmphistory`.`TonerYellow` AS `TonerYellow`,`snmphistory`.`Tray1` AS `Tray1`,`snmphistory`.`Tray2` AS `Tray2`,`snmphistory`.`Tray3` AS `Tray3`,`snmphistory`.`Tray4` AS `Tray4` from `snmphistory` order by `snmphistory`.`Stamp`,`snmphistory`.`Printer` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-23 21:06:24
