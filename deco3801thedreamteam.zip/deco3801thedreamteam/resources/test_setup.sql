-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2016 at 06:56 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `printer_test`
--
DROP SCHEMA IF EXISTS `printer_test`;
CREATE SCHEMA IF NOT EXISTS `printer_test`;
USE `printer_test`;

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE `nodes` (
  `id` int(10) UNSIGNED NOT NULL,
  `buildingName` varchar(16) NOT NULL,
  `printerName` varchar(16) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `node_distances`
--

CREATE TABLE `node_distances` (
  `startNode` int(10) UNSIGNED NOT NULL,
  `endNode` int(10) UNSIGNED NOT NULL,
  `distanceTime` double UNSIGNED NOT NULL,
  `distanceMeters` double UNSIGNED NOT NULL,
    PRIMARY KEY (`startNode`, `endNode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `snmphistory`
--

CREATE TABLE `SNMPHistory` (
  `Printer` int(10) UNSIGNED NOT NULL,
  `Location` varchar(16) NOT NULL DEFAULT '',
  `Stamp` datetime NOT NULL,
  `Uptime` int(10) UNSIGNED DEFAULT NULL,
  `Status` varchar(32) DEFAULT NULL,
  `TonerBlack` int(11) DEFAULT NULL,
  `TonerCyan` int(11) DEFAULT NULL,
  `TonerMagenta` int(11) DEFAULT NULL,
  `TonerYellow` int(11) DEFAULT NULL,
  `Tray1` int(11) DEFAULT NULL,
  `Tray2` int(11) DEFAULT NULL,
  `Tray3` int(11) DEFAULT NULL,
  `Tray4` int(11) DEFAULT NULL,
  `InkCyan` int(11) DEFAULT NULL,
  `InkMagenta` int(11) DEFAULT NULL,
  `InkYellow` int(11) DEFAULT NULL,
  `InkGray` int(11) DEFAULT NULL,
  `InkMatteBlack` int(11) DEFAULT NULL,
  `InkPhotoBlack` int(11) DEFAULT NULL,
  `HeadGrayPhotoBlack` int(11) DEFAULT NULL,
  `HeadMatteBlackYellow` int(11) DEFAULT NULL,
  `HeadMagentaCyan` int(11) DEFAULT NULL,
  PRIMARY KEY (`Printer`,`Stamp`),
  KEY `Stamp` (`Stamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
