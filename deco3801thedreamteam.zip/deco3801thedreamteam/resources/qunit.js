var testrunner = require("qunit");

 testrunner.setup({
    log: {
         summary: true
    },
    coverage: {
        dir: "Tests/reports/JS",
        reporters: ["lcov"]
    }
});

testrunner.run([
    {
        tests: "Tests/JS/Pathfinding/NodeTest.js",
        code: "js/Pathfinding/Node.js"
    }, {
        tests: "Tests/JS/Pathfinding/EdgeTest.js",
        deps: "js/Pathfinding/Node.js",
        code: "js/Pathfinding/Edge.js"
    }, {
        tests: "Tests/JS/Visualisation/PaperVisualisationTest.js",
        deps: ["js/ThirdParty/underscore-min.js", "js/Pathfinding/Node.js", "js/Pathfinding/Edge.js"],
        code: "js/Visualisation/PaperVisualisation.js"
    }, {
        tests: "Tests/JS/Pathfinding/OptimalPathFinderTest.js",
        deps: ["js/ThirdParty/underscore-min.js", "js/Pathfinding/Node.js", "js/Pathfinding/Edge.js"],
        code: "js/Pathfinding/OptimalPathFinder.js"
    }]
);
