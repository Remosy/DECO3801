function [week, wp] = weeklyPaper(amount)
    
    week = [1:52]';
    wp = [];
    temp = [];
    counter = 0;
    % Loop through
    for i = 1:365
        temp = [temp;amount(i)];
        counter = counter + 1;
        
        if counter == 7
            wp = [wp;mean(temp)];
            counter = 0;
            temp = [];
        end
        
    end
end