%% Convert a string to date
function out = stringToDate(DateStrings,format)
    % Convert to date using selected format
    out = datetime(DateStrings,'InputFormat',format);
end