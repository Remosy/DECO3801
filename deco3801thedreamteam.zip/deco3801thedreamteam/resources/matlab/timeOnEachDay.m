function out = timeOnEachDay(Date, Status)

%% Variables
% An array with all the dayArray in them
dayArray = zeros(365,1);
beenUsed = false;% Has been used
sessionBusy = false;% Changed
startTime = 1;% Start date
endTime = 1;% Stop Date
idleCount = 0;
%% Loop Function
% Loop through the list
% Check get the first time the printer status
% is printing. Once the status is not printing
% add the difference of the two times to the day
% of the starting date.
for i = 1:size(Date,1) % idle(3), printing(4)
    % Check if the status is printing
    if  Status(i) == 4
        
        % Check that the session is not busy
        if not(sessionBusy)
                    disp('.')
            % If it is make it busy
            sessionBusy = true;
            
            % It starts
            beenUsed = true;
            
            % Assign the start day to day session started
            startTime = i;
            disp(startTime)
            
            idleCount = 0;
        end

    elseif Status(i) == 3 && beenUsed 
        idleCount = idleCount + 1;
        % Stop the session
        sessionBusy = false;
        
        % Set the end date
        endTime = i;
        disp(endTime)
        % Add the time between startDay and ednDay
        % Toda the day the printer started on
        disp(i)
        dayArray(toDay(Date(startTime))) =...
            dayArray(toDay(Date(startTime))) +...
            timeToSec(Date(endTime) - Date(startTime));
        disp('Time Passed')
        disp(Date(endTime) - Date(startTime))
    elseif not(Status(i) == 3) && not(Status(i) == 4)
        beenUsed = false;
    end
    %% This is just to see progress while compiling
 %   clc;
 %   disp('Progress:');
 %disp(i/size(Date,1)*100);
end

%% Assign the out variable
out = dayArray;
end