function [startDate, endDate, papers, startDOY, endDOY, avgDailyPapers]...
    = timeBetween(Dates, Status, Papers)
% Initialize  variables end
startDate = [];
endDate = [];
papers = [];
startDOY = [];
endDOY = [];
avgDailyPapers = [];

% Initialize function variables
startDay = Dates(1);
endDay = '';

% Create a switch

threes = 0;
fours = 0;
paperCount = 0;
streek = false;
% Start looping through everything
for i = 1:size(Dates,1)
    
    % Check what it is
    status = Status(i);
    
    % Check conditions
    switch status
        case 3 % increase 3
            threes = threes + 1;
            fours = 0;
            
        case 4
            fours = fours + 1;
            threes = 0;
        otherwise
            threes = 0;
            fours = 0;
            continue
    end
    
    % Check for repitition
    if threes > 1 || fours > 1
        streek = true;
        % Check if the paper changed
        if Papers(i-1) < Papers(i)
            paperCount = paperCount + Papers(i) - Papers(i-1);
        end
        % End of repitition and end if streek
    elseif streek == true && not(paperCount == 0)
        % Reset streek
        streek = false;
        % Save the current startDay, endDay and TotalTime
        startDate = [startDate; startDay];
        papers = [papers; paperCount];
        endDay = Dates(i);
        endDate = [endDate; endDay];
        
        startDOY = [startDOY;toDay(startDay)];
        endDOY = [endDOY;toDay(endDay)];
        
        avgDailyPapers = [avgDailyPapers;paperCount/...
            abs(toDay(startDay)/toDay(endDay))];
        % Set the new startDay
        try
            startDay = Dates(i+1);
        end
        
        % Reset threes, fours and papers
        threes = 0;
        fours = 0;
        paperCount = 0;
    end
end


end