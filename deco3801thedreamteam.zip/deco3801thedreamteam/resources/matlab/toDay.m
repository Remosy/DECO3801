function out = toDay(date)
    out = datevec2doy(datevec(date));
end