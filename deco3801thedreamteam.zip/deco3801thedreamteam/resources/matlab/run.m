% Run Script
clc; clear all; close all;
load('Data.mat')

[startDate, endDate, papers, startDOY, endDOY, avgDailyPapers]...
    = timeBetween(Dates, Status, Paper);


[day, amount] = blockSmooth(startDOY, endDOY, papers);

smoothedSet = smooth(amount,0.1,'loess');
[week, wp] = weeklyPaper(amount);

subplot(2,1,1)
plot(day,amount)

subplot(2,1,2)
plot(day,smoothedSet)