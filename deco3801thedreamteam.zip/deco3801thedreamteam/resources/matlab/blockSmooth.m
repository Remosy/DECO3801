function [day, amount] = blockSmooth(startDOY, endDOY, papers)

day = [1:365]';
amount = zeros(size(day));

allData = [startDOY, papers];
    % Loop through
    for i = 1:365
        dayData = allData(find(startDOY == i),2);
        amount(i) = mean(dayData);
        if isnan(amount(i))
           amount(i) = 0; 
        end

    end
end