function out = dateAddition(A, B) 
    % Convert to vector format
    A = datevec(A);
    B = datevec(B);
    
    % Plus together
    C = A + B;
    
    % Back to datetime format
    out = datetime(C);
end