function out = filterDay(startDOY)
    count = 0;
    
    for i = 1:size(startDOY,1)
       if startDOY(i) == 340
          count = count + 1;
       end
       
       if count == 2
          out = i;
          return 
       end
    end
end