<?php
class Printer {
    public $Printer;
    public $Location;
    public $Stamp;
    public $Uptime;
    public $Status;
    public $Paper;
    public $Tray1;
    public $Tray2;
    public $Tray3;
    public $Tray4;
    public $TonerBlack;
    public $TonerCyan;
    public $TonerMagenta;
    public $TonerYellow;
    public $InkCyan;
    public $InkMagenta;
    public $InkYellow;
    public $InkGray;
    public $InkMatteBlack;
    public $InkPhotoBlack;
    public $HeadGrayPhotoBlack;
    public $HeadMatteBlackYellow;
    public $HeadMagentaCyan;
    
    public function toJSON($previousPrinter = null) {
        return "{\"id\": \"$this->Printer\", \"Location\": \"$this->Location\", \"Paper\": \"$this->Paper\", \"PaperChange\": \"" . (($previousPrinter == null) ? 0 : (($this->Paper - ($previousPrinter == null ? 0 : $previousPrinter->Paper)))) . "\", \"Stamp\": \"$this->Stamp\", \"Uptime\": \"$this->Uptime\", \"Status\": \"" . $this->Status . "\"}";
    }
}
?>
