<?php
class DAO {
    protected $connection;
    
    public function __construct($test = false) {
        $this->connection = $this->getConnection($test);
    }
    
    /*
    *   Gets the MYSQL connection and sets some attributes to make it perform better.
    */
    private function getConnection($test) {
        
        $dbHost = "localhost";
        if($test === false) {
            $dbName = "printer";
        } else {
            $dbName = "printer_test";
        }
        $dbUser = "default_user";
        $dbPassword = "aKmfWXUhyc3HtCB3";
        $connection = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPassword);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $connection->setAttribute(PDO::ATTR_ORACLE_NULLS, PDO::NULL_TO_STRING);
        $connection->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, FALSE);
        $connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);
        $connection->setAttribute(PDO::ATTR_STRINGIFY_FETCHES, FALSE);

        return $connection;
    }
}

?>