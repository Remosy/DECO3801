<?php

class PrinterDAO extends DAO {
    
    public function __construct($test = false) {
        parent::__construct($test);
        
    }
    
    /*
    *   Returns an Array of all printer ID's.
    */
    public function getAllPrinterIDs() {
        $stmt = $this->connection->prepare('
        SELECT DISTINCT(Printer)
        FROM SNMPHistory 
        ORDER BY Printer ASC');
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        return $row;
    }
    
    /*
    *   Fetches printer information between $startDate and $endDate
    *   Returns an Array of Printer on success or null on  failure.
    */
    public function fetchPrinterBetweenDates($startDate, $endDate, $printer) {
        $stmt = $this->connection->prepare('
        SELECT Printer, Location, Stamp, Uptime, Status, 
            (COALESCE(Tray1, 0) + COALESCE(Tray2, 0) + COALESCE(Tray3, 0) + COALESCE(Tray4, 0)) as Paper
        FROM SNMPHistory 
        WHERE Stamp >= :startDate 
            AND Stamp <= :endDate 
            AND Printer = :printer ' 
        . ' AND Status NOT LIKE "%other%"'
        . ' AND Status NOT LIKE "%warmup%"'
        //. ' AND Status NOT LIKE "%printing%"'
        . 'ORDER BY Stamp ASC');
        $result = $stmt->execute(array('startDate' => $startDate, 'endDate' => $endDate, 'printer' => $printer));
        
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Printer");
        $row = $stmt->fetchAll();
        
        
        return ($result === false) ? null : $row;
    }

    /*
    * Fetches Printers that are online for the current date
    * Returns an Array of Printer on success or null on failure.
    */
    public function getPrintersForDay($date) {
        $stmt = $this->connection->prepare('
        SELECT Printer, Stamp, Location, Uptime, Status, 
            (COALESCE(Tray1, 0) + COALESCE(Tray2, 0) + COALESCE(Tray3, 0) + COALESCE(Tray4, 0)) as Paper 
        FROM SNMPHistory 
        WHERE Stamp >= :start
        AND Stamp < :end
        GROUP BY Printer ORDER BY Stamp DESC');
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Printer");
        
        $result = $stmt->execute(array('end' => date('Y-m-d', strtotime($date . "+1 Day")),
                "start" => date('Y-m-d', strtotime($date))
            ));
        
        $row = $stmt->fetchAll();
        
        return ($result === false) ? null : $row;
        
    }
    /*
    * Fetches Printers that are online for the current date
    * Returns an Array of Printer on success or null on failure.
    */
    public function getPrintersWithTrend($date) {
        $stmt = $this->connection->prepare('
        SELECT Printer, Stamp, Location, Uptime, Status, 
            (COALESCE(Tray1, 0) + COALESCE(Tray2, 0) + COALESCE(Tray3, 0) + COALESCE(Tray4, 0)) as Paper,
            (SELECT latitude FROM nodes where id=Printer) as latitude,
			(SELECT longitude FROM nodes where id=Printer) as longitude
        FROM SNMPHistory 
        WHERE Stamp >= :start
        AND Stamp <= :end
        AND Status NOT Like "%other%"
        AND Status NOT Like "%warmup%"
        ORDER BY Printer,Stamp DESC');
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Printer");
        
        $result = $stmt->execute(array('start' => date('Y-m-d', strtotime($date . "-3 Days")),
                "end" => date('Y-m-d', strtotime($date))
            ));
            
        
        $row = $stmt->fetchAll();
        
        return ($result === false) ? null : $row;
        
    }
    
    
    /*
    * Fetches printers from when they were last online. $date should be of format YYYY-mm-dd H:i:s
    * Returns an Array of Printer on success or null on failure.
    */
    public function fetchLastKnownGoodPrinterState($date) {
        $stmt = $this->connection->prepare('
        SELECT Printer, MAX(Stamp) as Stamp, Location, Uptime, Status, 
            (COALESCE(Tray1, 0) + COALESCE(Tray2, 0) + COALESCE(Tray3, 0) + COALESCE(Tray4, 0)) as Paper 
        From SNMPHistory 
        WHERE Stamp <= :date
        GROUP by Printer DESC');
        $result = $stmt->execute(array('date' => $date));
        
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Printer");
        $row = $stmt->fetchAll();
        
        return ($result === false) ? null : $row;
    }
    
    
    /**
    *   Fetches a specific printer based on its ID and Stamp
    *
    *   @return Printer on success, Null otherwise
    */
    public function getPrinterByStamp($printer) {
        $stmt = $this->connection->prepare('
            SELECT Printer, MAX(Stamp) as Stamp, Location, Uptime, Status, 
            (COALESCE(Tray1, 0) + COALESCE(Tray2, 0) + COALESCE(Tray3, 0) + COALESCE(Tray4, 0)) as Paper 
        From SNMPHistory 
        WHERE 
            Stamp = :Stamp AND 
            Printer = :Printer');
        
        $result = $stmt->execute(array(
            "Stamp" => $printer->Stamp,
            "Printer" => $printer->Printer));
        
        
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Printer");
        $row = $stmt->fetch();
        
        return ($result === false ? null : ($row == new Printer()) ? null : $row);
    }
    
    /*
    *   Inserts a printer into the database
    *   Returns true on success
    */
    public function create($printer) {
        $stmt = $this->connection->prepare('
        INSERT INTO SNMPHistory (Printer, Location, Stamp, Uptime, Status, TonerBlack, TonerCyan, TonerMagenta, TonerYellow, Tray1, Tray2, Tray3, Tray4, InkCyan, InkMagenta, InkYellow, InkGray, InkMatteBlack, InkPhotoBlack, HeadGrayPhotoBlack, HeadMatteBlackYellow, HeadMagentaCyan) VALUES(:Printer, :Location, :Stamp, :Uptime, :Status, :TonerBlack, :TonerCyan, :TonerMagenta, :TonerYellow, :Tray1, :Tray2, :Tray3, :Tray4, :InkCyan, :InkMagenta, :InkYellow, :InkGray, :InkMatteBlack, :InkPhotoBlack, :HeadGrayPhotoBlack, :HeadMatteBlackYellow, :HeadMagentaCyan)');
        return $stmt->execute(array(
            'Printer' => ($printer->Printer), 
            'Location' => ($printer->Location), 
            'Stamp' => ($printer->Stamp), 
            'Uptime' => ($printer->Uptime), 
            'Status' => ($printer->Status),
            'TonerBlack' => ($printer->TonerBlack),
            'TonerCyan' => ($printer->TonerCyan),
            'TonerMagenta' => ($printer->TonerMagenta),
            'TonerYellow' => ($printer->TonerYellow),
            'Tray1' => ($printer->Tray1),
            'Tray2' => ($printer->Tray2),
            'Tray3' => ($printer->Tray3),
            'Tray4' => ($printer->Tray4),
            'InkCyan' => ($printer->InkCyan),
            'InkMagenta' => ($printer->InkMagenta),
            'InkYellow' => ($printer->InkYellow),
            'InkGray' => ($printer->InkGray),
            'InkMatteBlack' => ($printer->InkMatteBlack),
            'InkPhotoBlack' => ($printer->InkPhotoBlack),
            'HeadGrayPhotoBlack' => ($printer->HeadGrayPhotoBlack),
            'HeadMatteBlackYellow' => ($printer->HeadMatteBlackYellow),
            'HeadMagentaCyan' => ($printer->HeadMagentaCyan)
        ));
        
    }
   
    /*
    *   Updates a printer from the database
    */
    public function update($printer) {
        $stmt = $this->connection->prepare('
        UPDATE SNMPHistory 
        SET
            Printer = :Printer,
            Location = :Location, 
            Stamp = :Stamp, 
            Uptime = :Uptime, 
            Status = :Status, 
            Tray1 = :Tray1, 
            Tray2 = :Tray2, 
            Tray3 = :Tray3, 
            Tray4 = :Tray4, 
            TonerBlack = :TonerBlack, 
            TonerCyan = :TonerCyan, 
            TonerMagenta = :TonerMagenta, 
            TonerYellow = :TonerYellow, 
            InkCyan = :InkCyan, 
            InkMagenta = :InkMagenta, 
            InkYellow = :InkYellow, 
            InkGray = :InkGray, 
            InkMatteBlack = :InkMatteBlack, 
            InkPhotoBlack = :InkPhotoBlack, 
            HeadGrayPhotoBlack = :HeadGrayPhotoBlack, 
            HeadMatteBlackYellow = :HeadMatteBlackYellow, 
            HeadMagentaCyan = :HeadMagentaCyan
        WHERE
            Printer = :PrinterID AND
            Stamp = :StampID
        ');
        
        return $stmt->execute(array(
            'Printer' => ($printer->Printer), 
            'Location' => ($printer->Location), 
            'Stamp' => ($printer->Stamp), 
            'Uptime' => ($printer->Uptime), 
            'Status' => ($printer->Status),
            'TonerBlack' => ($printer->TonerBlack),
            'TonerCyan' => ($printer->TonerCyan),
            'TonerMagenta' => ($printer->TonerMagenta),
            'TonerYellow' => ($printer->TonerYellow),
            'Tray1' => ($printer->Tray1),
            'Tray2' => ($printer->Tray2),
            'Tray3' => ($printer->Tray3),
            'Tray4' => ($printer->Tray4),
            'InkCyan' => ($printer->InkCyan),
            'InkMagenta' => ($printer->InkMagenta),
            'InkYellow' => ($printer->InkYellow),
            'InkGray' => ($printer->InkGray),
            'InkMatteBlack' => ($printer->InkMatteBlack),
            'InkPhotoBlack' => ($printer->InkPhotoBlack),
            'HeadGrayPhotoBlack' => ($printer->HeadGrayPhotoBlack),
            'HeadMatteBlackYellow' => ($printer->HeadMatteBlackYellow),
            'HeadMagentaCyan' => ($printer->HeadMagentaCyan),
            'StampID' => ($printer->Stamp),
            'PrinterID' => ($printer->Printer), 
        ));
    }
    
    /*
    *   Deletes a printer from the database
    */
    public function delete($printer) {
        $stmt = $this->connection->prepare('
            DELETE FROM SNMPHistory WHERE 
                Printer = :Printer AND
                Stamp = :Stamp
                ');
                
        return $stmt->execute(array(
            'Printer' => $printer->Printer, 
            'Stamp' => $printer->Stamp
        ));
    }
    
}
?>
