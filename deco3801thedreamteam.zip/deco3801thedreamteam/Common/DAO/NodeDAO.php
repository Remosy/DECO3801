<?php

/*
*   A Class to manage database interactions for Nodes
*/
class NodeDAO extends DAO {
    
    public function __construct($test = false) {
        parent::__construct($test);
    }
    
    /*
    *   Returns an Array of all Nodes.
    *   Returns array of length 0 on not found
    *   Returns false on failure
    */
    public function getAllNodes() {
        $stmt = $this->connection->prepare('
            SELECT *
            FROM nodes 
        ORDER BY id ASC');
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Node");
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        
        return ($row === false ? null : $row);
    }
    
    /*
    *   Returns an Array of all Nodes.
    *   Returns array of length 0 on not found
    *   Returns false on failure
    */
    public function getAllBuildings() {
        $stmt = $this->connection->prepare('
            SELECT *
            FROM nodes WHERE PrinterName = "E"
        ORDER BY id ASC');
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Node");
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        
        return ($row === false ? null : $row);
    }
    /*
    *   Populates all items in $nodes with DistanceNodes
    */
    public function linkNodes(&$nodes) {
        $tempLinks = array();
        
        foreach($nodes as &$n) {
            $tempLinks = $this->getLinkedNodes($n);
            if($tempLinks !== false && $tempLinks !== null) {
                $n->addLinks($tempLinks);
            }
        }
        
    }
    
    /*
    *   Returns an array of NodeDistance where $node is either the start or end Node
    *   Returns an array of zero length on no links found
    *   Returns null on failure
    */
    public function getLinkedNodes($node) {
    $stmt = $this->connection->prepare('
        SELECT *,
        (SELECT CONCAT(nodes.buildingName, "-", nodes.printerName) FROM nodes WHERE id=node_distances.startNode) as startNodeName,
        (SELECT CONCAT(nodes.buildingName, "-", nodes.printerName) FROM nodes WHERE id=node_distances.endNode) as endNodeName
        FROM node_distances
        WHERE startNode = :startID 
            OR endNode = :endId');
        $stmt->execute(array('startID' => $node->id, 'endId' => $node->id));
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NodeDistance");
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        
        return ($row === false ? null : $row);
    }
    
    
    private function getNodeLinks($node) {
        $stmt = $this->connection->prepare('
        SELECT * FROM node_distances WHERE startNode = :startID OR endNode = :endId');
        $stmt->execute(array('startID' => $node->id, 'endId' => $node->id));
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NodeDistance");
        $row = $stmt->fetchAll();
        $stmt->closeCursor();
        
        return ($row === false ? null : $row);
    }
    
    public function create($node) {
        $stmt = $this->connection->prepare('
            INSERT INTO nodes (id, buildingName, printerName, latitude, longitude) VALUES(:id, :buildingName, :printerName, :lat, :lng)');
            
        $result = $stmt->execute(array(
            'id' => ($node->id), 
            'buildingName' => ($node->buildingName), 
            'printerName' => ($node->printerName),
            'lat' => ($node->latitude),
            'lng' => ($node->longitude)));
            
        
        $storedLinks = $this->getNodeLinks($node);
        
        foreach($node->linkedTo as $linkedNode) {
            if($linkedNode->insideArray($storedLinks) === false) {
                $stmt = $this->connection->prepare('
                    INSERT INTO node_distances (startNode, endNode, distanceTime, distanceMeters) VALUES(:startNode, :endNode, :distanceTime, :distanceMeters)');
                $result = $stmt->execute(array(
                    'startNode' => $linkedNode->startNode,
                    'endNode' => $linkedNode->endNode,
                    'distanceTime' => $linkedNode->distanceTime,
                    'distanceMeters' => $linkedNode->distanceMeters
                ));

            }
        }
        return true;
        
    }
    
    public function delete($node) {
        $stmt = $this->connection->prepare('
            DELETE FROM nodes WHERE
            id = :id');
        return $stmt->execute(array('id' => $node->id));
        
    }
    
    public function deleteNodeDistance($nodeDistance) {
        $stmt = $this->connection->prepare('
            DELETE FROM node_distances WHERE
            startNode= :startNode AND endNode = :endNode');
        return $stmt->execute(array('startNode' => $nodeDistance->startNode, "endNode" => $nodeDistance->endNode));
        
    }
    public function updateNode($node) {
        $stmt = $this->connection->prepare('
            UPDATE nodes SET
                id = :nodeID,
                buildingName = :buildingName,
                printerName = :printerName
            WHERE
                id = :id
            ');
        return $stmt->execute(array(
            'id' => $node->id,
            'nodeID' => $node->id,
            'buildingName' => $node->buildingName,
            'printerName' => $node->printerName,
            ));
    }
    
    
    
    public function updateNodeDistance($nodeDistance) {
        $stmt = $this->connection->prepare('
            UPDATE node_distances SET
            startNode = :startNodeID,
            endNode = :endNodeID,
            distanceTime = :distanceTime,
            distanceMeters = :distanceMeters
            WHERE 
            startNode = :startNode AND
            endNode = :endNode');
        return $stmt->execute(array(
            'startNode' => $nodeDistance->startNode,
            'endNode' => $nodeDistance->endNode,
            'distanceTime' => $nodeDistance->distanceTime,
            'distanceMeters' => $nodeDistance->distanceMeters,
            'startNodeID' => $nodeDistance->startNode,
            'endNodeID' => $nodeDistance->endNode
        ));
    }
}
?>