<?php
    
/*
*   A simple class representing a Node in a Graph
*/
class Node {
    public $id;
    public $buildingName;
    public $printerName;
    public $latitude;
    public $longitude;
    
    public $linkedTo; // Array of NodeDistances
    
    public function __construct() {
        $this->linkedTo = array();
    }
    
    /*
    *   Associates a NodeDistance with $this
    */
    public function addLink($nodeDistance) {
        $this->linkedTo[] = $nodeDistance;
    }
    
    /*
    *   Associates an Array of NodeDistance with $this
    */
    public function addLinks(&$nodeDistance) {
        foreach($nodeDistance as $node) {
            $this->linkedTo[] = $node;
			// Add the reverse as well
			
			$nReverse = new NodeDistance();
			$nReverse->startNode = $node->endNode;
			$nReverse->startNodeName = $node->endNodeName;
			$nReverse->endNode = $node->startNode;
			$nReverse->endNodeName = $node->startNodeName;
			$nReverse->distanceMeters = $node->distanceMeters;
			$nReverse->distanceTime = $node->distanceTime;
			
			$this->linkedTo[] = $nReverse;
        }
    }
    
    /*
    *   Returns True iff $this represents a building
    */
    public function isBuilding() {
        return $this->printerName === "E";
    }
    
    
    /*
    *   Returns the String representation of this class
    */
    public function __toString() {
        return $this->buildingName . "-" . $this->printerName;
    }
    
    public function toJSON() {
        return "\"$this->buildingName-$this->printerName\": {\"lat\": $this->latitude, \"lng\": $this->longitude, \"visited\": false, \"name\": \"$this->buildingName-$this->printerName\"}";
    }
    
    /*
    *   Returns a JS representation of a Node
    */
    public function toNode() {
        return "\"$this->buildingName-$this->printerName\": new Node(\"$this->buildingName-$this->printerName\", $this->latitude, $this->longitude)";
    }
}


?>