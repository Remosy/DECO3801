<?php

/*
*   A simple class to represent the distance between two Nodes
*/
class NodeDistance {
    public $startNode;
    public $endNode;
    public $distanceTime;
    public $distanceMeters;
    
    // Weak Entities
    public $startNodeName;
    public $endNodeName;
    
    /*
    *   Two NodeDistance are equal if they have the same endPoints
    */
    public function equals(&$other) {
        if($this->startNode == $other->startNode && $this->endNode == $other->endNode) {
            return true;
        }
        
        if($this->startNode == $other->endNode && $this->endNode == $other->startNode) {
            return true;
        }
		return false;
    }
    
    /*
    *   Returns True if $nodeDistanceList contains $this according to the $this->equals() method
    */
    public function insideArray($nodeDistanceList) {
        foreach($nodeDistanceList as $d) {
            if($this->equals($d))
                return true;
        }
        return false;
    }
    
    public function __toString() {
        return "\"$this->startNodeName\", \"$this->endNodeName\", $this->distanceMeters";
    }
    
    public function toEdge() {
        return "new Edge(\"$this->startNodeName\", \"$this->endNodeName\", $this->distanceMeters)";
    }
    
}
?>