<?php

require_once("includes.php");
require_once("uq/auth.php");

if(auth_get_payload() !== false) {
    
    header("Location: index.php");
}

if(isset($_POST["register"])) {
    // Register
}
if(isset($_POST["login"]) && isset($_POST["password"])) {
   // Login
}

if(isset($_POST["SSO"])) {
    auth_require();
    if(auth_get_payload() !== false) {
        header("Location: index.php");
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/reset.css" />
<link rel="stylesheet" href="css/style.css" />

<script type="text/Javascript" src="js/ThirdParty/jquery.js"></script>
</head>
<body>
<form class="overlayForm" action="login.php" method="POST">
    <div class="formItems">
        <div class="formHeader">
            <div><img src="img/Logo_new.png" alt="PaperFactory! Logo" /><h1>Paper<br />Factory</h1></div>
        </div>
        <h3>Login Form</h3>
        <div class="formPair">
            <label for="formUsermame">Username: </label><input id="formUsermame" type="text"/>
        </div>
        <div class="formPair">
            <label for="formPassword">Password: </label><input id="formPassword" type="password" />
        </div>
        <div class="formFooter">
            <input type="submit" value="Login" name="login" /><input type="submit" value="Register" name="register"/><input type="submit" value="Single Sign On" name="SSO" />
        </div>
    </div>
</form>
</body>
</html>
