function PaperVisualisation(printerData) {
    this.updateTimeout = -1;
    var self = this;
    self.printerData = printerData;
    
    $("#printerInfoTableContainer table").on("click", "tr:gt(0)", function(event) {
        
        var headings = $("#printerOverviewOverlay h2");
        var cells = $(this).find("td");
        if(cells.length == 1) {
            return;
        }
        
        headings[0].innerHTML = "Printer ID: " + cells[0].innerHTML;
        headings[1].innerHTML = "Location: " + cells[1].innerHTML;
        headings[2].innerHTML = "Paper Level: " + cells[2].innerHTML;
        
        
        $("#printerOverviewOverlay").fadeIn(500, function() {
            if($("#printerMapContainer").children().length == 0) {
                self.map = new google.maps.Map($('#printerMapContainer').get(0), {
                  zoom: 16,
                  center: {lat: -27.500272, lng: 153.013891}
                });
            }
            var printer;
            var dataPoints = "";
            var dataLabels = "";
            for(var i in self.printerData) {
                
                if(self.printerData[i].id == cells[0].innerHTML) {
                    printer = self.printerData[i];
                    for(var z in printer.printerData) {
                        dataPoints += (dataPoints == "" ? "" : ", ") + printer.printerData[z].Paper;
                        dataLabels += (dataLabels == "" ? "" : ", ") + printer.timeStamps[z];
                    }
                    break;
                }
            }
            if(self.marker !== undefined) {
                self.marker.setPosition(printer);
            } else {
                self.marker = new google.maps.Marker({
                position: printer,
                map: self.map,
                icon: new google.maps.MarkerImage(
                    'img/nodes/marker.png',
                    new google.maps.Size(48, 48),
                    new google.maps.Point(0, 0),
                    new google.maps.Point(16, 48)
                )
            });
            }
            
            $("#currentLineChart").attr("data-data", "");
            $("#currentLineChart").attr("data-labels", "");
            $("#printerOverview a").attr("href", "?action=ViewPath&startingNode=" + printer.location.split("-")[0] + "-E");
            $("#currentLineChart").attr("data-data", dataPoints);
            $("#currentLineChart").attr("data-labels", dataLabels);
            if($("#currentLineChart")[0].chart !== undefined) {
                $("#currentLineChart")[0].chart.destroy();
            }
            
            self.makeChart("currentLineChart", {pointDotRadius: 1}, 1, 2);
        });
        
        
    });
    
    $("#printerOverviewOverlay button").on("click", function() {
        $("#printerOverviewOverlay").fadeOut(); 
    });
}

/*
*   Replaces the chart found at id with a Bar chart with values from its own DOM element.
*   If no chart exists one is made.
*/
PaperVisualisation.prototype.makeChart = function(id, options, wScale, hScale) {
    var canvas = $("#" + id);
    var self = this;
    var pWidth = canvas.parent().width();
    var pHeight = canvas.parent().height();
    canvas.attr({width: pWidth/wScale, height: pHeight/hScale});
    var printerLabels = canvas.attr("data-labels").split(",");
    var printerData = canvas.attr("data-data").split(",");
    var trendColour = "rgba(102,157,185,1)";
    
    if(printerLabels.length == 1) {
        printerData.push(printerData[0]);
        printerLabels.push(printerLabels[0]);
    }
    
    if(options.showTrendColour === true) {
        if(printerData[0] - printerData[printerData.length -1] >= 0) {
            trendColour = "rgba(102,157,185,1)";
        } else if(Math.abs(printerData[0] - printerData[printerData.length -1]) < 60) {
            trendColour = 'orange';
        } else {
            trendColour = 'red';
        }
    }
    
    newChart = new Chart(canvas[0].getContext("2d")).Line({
            labels: printerLabels, // Labels for data
            
            datasets: [{
                label: 'Printer Paper Levels',
                fillColor: 'transparent', // Fill of bars
                strokeColor: trendColour, // Stroke of bars
                highlightFill: 'rgba(151,187,205,0.75)',
                highlightStroke: 'rgba(151,187,205,1)',
                
                data:  printerData// Data Y values
            }]
        
        }, options);

    canvas[0].chart = newChart;
};


PaperVisualisation.prototype.redrawCharts = function() {
    var self = this;
    var table = $("#printerInfoTableContainer table tbody");
    $(table).find("tr").remove();
    
    if(self.printerData.length == 0) {
        table.append("<tr class='disabled'><td style='padding: 50px 0px' colspan='4'>No data to display for selected date</td></tr>")
    }
    
    
    for(var i in self.printerData) {
        var chartId = 'barChart-' + self.printerData[i].printerData[0].id;
        
        // Only pick out distinct timestamp values
        var labels = [];
        var points = [];
        var lastValue;
        for(var z in  self.printerData[i].lineValues) {
            var paper = self.printerData[i].lineValues[z];
            if(lastValue !== paper) {
                points.push(paper)
                labels.push(self.printerData[i].timeStamps[z])
            }
            lastValue = paper;
        }
        var addImage = (parseInt(self.printerData[i].printerData[0].Paper) < 50 ? "<img src='img/warning.png' alt='Critical Paper Level'/>" : "")
        table.append($("<tr>" +
            "<td>" + self.printerData[i].printerData[0].id + "</td>" + // PrinterID
            "<td>" + self.printerData[i].printerData[0].Location + "</td>" + // Location
            "<td>" + self.printerData[i].printerData[0].Paper + addImage + "</td>" + // Paper Level
            "<td><canvas data-data=\"" + points + "\" data-labels=\"" + labels + "\"class='chart' id='" + chartId + "'></canvas></td>" + // Trend
        "</tr>"));
        self.makeChart(chartId, {scaleFontSize: 0, showScale: false, tooltipenabled: false, showTrendColour: true, showTooltips: false, pointDotRadius: 1}, 4, 4)
    }

}
/*
*   Updates the Paper Visualisation chart when the slider changes the date
*/
PaperVisualisation.prototype.getMostRecentPrinterDataForDay = function(chartID, time) {
    var self = this;
    jQuery.getJSON("api/getMostRecentPrinterInfo.php?date=" + time, function(data) {
        self.printerData = data;
        self.redrawCharts();
    });
}

PaperVisualisation.prototype.updateData = function() {
    var self = this;
    var date = $("#datePicker").val();
    self.getMostRecentPrinterDataForDay("todaysBarChart", date);
}


/*
*   Export Required for QUnit
*/
if (typeof module != 'undefined' && module.exports) {
  module.exports = {
    PaperVisualisation: PaperVisualisation
  }
  var google = {
      maps: {
          Marker: function(a) { 
                return { };
          },
          Size: function() {},
          Map: function() { },
          Point: function() {},
          MarkerImage: function() {},
          TravelMode: {
              WALKING: 1
          },
          DirectionsStatus: {
              OK: 1
          }
      }
  }
  var mockJQueryObject = {
      0: {},
      1: {},
      2: {},
      on: function(a,b,c) { 
        if(typeof b === "function") b();
        if(typeof c === "function") c();
        
        return mockJQueryObject; 
      },
      chart: mockJQueryObject,
      get: function() { return mockJQueryObject },
      append: function() { return mockJQueryObject },
      height: function() { return mockJQueryObject },
      parent: function() { return mockJQueryObject },
      width: function() { return mockJQueryObject },
      val: function() { return "" },
      find: function(a) { 
        if(a == "td" && typeof PaperVisualisation.cellLength === 'undefined') {
            var ret = [];
            ret[0] = {innerHTML: 4};
            ret[1] = {innerHTML: 4};
            ret[2] = {innerHTML: 4};
            return ret;
        } else if(a == "td") {
            var ret = [];
            ret[0] = {innerHTML: 4};
            return ret;
        }
        return mockJQueryObject;
      },
      remove: function() { return mockJQueryObject; },
      getContext: function(){ return mockJQueryObject; },
      attr: function() { return mockJQueryObject },
      split: function() {
        if(PaperVisualisation.split == 0)
            return [0,100];
        else if(PaperVisualisation.split == 1)
            return [1];
        
        return [1,2,3,4];
      },
      fadeIn: function(a, b) { 
        b();
        return mockJQueryObject;
      },
      fadeOut: function() {},
    getJSON: function(a,b) {
        if(PaperVisualisation.t == 0) {
            b([{
                id: "2", location: "51-508", lat: "-27.78", lng: "153.34", 
                printerData: [{
                    id: "2",
                    Location: "51-508",
                    Paper: "250",
                    PaperChange: "0",
                    Stamp: "2014-03-31 20:59:01",
                    Uptime: "176211385",
                    Status: "printing(4)"
                }, {
                    id: "2",
                    Location: "51-508",
                    Paper: "250",
                    PaperChange: "0",
                    Stamp: "2014-03-31 20:58:01",
                    Uptime: "176205386",
                    Status: "idle(3)"
                }],
                    timeStamps: ["2014-03-31 20:59:01", "2014-03-31 20:58:01"],
                    lineValues: ["250", "250"]
            }]);
        } else if(PaperVisualisation.t == 1) {
            b([{
                id: "2", location: "51-508", lat: "-27.78", lng: "153.34", 
                printerData: [{
                    id: "2",
                    Location: "51-508",
                    Paper: "0",
                    PaperChange: "0",
                    Stamp: "2014-03-31 20:59:01",
                    Uptime: "176211385",
                    Status: "printing(4)"
                }, {
                    id: "2",
                    Location: "51-508",
                    Paper: "250",
                    PaperChange: "0",
                    Stamp: "2014-03-31 20:58:01",
                    Uptime: "176205386",
                    Status: "idle(3)"
                }],
                    timeStamps: ["2014-03-31 20:59:01", "2014-03-31 20:58:01"],
                    lineValues: ["250", "250"]
            }]);
        } else if(PaperVisualisation.t == 2) {
            
        } else {
            b([]);
        }
        
    },
    value: "43-E"
  };
  
  var $ = function(a) {
    if(a === "#printerMapContainer") {
        var ret = mockJQueryObject;
        ret.children = function() { return {length: 0} };
        return ret;
    } else if (a === "#currentLineChart") {
        var ret = mockJQueryObject;
        ret[0] = mockJQueryObject;
        return ret;
    }
    
    return mockJQueryObject;
  };
  
  var jQuery = mockJQueryObject;
  
  function Chart() {
    return mockChartObject;
  }
  
  
  var mockChartObject = {
    Line: function() { return mockChartObject; },
    destroy: function() {}
  }
}