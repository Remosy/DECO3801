 $(document).ready(function() {
	var map; 
	var id_list = new Array();	
	var currnt_printerID = "";
	var start_date;
	var end_date;
	var LevelEvent;//Previous Level = 1, Upcoming Level = 3
	 /**
		 (Previous/Current/Upcoming)Levels --- UI Select
	 */
	$("#timeButtonsContainer a").click(function(event){
		$("#timeButtonsContainer a").removeClass("selectedTab");
		$(this).addClass("selectedTab");
		if(this.id == "selectPreviousLevels"){
			DisplayDatesPicker();
		}else if(this.id == "selectUpcomingLevels"){
			LevelEvent = 3;
			$("#datesPicker").empty();
		}else{
			$("#datesPicker").empty();
			start_date ="";
			end_date="";
			LevelEvent="";
		};
	});
	 
	 
	 /**
		 Previous Level --- DatePiker
	 */	
	function DisplayDatesPicker(){
		//Load dates picker
		 var html = '<script>var start = $("#startDate").datepicker({defaultDate: "+1w",changeMonth: true,numberOfMonths: 1,maxDate: "-1D",dateFormat:"yy-mm-dd"});'
		 			+'var end = $("#endDate").datepicker({defaultDate: "+1w",changeMonth: true,numberOfMonths: 1,maxDate: "-1D",dateFormat:"yy-mm-dd"})'
		 			+'.on( "change", function(){start.datepicker( "option", "minDate", getDate( this ) );});'
		 			+'function getDate(element){var date;try {date = $.datepicker.parseDate( element.value );} catch( error ) {date = null;}return date;}'
		 			+'function resetDate(element){var id = element.previousSibling.id; $("#"+id).val("");if(id="StarDate"){start_date = "";}else{end_date = "";}}'
		 			+'</script>'
		 			+'<label class="datePickerLabel">Start Date</label>'
		 			+'<input id="startDate" type="text" readonly>'
			 		+'<span class="glyphicon glyphicon-trash" onclick="resetDate(this)"></span>'
			 		+'<label class="datePickerLabel">End Date</label>'
			 		+'<input id="endDate" type="text" readonly>'
			 		+'<span class="glyphicon glyphicon-trash" onclick="resetDate(this)"></span>';
		 $("#datesPicker").html(html); 
	}
	/**
		Previous Level --- DatePiker_Verify
	*/
	function verifyDates(startDate,endDate){
		if(Date.parse(startDate)>=Date.parse(endDate)){
			$("#startDate").css("background-color","#ff6183");		
		}else{
			$("#startDate").css("background-color","#ffffff");	
		}
	}
	 
	 
	 /**
		 Printer List --- Sparkline CHARTS
	 */
	function makeChart(id_list){
		for(var id=0;id< id_list.length; id++){
			var url = "https://thedreamteam.uqcloud.net/paperfactoryapi/v1/printers/"+id_list[id]+"/media_levels";
			draw(id_list[id],url);
	    }	
	}

	function getMediaAmounts(reply, mediaTypeName) {
		for(var i = 0; i < reply.length; i++) {
			if(reply[i].media_type === mediaTypeName) {
				return reply[i].amounts;
			}
		}
	}
	
	function draw(id,link){
		var div = "#trend_"+id;
		var printerData = [];
		$.getJSON(link, function(reply){
			var tray1Amounts = getMediaAmounts(reply, 'Tray1');
			var trendColour;
			for(var i = 0; i< tray1Amounts.length;i++){
			    printerData.push(tray1Amounts[i].amount);
			}
			
		    if(printerData[0] - printerData[printerData.length -1] >= 0) {
		            trendColour = "rgba(102,157,185,1)";
		    } else if(Math.abs(printerData[0] - printerData[printerData.length -1]) < 60) {
		            trendColour = 'orange';
		    } else {
		            trendColour = 'red';
		    }
			
			$(div).sparkline(
			printerData, 
			{
			width:'100%',
		    type: 'line',
		    lineColor: trendColour,
		    fillColor: null,
		    spotColor: null,
		    minSpotColor: '#56ffaa',
		    maxSpotColor: '#ffff56',
		    drawNormalOnTop: false
		    }
		    );
		});
		
			
		}
	 /**
		 Printer List --- DISPLAY ALL PRINTERS
	 */
    var table = $('#allPrinterList').DataTable({
           'ajax':{
				"type"   : "GET",
				"url"    : "https://thedreamteam.uqcloud.net/paperfactoryapi/v1/printers/list",
				"dataSrc": function (json) {
							var id;
						    var data = new Array();
						    for(var i=0;i< json.length; i++){
							    id = json[i].printer_id;
							    id_list.push(id);
							    data.push({
								    'printer_id': json[i].printer_id,
							        'building_name': json[i].building_name,
							        'printer_name': json[i].printer_name,
							        'location': json[i].location.lat+","+json[i].location.lng,
							        'trend':"<div style='vertical-align: middle; display: inline-block; width: 100px; height: 30px;' id='trend_"+id+"'></div>",
							       
							    })
						    }
							return data;
				        }
			},
           "columns": [
	        { "data": "printer_id" },   
            { "data": "building_name" },
            { "data": "printer_name" },
            { "data": "location" },
            { "data": "trend"}
			],
			"columnDefs": [
			{ "visible": false, "targets": 0},
			{ "visible": false, "targets": 3}
			],
			"iDisplayLength": 50,
			"bLengthChange": false,
			"sDom": '<"top"f>rt<"bottom"p>'
	});
	
	
	
	$('#allPrinterList').on( 'draw.dt', function () {
    	makeChart(id_list);
	});
	/**
		 Printer List --- SELECT PRINTER
	*/
	$('#allPrinterList tbody').on('click', 'tr', function () {
			//Get Printer ID,Building Name & Location 
				var data = table.row($(this).children()).data();
				var printer_id = data['printer_id'];
				var printer = data['printer_name'];
				var building = data['building_name'];
				var location = (data['location']).split(',');
				var lat = JSON.parse(location[0]);
				var lng = JSON.parse(location[1]);
				  		
			//Display Dialog
				$('#printerOverviewOverlay').modal('toggle');
				  		
			//Fill in Details
				displayInfo(printer_id,printer,building,lat,lng);
	});
	
	/**
		 Printer --- INFO 
	*/
	function displayInfo(printer_id,printer,building,lat,lng){

		//first remove any old event handler, otherwise we'll have multiple
		$("#printerOverviewOverlay").off('shown.bs.modal');
		$("#printerOverviewOverlay").on('shown.bs.modal', function () {
				var modal = $(this)
				modal.find('.modal-title').text('Printer: ' + printer)
				modal.find('.PrinterBuilding').text('Building: ' + building)
				initMap(lat,lng);
				//drawChart(printer_id);
				getMediaLevels_Paper(printer_id);
				currnt_printerID = printer_id;
    	});
    	
				  		
	}
    
    /**
		 Printer --- INFO_MAP 
	*/
    function initMap(lat,lng) {
        map = new google.maps.Map(document.getElementById('printerMapContainer'), {
          center: {lat: lat, lng: lng},
          zoom: 18
        });
        var printerMarker = new google.maps.Marker({
          position: {lat: lat, lng: lng},
          map: map,
          icon: new google.maps.MarkerImage(
            'img/nodes2/marker.png',
            new google.maps.Size(48, 48),
            new google.maps.Point(0, 0),
            new google.maps.Point(24, 24),
            new google.maps.Size(40, 40)
          )
        });
      }
      
    /**
		 Printer --- INFO_CHART 
	*/	
	function getMediaLevels_Paper(printer_id){
		start_date = $("#startDate").val();
		end_date = $("#endDate").val();
		if(start_date!=null||end_date!=null){
			//Verify Dates
			verifyDates(start_date,end_date);
			LevelEvent = 1;
		}
		var url = "https://thedreamteam.uqcloud.net/paperfactoryapi/v1/printers/"+printer_id+"/media_levels?start_date="+start_date+"&end_date="+end_date;
		//alert(url);
		$.get({url: url, success: function (data) { drawChart(data, printer_id); }});
	}
	
	function drawChart(media_levels, printer_id) {

		var predictedUrl = "https://thedreamteam.uqcloud.net/paperfactoryapi/v1/printers/" + printer_id + "/media_levels_predicted";

		//if we're on future data tab, get 30 days instead of default 7
		if(LevelEvent == 3) {
			predictedUrl += "?look_ahead_days=30";
		}

		//get predicted data and add (if LevelEvent != 1)
		$.get({url: predictedUrl, success: function(predicted_levels) {

		//container for all the charts - get and clear it
		var lineChartContainer = $("#lineChartContainer");
		lineChartContainer.empty();

		//flatten data to allow direct lookup via media type associative array style
		for(var mediaIdx = 0; mediaIdx < media_levels.length; mediaIdx++) {
		
			var thisMediaType = media_levels[mediaIdx].media_type;
			var thisMediaLevelAmounts = media_levels[mediaIdx].amounts;
			var thisMediaPredictedAmounts = predicted_levels[mediaIdx].amounts;

			//TODO: if we're not on the previous levels tab, add the predicted levels with a different colour
			if(LevelEvent != 1) {
				for(var predictedLevelIdx = 0; predictedLevelIdx < thisMediaPredictedAmounts.length; predictedLevelIdx++) {
					var thisAmountEntry = thisMediaPredictedAmounts[predictedLevelIdx];
					thisAmountEntry.lineColor = "#33b70b";
					thisMediaLevelAmounts.push(thisAmountEntry);
				}
			}

			//if there's no amounts for this media type, it's not supported for printer, so skip
			if(thisMediaLevelAmounts.length == 0) {
				continue;
			}

			//add element for chart to the chart container
			var chartElementJq = $("<div style='width: 100%; height: 200px'/>");

			//add title for media type
			var mediaTypeTitleElem = $("<h3/>");
			mediaTypeTitleElem.text(thisMediaType);
			lineChartContainer.append(mediaTypeTitleElem);

			lineChartContainer.append(chartElementJq);
			var chartElement = chartElementJq.get(0);

			//create chart!
			AmCharts.makeChart(chartElement, {
			    "type": "serial",
			    "theme": "light",
			    "marginRight": 40,
			    "marginLeft": 40,
			    "marginTop": 15,
			    "autoMarginOffset": 20,
			    "mouseWheelZoomEnabled":false,
			    "valueAxes": [{
			        "id": "v1",
			        "axisAlpha": 0,
			        "position": "left",
			        "ignoreAxisWidth":true,
				"maximum": 100, //data is in 0-100 range
				"minimum": 0
			    }],
			    "balloon": {
			        "borderThickness": 1,
			        "shadowAlpha": 0
			    },
			    "graphs": [{
			        "id": "g1",
			        "balloon":{
			          "drop":true,
			          "adjustBorderColor":false,
			          "color":"#ffffff",
			          "lineColorField": "lineColor"
			        },
			        "bullet": "round",
			        "bulletBorderAlpha": 1,
			        "bulletColor": "#FFFFFF",
			        "bulletSize": 4,
			        "hideBulletsCount": 50,
			        "lineThickness": 2,
			        "fillColorsField": "lineColor",
			        "lineColorField": "lineColor",
			        "title": "red line",
			        "useLineColorForBulletBorder": true,
			        "valueField": "amount",
			        "balloonText": "<span style='font-size:12px;'>[[value]]</span>"
			    }],
			    //"chartScrollbar": {
			    //    "graph": "g1",
			    //    "oppositeAxis":false,
			    //    "offset":30,
			    //    "scrollbarHeight": 80,
			    //    "backgroundAlpha": 0,
			    //    "selectedBackgroundAlpha": 0.1,
			    //    "selectedBackgroundColor": "#888888",
			    //    "graphFillAlpha": 0,
			    //    "graphLineAlpha": 0.5,
			    //    "selectedGraphFillAlpha": 0,
			    //    "selectedGraphLineAlpha": 1,
			    //    "autoGridCount":true,
			    //    "color":"#AAAAAA"
			    //},
			    "chartCursor": {
			        "pan": true,
			        "valueLineEnabled": true,
			        "valueLineBalloonEnabled": true,
			        "cursorAlpha":1,
			        "cursorColor":"#258cbb",
			        "limitToGraph":"g1",
			        "valueLineAlpha":0.2,
			        "valueZoomable":true
			    },
			    "valueScrollbar":{
			      "oppositeAxis":false,
			      "offset":50,
			      "scrollbarHeight":10
			    },
			    "categoryField": "timestamp",
			    "categoryAxis": {
			        "parseDates": true,
				"minPeriod": "hh",
			        "dashLength": 1,
			        "minorGridEnabled": true
			    },
			    "export": {
			        "enabled": true
			    },
			     "dataProvider": thisMediaLevelAmounts
			});
			
		
			}
		}});
		
	}			
} );
