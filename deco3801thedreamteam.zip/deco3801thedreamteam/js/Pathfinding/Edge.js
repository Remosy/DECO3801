function Edge(source, destination, distance) {
    
	var self = this;
    
	self.source = (source instanceof Node) ? source : new Node(source);
	self.destination = (destination instanceof Node) ? destination : new Node(destination);
    self.distance = distance; // Distance in metres
}

Edge.prototype.indexIn = function(edgeArray) {
	var self = this;
	
	for(var i = 0; i < edgeArray.length; i++) {
		var currentEdge = edgeArray[i];
        
		if(this.source  == currentEdge.source &&
			this.destination == currentEdge.destination &&
			this.distance == currentEdge.distance) {
			return i;
		}
	}
	
	return -1;
}

/*
*   Export Required for QUnit
*/
if (typeof module != 'undefined' && module.exports) {
  module.exports = {
    Edge: Edge
  }
}