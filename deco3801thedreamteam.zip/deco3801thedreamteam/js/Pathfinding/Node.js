function Node(nodeId, lat, lng) {
    
	var self = this;
    
	self.id = nodeId; // The node ID is the NAME of the node, not the db id
    self.visited = false; // false by default
	self.lat = lat;
	self.lng = lng;
}

Node.prototype.isBuilding = function() {
	var self = this;
	
	if(self.id.slice(-1) === "E" && self.id.split("-")[1].length == 1) {
		return true;
	}
	
	return false;
}

Node.prototype.equals = function(other) {
	var self = this;
	
	// Do not compare lat/lng for now as edges have undefined lat/lng nodes
	// I.e. the link to the source/destination nodes is a weak id based link
	if(self.id == other.id){
        return true;
	}
	
	return false;
}

Node.prototype.inArray = function(nodeArray) {
	var self = this;
	
	for(var i = 0; i < nodeArray.length; i++) {
		var currentNode = nodeArray[i];
		
		if(this.id == currentNode.id) {
			return true;
		}
	
	}
	
	return false;
}

Node.prototype.indexIn = function(nodeArray) {
	var self = this;
	
	for(var i = 0; i < nodeArray.length; i++) {
		var currentNode = nodeArray[i];
		
		if(this.id  == currentNode.id) {
			return i;
		}
	}
	
	return -1;
}

/*
*   Export Required for QUnit
*/
if (typeof module != 'undefined' && module.exports) {
  module.exports = {
    Node: Node
  }
}