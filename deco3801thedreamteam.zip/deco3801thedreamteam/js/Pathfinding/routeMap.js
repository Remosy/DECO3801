var selectedPoint=[];
var startPoint=[];
var endPoint=[];
var selectedInfoWindow=[];
var map;
var travelPath;
var intRegex = /^\d+(?:\.\d\d?)?$/;
var geolocationRegex = /^(\-?\d+(\.\d+)?),\s*(\-?\d+(\.\d+)?)$/;
var routeJsonBlob;

$( document ).ready(function() {
		$("#routePlanner_calculate").prop('disabled', true);
		$("#downloadButton").prop('disabled', true);
		$( "#timeLimit" ).keyup(function() {inputVlidation();});
		$( "#startPoint" ).keyup(function() {inputVlidation();});
	
});

function initMap() {
    map = new google.maps.Map(document.getElementById('routeMap'), {
	    zoom: 17,
        center: {lat: -27.500105, lng: 153.014784}
    });
    // Create a renderer for directions and bind it to the map.
	map.directionsDisplay = new google.maps.DirectionsRenderer({map: self.map, suppressMarkers: true});
	addMark(map);
}

function addMark(map){
	var bounds = new google.maps.LatLngBounds();
	var markers = [
        ['E-43', -27.499333,153.013413],
        ['E-44', -27.499019,153.013897],
        ['E-45', -27.499607,153.013892],
        ['E-47', -27.500060,153.014555],
        ['E-49', -27.499607,153.014690],
        ['E-50', -27.500076,153.013624],
        ['E-51', -27.498947,153.014532],
        ['E-60', -27.499932,153.012176],
        ['E-74', -27.500272,153.013891],
        ['E-78', -27.500105,153.014784],
    ];

    // Loop through our array of markers & place each one on the map  
    for( i = 0; i < markers.length; i++ ) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        bounds.extend(position);
        var marker = new google.maps.Marker({
            position: position,
            map: map,
            icon: new google.maps.MarkerImage(
            'img/nodes2/' + markers[i][0] + '.png',
            new google.maps.Size(48, 48),
            new google.maps.Point(0, 0),
            new google.maps.Point(24, 24),
            new google.maps.Size(40, 40)
			),
            title: markers[i][0]
    	});
    	google.maps.event.addListener(marker,'click', function() {
         	addMarkerInfoWindow(map,this);
    	});
    }
}

function addMarkerInfoWindow(map,marker){
	selectedPoint=[];
	selectedInfoWindow=[];
	selectedPoint.push(marker);
	var contentString = 
    	'<div class="mapNode_window">'+
		'<button type="button" class="btn btn-primary" onclick="setStartMarker()">Set As Start Point</button>'+
        '</div>';
    var infowindow = new google.maps.InfoWindow({
		content: contentString,
		maxWidth: 400
	});
	infowindow.open(map,marker);
	selectedInfoWindow.push(infowindow);
}

function setStartMarker(lat, lng){
	if(startPoint.length>0){
		startPoint[0].setIcon('img/nodes2/'+startPoint[0].getTitle()+'.png');
		startPoint = [];
	}
	startPoint.push(selectedPoint[0]);
	var marker = startPoint[0];
	var lat = marker.getPosition().lat();
	var lng = marker.getPosition().lng();
	marker.setIcon('img/nodes2/person.png');
	document.getElementById('startPoint').value=lat+","+lng;
	selectedInfoWindow[0].close();
}

function setCurrentLocation() {

	//reset existing start point icon if present
	if (startPoint.length > 0) {
		startPoint[0].setIcon('img/nodes2/' + startPoint[0].getTitle() + '.png');
		startPoint = [];
	}

	if (navigator.geolocation) {
		
		navigator.geolocation.getCurrentPosition(function(pos) {
			
			document.getElementById('startPoint').value = pos.coords.latitude + "," + pos.coords.longitude;
		},
		function () {
			alert("Geolocation failed");
		});

	} else {
		alert("Browser doesn't support geolocation");
	}
}

function setEndMarker(lat, lng){
	if(endPoint.length>0){
		endPoint[0].setIcon('img/nodes2/'+endPoint[0].getTitle()+'.png');
		endPoint = [];
	}
	endPoint.push(selectedPoint[0]);
	var marker = endPoint[0];
	var lat = marker.getPosition().lat();
	var lng = marker.getPosition().lng();
	marker.setIcon('img/nodes2/end.png');
	document.getElementById('endPoint').value=lat+" , "+lng;
	selectedInfoWindow[0].close();
}

function getCaculateResult(){
	if(!($("#startPoint").val()).match(geolocationRegex)){
		return;	
	}
	$("#routeLoader").show();
	var timeLimitSeconds = parseInt(document.getElementById('timeLimit').value) * 60;
	var startPoint = document.getElementById('startPoint').value.split(',');
	var start_lat = startPoint[0];
	var start_lng = startPoint[1];
	var planner = $('select[name=planner]').val();
	var routeReqUrl = 'https://thedreamteam.uqcloud.net/paperfactoryapi/v1/plan_route?time_window_seconds='
			+ timeLimitSeconds +
			'&origin_lat=' + start_lat +
			'&origin_lng=' + start_lng +
			'&planner=' + planner;

	//jquery get
	$.get({url: routeReqUrl, success: plotRoute});
}  

function plotRoute(route){

	// save JSON so that the 'Download' button works
	var jsonRoute = JSON.stringify(route);
	routeJsonBlob = new Blob([jsonRoute], {type: "application/json"});
	var routeJsonBlobUrl = URL.createObjectURL(routeJsonBlob);
	var downloadButtonA = document.getElementById("downloadButtonA");
	downloadButtonA.download = "route.json";
	downloadButtonA.href = routeJsonBlobUrl;

	//enable download button
	$("#downloadButton").prop('disabled', false);

	//draw simple polylines representing route and return to start -
	// this is because google maps directions don't really work the
	// way we want on a pedestrian scale
	
	//if existing path, remove it from map
	if(travelPath != null) {
		travelPath.setMap(null);
	}

	//parse origin from text box
	var originText = document.getElementById('startPoint').value.split(',');

	//first build path
	var origin = {lat: parseFloat(originText[0]), lng: parseFloat(originText[1])};	
	var routePath = [origin];
	for(var i = 0; i < route.length; i++ ) {
		var nextPoint = route[i].printer.location;
		routePath.push(nextPoint);
	}

	//need to return to origin
	routePath.push(origin);

	//draw the path
	travelPath = new google.maps.Polyline({
		path: routePath,
		geodesic: false,
		strokeColor: '#FF0000',
		strokeOpacity: 1.0,
		strokeWeight: 2
	});
	travelPath.setMap(map);

	//now present the list of printers to visit on the UI
	var routeListPanel = $('#routeListPanel');
	routeListPanel.empty();
   
	var totalReward = 0; 
	for(var i = 0; i < route.length; i++) {
		var printer = route[i].printer;
		var reward = Math.round(route[i].reward);
		totalReward = totalReward + reward;
		var routeListLine = (i + 1) + '. Bldg: ' + printer.building_name + ' Printer: ' + printer.printer_name + ' Reward: ' + reward;
		var routeListLineP = $('<p/>').text(routeListLine);
		routeListPanel.append(routeListLineP);
	}
	
	//append total route reward
	routeListPanel.append('TOTAL REWARD: ' + Math.round(totalReward));

	$("#routeLoader").css('display','none');
}
function inputVlidation(){
			if(($("#timeLimit").val()).match(intRegex)){
				$("#routePlanner_calculate").prop('disabled', false);				
			}else{
				$("#routePlanner_calculate").prop('disabled', true);}
}
