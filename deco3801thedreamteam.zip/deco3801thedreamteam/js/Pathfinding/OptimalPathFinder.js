function OptimalPathFinder(nodes, weightedEdges, selectBoxID) {
    var self = this;
    self.map = null;

    self.selectBox = $("#" + selectBoxID).get(0);
    $(self.selectBox).on("change", function() { try {self.newSourceNode()} catch(e) {} });
    
    
    self.nodes = nodes;
    self.weightedEdges = weightedEdges;

    self.markerArray = [];
    self.visitIndex = 0;

    self.personalMarker = null;

    
    // Create event handlers for the sidebar check boxes
    $("#nodesToVisit").on("click", ".buttonWrapper li button", function() {
        var p = $(this).parent();
        p.parent().find(".undo").slideUp();
        p.slideUp(500, function() {
            var n = $("<button class='undo'>Undo</div>");
            n.hide();
            p.after(n);
            n.slideDown();
            try {self.visitNode(p); } catch (e) {}
            n.click(function() {
                $(this).prev().slideDown();
                n.slideUp();
                try {self.undoVisit(p); } catch (e) {}
            });
        });
    });
}

OptimalPathFinder.prototype.newSourceNode = function() {
    var self = this;
    for(var i in this.markerArray) {
        self.removeMarker(i);
    }

    self.nodes[self.selectBox.value].visited = false;

    self.startOptimalPath(self.selectBox.value);

    for(var i in self.nodes) {
        if(self.nodes[i].visited === false) {
            self.addMarker(i);
        }
    }

    self.calculateAndDisplayRoute(self.indexToNode(self.visitIndex), self.indexToNode(self.visitIndex));
    self.visitIndex = self.indexToNode(self.visitIndex).index;
}

OptimalPathFinder.prototype.visitNode = function(node) {
    var self = this;

    var nodeName = node.data("node");
    
    self.nodes[nodeName].visited = true;
    self.removeMarker(nodeName);

    if(self.nodes[nodeName].index == self.visitIndex) {
        var startNode = self.nodes[nodeName];
        var nextNode = self.nextUnvisitedNode(startNode.index);
        if(nextNode == null) {
            self.calculateAndDisplayRoute(startNode, startNode);
        } else {
            self.visitIndex = nextNode.index;
            self.calculateAndDisplayRoute(startNode, nextNode);
        }
    }
}

OptimalPathFinder.prototype.undoVisit = function(node) {
    var self = this;

    var nodeName = node.data("node");
    self.addMarker(nodeName);
    self.nodes[nodeName].visited = false;

    var nextNode = self.nodes[nodeName];
    var startNode = self.nextUnvisitedNode(0);

    if(nextNode.index == 0) {
        self.visitIndex = nextNode.index;
        self.calculateAndDisplayRoute(nextNode, nextNode);
    } else if(nextNode.index == startNode.index) {
        self.visitIndex = nextNode.index;
        self.calculateAndDisplayRoute(startNode, nextNode);
    }
}


OptimalPathFinder.prototype.initMap = function() {

    var self = this;

    self.directionsService = new google.maps.DirectionsService;
    $("#map").height($("#map").parent().height());

    // Create a map and center it on UQ St Lucia.
    self.map = new google.maps.Map($('#map').get(0), {
      zoom: 18,
      center: {lat: -27.500272, lng: 153.013891}
    });
    // Create a renderer for directions and bind it to the map.
    self.directionsDisplay = new google.maps.DirectionsRenderer({map: self.map, suppressMarkers: true});
    
    self.personalMarker = new google.maps.Marker({
        position: self.indexToNode(self.visitIndex),
        map: self.map,
        icon: new google.maps.MarkerImage(
            'img/nodes/person.png',
            new google.maps.Size(48, 48),
            new google.maps.Point(0, 0),
            new google.maps.Point(16, 48)
        )
    });

    self.newSourceNode();
}

OptimalPathFinder.prototype.calculateAndDisplayRoute = function(start, end) {
    var self = this;

    // Retrieve the start and end locations and create a DirectionsRequest using WALKING directions.
    self.directionsService.route({
      origin: start,
      destination: end,
      travelMode: google.maps.TravelMode.WALKING
    }, function(response, status) {
      // Route the directions and pass the response to a function to create markers for each step.
        if (status === google.maps.DirectionsStatus.OK) {
            var leg = response.routes[0].legs[0];
            self.personalMarker.setPosition(leg.start_location);
            self.directionsDisplay.setDirections(response);

        }
    });
}

OptimalPathFinder.prototype.addMarker = function(location) {
    var self = this;

    var marker = new google.maps.Marker({
        position: self.nodes[location],
        map: self.map,
        icon: new google.maps.MarkerImage(
            'img/nodes/node_' + location + '.png',
            new google.maps.Size(48, 48),
            new google.maps.Point(0, 0),
            new google.maps.Point(24, 24),
            new google.maps.Size(40, 40)
        ),
        title: location
    });

    self.markerArray[location] = marker;
}

OptimalPathFinder.prototype.removeMarker = function(location) {
    var self = this;

    self.markerArray[location].setMap(null);
    delete self.markerArray[location];
}

OptimalPathFinder.prototype.nearestNeighbour = function(nodes, edges, sourceNode) {
    var resultPath = [];
	var resultEdges = [];
	var currentNode = sourceNode;

    edges = edges.slice();
	resultPath.push(currentNode); // push initial node
	nodes.splice(sourceNode.indexIn(nodes), 1);
    
	while(nodes.length > 0) {
		var currentMinimum = Number.MAX_VALUE;
		var nextNode;
		var currentEdge;

		// Find closest node to sourceNode using edges
		for(var i = 0; i < edges.length; i++) {
			// If currentNode == startNode of this edge and endNode hasn't been visited
			if(edges[i].source.equals(currentNode) 
                && !(edges[i].destination.inArray(resultPath))
				&& edges[i].destination.inArray(nodes)) {
                    
				// compare edge weight with the current minimum
				if(edges[i].distance < currentMinimum ) {
					currentMinimum = edges[i].distance;
					nextNode = edges[i].destination;
					currentEdge = edges[i];
				}
			}
		}

		if(currentNode.indexIn(nodes) != -1) {
			nodes.splice(currentNode.indexIn(nodes),1); // remove this now visited node
		}
        
		if(typeof currentEdge !== 'undefined' && currentEdge.indexIn(edges) != -1) {
			edges.splice(currentEdge.indexIn(edges),1); // remove used up edge, don't go back <- we eventually need to allow this for optimal cycles
		}

		currentNode = nextNode;

		resultPath.push(currentNode);
		resultEdges.push(currentEdge);
	}

	// Currently returns the edges representing the path
	return resultEdges;
}

OptimalPathFinder.prototype.startOptimalPath = function(sourceNode) {
    var self = this;
    var culledNodes = [];

	// Remove nodes that have been visited
	for(var i in self.nodes) {
        if(self.nodes[i].visited === false)
            culledNodes.push(self.nodes[i]);
    }
    
	// Create the graph using the global jsnx object

	//var newMSTEdges = kruskalMST(nodes, weightedEdges);
	var pathEdges = self.nearestNeighbour(culledNodes, self.weightedEdges, new Node(sourceNode));

    var nodesToVisit = [];
    var index = 0;

    for(var i = 0; i < pathEdges.length; i++) {
        //var e = graph.edges()[i];
		var e = pathEdges[i];
        // Only print another e[0] if distinct from previous e[1]
		if(nodesToVisit[e.source.id] === undefined) {
            self.nodes[e.source.id].index = index;
            nodesToVisit[e.source.id] = index++;
		}
		if(nodesToVisit[e.destination.id] === undefined) {
            self.nodes[e.destination.id].index = index;
            nodesToVisit[e.destination.id] = index++;
		}
    }


    $("#nodesToVisit .buttonWrapper").empty();
    var sorted = _.sortBy(self.nodes, 'index');
    self.visitIndex = -1;

    for(var i = 0; i < sorted.length; i++) {
        if(sorted[i].visited === false) {
            if(self.visitIndex == -1) {
                self.visitIndex = sorted[i].index;
            }
            $('#nodesToVisit .buttonWrapper').append("<li data-node=\"" + sorted[i].id + "\"><button>" + sorted[i].id + "</button></li>");
        }
    }
}

OptimalPathFinder.prototype.indexToNode = function(index) {
    var self = this;

    for(var i in self.nodes) {
        if(self.nodes[i].index == index && self.nodes[i].visited === false) {
            return self.nodes[i];
        }
    }
    return null;
}

OptimalPathFinder.prototype.nextUnvisitedNode = function(index) {
    var self = this;
    var sorted = _.sortBy(self.nodes, 'index');

    for(var i = index; i < sorted.length; i++) {
        var node = sorted[i];
        if(node.visited == false)
            return node;
    }

    return null;
}

/*
*   Export Required for QUnit
*/
if (typeof module != 'undefined' && module.exports) {
  module.exports = {
    OptimalPathFinder: OptimalPathFinder
  }
  var google = {
      maps: {
          Marker: function(a) { 
            var ret = {}; 
            if(typeof a.title === 'undefined') {
                ret = {setPosition: function() {}};
            } else {
                ret[a.title] = {
                    
                }; 
            }

            return ret 
          },
          Size: function() {},
          Map: function() { },
          Point: function() {},
          MarkerImage: function() {},
          DirectionsService: function() {
              return mockJQueryObject
          },
          DirectionsRenderer: function() {
              return mockJQueryObject
          },
          TravelMode: {
              WALKING: 1
          },
          DirectionsStatus: {
              OK: 1
          }
      }
  }
  var mockJQueryObject = {
      on: function(a,b,c) { 
        if(a === "click") {
            c();
        } else {
            b();
        }
            
        return mockJQueryObject; 
      },
      get: function() { return mockJQueryObject },
      empty: function() { return  mockJQueryObject},
      append: function() { return mockJQueryObject },
      height: function() { return mockJQueryObject },
      parent: function() { return mockJQueryObject },
      find: function() { return mockJQueryObject },
      hide: function() { return mockJQueryObject },
      slideDown: function() { return mockJQueryObject },
      prev: function() { return mockJQueryObject },
      after: function() { return mockJQueryObject },
      click: function(a) { a(); return mockJQueryObject },
      slideUp: function(a, b) { 
        if(typeof b === "function") b();
        return mockJQueryObject 
     },
      
      route: function(a, b) { b({routes: [{legs: [{start_location: 1}]}]}, 1);},
      setDirections: function() {},
      value: "43-E"
  };
  
  var $ = function() { 
    return mockJQueryObject;
  };
}