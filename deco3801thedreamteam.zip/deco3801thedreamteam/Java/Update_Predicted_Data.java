// Made for Java 8
// Requires mysql-connector-java-$version-bin.jar (tested with 5.1.39)
package PaperFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.Period;

import static PaperFactory.PaperFactory_Helper.*;

class Update_Predicted_Data
{
	static PreparedStatement insert_statement = null;
	static PreparedStatement select_recent_statement = null;
	static PreparedStatement select_past_statement = null;
	static PreparedStatement select_at_statement = null;
	static PreparedStatement current_date_statement = null;
	static PreparedStatement delete_statement = null;

	public static void main(String[] args) throws Exception
	{
		try
		{
			if (args.length != 0 && args.length != 2)
				throw new IllegalArgumentException("Incorrect number of arguments");
		}
		catch (Exception e)
		{
			log_exception(e);
			throw e;
		}

		PaperFactory_Helper.initilise(true);
		PaperFactory_Helper.connect();

		try
		{
			if (args.length == 0) predict_all();
			else predict(args[0], Integer.parseInt(args[1]));
		}
		catch (SQLException e) { log_exception(e); }
		catch (Exception e) { log_exception(e); }
		finally
		{
			close(insert_statement);
			close(select_recent_statement);
			close(select_past_statement);
			close(select_at_statement);
			close(current_date_statement);
			close(delete_statement);
			close();
		}
	}

	// String, tinyInt, DateTime, int,
	static int insert_row(String media, int printer, LocalDateTime time, LocalDateTime created, int consumption) throws SQLException
	{
		if (insert_statement == null)
			insert_statement = connection.prepareStatement("INSERT INTO predicted_data VALUES (?, ?, ?, ?, ?)");
		insert_statement.setString(1, media);
		insert_statement.setInt(2, printer);
		insert_statement.setTimestamp(3, Timestamp.valueOf(time), UTC);
		insert_statement.setTimestamp(4, Timestamp.valueOf(created), UTC);
		insert_statement.setInt(5, consumption);
		return insert_statement.executeUpdate();
	}

	static LocalDateTime current_date() throws SQLException
	{
		ResultSet r = null;
		try
		{
			if (current_date_statement == null)
				current_date_statement = connection.prepareStatement("SELECT * FROM `current_date`");
			r = current_date_statement.executeQuery();
			r.next();
			return r.getTimestamp(1, UTC).toLocalDateTime();
		}
		finally { close(r); }
	}


	// Get the most recent (filtered) Level and Consumption for the given printer and media.
	static ResultSet select_recent(String media, int printer) throws SQLException
	{
		if (select_recent_statement == null)
			select_recent_statement = connection.prepareStatement(
				"SELECT Level, Consumption FROM filtered_data " +
				"WHERE Media = ? AND Printer = ? " +
				"ORDER BY Time DESC LIMIT 1");
		select_recent_statement.setString(1, media);
		select_recent_statement.setInt(2, printer);
		return select_recent_statement.executeQuery();
	}

	// Gets the 'Consumption' at the given time for the given media and printer
	static int select_consumption_at(LocalDateTime start, String media, int printer) throws SQLException
	{
		ResultSet r = null;
		try
		{
			if (select_at_statement == null)
				select_at_statement = connection.prepareStatement(
					"SELECT Consumption FROM filtered_data " +
					"WHERE Media = ? AND Printer = ? AND Time <= ?" +
					"ORDER BY Time DESC LIMIT 1");
			select_at_statement.setString(1, media);
			select_at_statement.setInt(2, printer);
			select_at_statement.setTimestamp(3, Timestamp.valueOf(start), UTC);
			r = select_at_statement.executeQuery();
			if (r.next()) return r.getInt("Consumption");
			else return -1;
		}
		finally { close(r); }
	}
	// Get the 'Time' and 'Consumption' from 'filtered_data' corresponding to the given media and printer
	// that occur after the given date.
	static ResultSet select_past_consumption(String media, int printer, LocalDateTime start) throws SQLException
	{
		if (select_past_statement == null)
			select_past_statement = connection.prepareStatement(
					"SELECT `Time`, Consumption FROM filtered_data " +
					"WHERE Media = ? AND Printer = ? AND `Time` > ?" +
					"ORDER BY `Time` ASC");
		select_past_statement.setString(1, media);
		select_past_statement.setInt(2, printer);
		select_past_statement.setTimestamp(3, Timestamp.valueOf(start), UTC);
		return select_past_statement.executeQuery();
	}

	static int delete(String media, int printer) throws SQLException
	{
		if (delete_statement == null)
			delete_statement = connection.prepareStatement("DELETE FROM predicted_data WHERE Media = ? AND Printer = ?");
		delete_statement.setString(1, media);
		delete_statement.setInt(2, printer);
		return delete_statement.executeUpdate();
	}

	// Update the prediction for all data
	static void predict_all() throws SQLException
	{
		Statement select_statetment = null;
		ResultSet media_printer = null;
		try
		{
			select_statetment = connection.createStatement();
			media_printer = select_statetment.executeQuery("SELECT DISTINCT Media, Printer FROM filtered_data");

			while (media_printer.next())
				predict(media_printer.getString("Media"), media_printer.getInt("Printer"));
		}
		finally
		{
			close(media_printer);
			close(select_statetment);
		}
	}

	// (one printer 'p' and one media level 'm')
	static void predict(String media, int printer) throws SQLException
	{
		delete(media, printer); // Delete any outdated predictions
		LocalDateTime now = current_date();
		ResultSet recent_result = null;
		ResultSet past_result = null;
		try
		{
			recent_result = select_recent(media, printer);
			if (!recent_result.next()) return; // This shouldn't happen
			int current_level = recent_result.getInt("Level");
			int current_consumption = recent_result.getInt("Consumption");
			close(recent_result);
			recent_result = null;


			LocalDateTime start_time = now.minus(Period.ofYears(1));

			int start_consumption = select_consumption_at(start_time, media, printer);
			int predicted_level = current_level;

			past_result = select_past_consumption(media, printer, start_time);
			while (predicted_level > 0 && past_result.next())
			{
				int past_consumption = past_result.getInt("Consumption");
				LocalDateTime past_time = past_result.getTimestamp("Time", UTC).toLocalDateTime();

				int predicted_consumption = (past_consumption - start_consumption) + current_consumption;
				predicted_level = (int)(current_level - (predicted_consumption - current_consumption));
				if (predicted_level < 0) predicted_level = 0;

				LocalDateTime predicted_time = past_time.plus(Period.ofYears(1));
				insert_row(media, printer, predicted_time, now, predicted_consumption);
			}
		}
		finally
		{
			close(recent_result);
			close(past_result);
		}
	}
}