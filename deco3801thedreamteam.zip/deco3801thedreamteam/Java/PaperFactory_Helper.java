package PaperFactory;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

// A class of usefull functions and things to be used by PaperFactory programs (e.g. Update_Predicted_Data)
class PaperFactory_Helper
{
	static final Calendar UTC = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
	static boolean auto_log = false; // Automatically log exceptions to stdout
	static Connection connection = null;

	static void initilise() throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		initilise(false);
	}
	static void initilise(boolean auto_log) throws ClassNotFoundException, IllegalAccessException,
			InstantiationException
	{
		PaperFactory_Helper.auto_log = auto_log;

		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		}
		catch (ReflectiveOperationException e)
		{
			if (auto_log) log_exception(e);
			throw e;
		}
	}

	static void connect() throws SQLException
	{
		try
		{
			connection = DriverManager.getConnection("jdbc:mysql://localhost/printer?user=root&password=dReam&useSSL=false");
		}
		catch (SQLException e)
		{
			if (auto_log) log_exception(e);
			throw e;
		}
	}

	static void log_exception(Exception ex)
	{
		try
		{
			String time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

			System.out.print("[" + time + "] ");
			ex.printStackTrace(System.out);
			System.out.println();
			System.out.println();
			System.out.flush();
		}
		catch (Exception e) { }
		finally
		{
			try { System.out.flush(); }
			catch (Exception e) { }
		}
	}
	static void log_exception(SQLException ex)
	{
		try
		{
			String time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

			while (ex != null)
			{
				System.out.print("[" + time
						+ " code: " + Integer.toString(ex.getErrorCode()) + ","
						+ " state: " + ex.getSQLState() + "] ");
				ex.printStackTrace(System.out);
				System.out.println();
				ex = ex.getNextException();
			}
			System.out.println();
			System.out.flush();
		}
		catch (Exception e) { }
		finally
		{
			try { System.out.flush(); }
			catch (Exception e) { }
		}
	}

	static void close(ResultSet s)
	{
		if (s != null)
		{
			try { s.close(); }
			catch (SQLException e) { if (auto_log) log_exception(e); }
		}
	}

	static void close(Statement s)
	{
		if (s != null)
		{
			try { s.close(); }
			catch (SQLException e) { if (auto_log) log_exception(e); }
		}
	}

	static void close()
	{
		if (connection != null)
		{
			try { connection.close(); }
			catch (SQLException e) { if (auto_log) log_exception(e); }
		}
	}
}