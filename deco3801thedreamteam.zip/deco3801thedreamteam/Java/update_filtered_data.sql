USE printer;
DROP TRIGGER IF EXISTS update_filtered_data;
DELIMITER $$
CREATE TRIGGER update_filtered_data
BEFORE INSERT ON snmphistory FOR EACH ROW 
BEGIN
SET @cmd = sys_exec('/opt/local/bin/java -jar /var/PaperFactory/Java/Update_Filtered_Data.jar');
END;
$$
