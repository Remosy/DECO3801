// Made for Java 8
// Requires mysql-connector-java-$version-bin.jar (tested with 5.1.39)
package PaperFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.Period;

import static PaperFactory.PaperFactory_Helper.*;

class Update_Filtered_Data
{
	static int filtered_data_length = -1;
	static PreparedStatement select_statement = null;
	static PreparedStatement delete_statement = null;
	static PreparedStatement insert_statement = null;
	static ResultSet filtered_data = null;

	public static void main(String[] args) throws Exception
	{
		try
		{
			if (args.length != 0 && args.length != 5)
				throw new IllegalArgumentException("Incorrect number of arguments");
		}
		catch (Exception e)
		{
			log_exception(e);
			throw e;
		}

		PaperFactory_Helper.initilise(true);
		PaperFactory_Helper.connect();

		try
		{

			if (args.length == 0) update_all();
			else update(args[0], Integer.parseInt(args[1]), args[2], Integer.parseInt(args[4]));
		}
		catch (SQLException e) { log_exception(e); }
		catch (Exception e) { log_exception(e); }
		finally
		{
			close(insert_statement);
			close(delete_statement);
			close(select_statement);
			close();
		}
	}


	static ResultSet select_rows(String media, int printer) throws SQLException
	{
		if (select_statement == null)
			select_statement = connection.prepareStatement(
				"SELECT * FROM filtered_data WHERE Media = ? AND Printer = ? ORDER BY Time DESC ",
				ResultSet.TYPE_SCROLL_INSENSITIVE);
		select_statement.setString(1, media);
		select_statement.setInt(2, printer);
		return select_statement.executeQuery();
	}

	static int delete_row(int i) throws SQLException
	{
		if (delete_statement == null)
			delete_statement = connection.prepareStatement("DELETE FROM filtered_data WHERE Media = ? AND Printer = ? AND Time = ?");

		filtered_data.absolute(i + 1);
		delete_statement.setString(1, filtered_data.getString("Media"));
		delete_statement.setString(2, filtered_data.getString("Printer"));
		delete_statement.setTimestamp(3, filtered_data.getTimestamp("Time", UTC), UTC);
		return delete_statement.executeUpdate();
	}

	static int insert_row(String media, int printer, String time, int level, int consumption) throws SQLException
	{
		if (insert_statement == null)
			insert_statement = connection.prepareStatement("INSERT INTO filtered_data VALUES (?, ?, ?, ?, ?)");
		insert_statement.setString(1, media);
		insert_statement.setInt(2, printer);
		insert_statement.setString(3, time);
		insert_statement.setInt(4, level);
		insert_statement.setInt(5, consumption);
		return insert_statement.executeUpdate();
	}

	static int get_consumption(int i) throws SQLException
	{
		filtered_data.absolute(i + 1);
		return filtered_data.getInt("Consumption");
	}
	static int get_level(int i) throws SQLException
	{
		filtered_data.absolute(i + 1);
		return filtered_data.getInt("Level");
	}

	static void update_all() throws SQLException
	{
		Statement select_all = null;
		Statement select_recent = null;
		PreparedStatement select_after = null;
		ResultSet recent_time = null;
		ResultSet snmp_data = null;
		try
		{
			select_recent = connection.createStatement();
			recent_time = select_recent.executeQuery("SELECT `Time` FROM filtered_data ORDER BY `Time` DESC LIMIT 1");

			if (recent_time.next())
			{
				select_after = connection.prepareStatement("SELECT * FROM snmp_data WHERE Stamp > ?");
				select_after.setTimestamp(1, recent_time.getTimestamp("Time", UTC), UTC);
				snmp_data = select_after.executeQuery();
			}
			else
			{
				select_all = connection.createStatement();
				snmp_data = select_all.executeQuery("SELECT * FROM snmp_data");
			}

			while (snmp_data.next())
			{
				int printer = snmp_data.getInt("Printer");
				String time = snmp_data.getString("Stamp");

				update("Tray1", printer, time, snmp_data.getInt("Tray1"));
				update("Tray2", printer, time, snmp_data.getInt("Tray2"));
				update("Tray3", printer, time, snmp_data.getInt("Tray3"));
				update("Tray4", printer, time, snmp_data.getInt("Tray4"));
				update("TonerCyan", printer, time, snmp_data.getInt("TonerCyan"));
				update("TonerMagenta", printer, time, snmp_data.getInt("TonerMagenta"));
				update("TonerYellow", printer, time, snmp_data.getInt("TonerYellow"));
				update("TonerBlack", printer, time, snmp_data.getInt("TonerBlack"));
			}
		}
		finally
		{
			close(snmp_data);
			close(select_all);
			close(select_after);
			close(recent_time);
			close(select_recent);
		}

	}
	static void update(String media, int printer, String time, int level) throws SQLException
	{
		try
		{
			filtered_data = select_rows(media, printer);
			filtered_data.last();
			filtered_data_length = filtered_data.getRow();

			int i = 0;

			if (filtered_data_length > 1 && media.startsWith("Toner")) i = ink_filter(level);

			int consumption = 0;
			if (i < filtered_data_length)
			{
				consumption = get_consumption(i);

				if (level < get_level(i)) // Level went down
					consumption += get_level(i) - level;

				// Check for duplicates
				if (i + 1 < filtered_data_length)
				{
					if (get_level(i) == get_level(i + 1)) // Remove duplicate
						delete_row(i);
				}
			}

			insert_row(media, printer, time, level, consumption);
		}
		finally
		{
			close(filtered_data);
		}
	}

	static int ink_filter(int level) throws SQLException
	{
		if (level != 0 && level != 100)
		{
			for (int k : new    int[]{0, 100})
			{
				if (get_level(0) != k)
					continue;

				for (int i = 1; i < filtered_data_length; i++)
				{
					int other_level = get_level(i);
					if (other_level == k)
						continue;

					if (other_level >= level - 2 & other_level <= level + 2)
					{
						for (int j = 0; j < i; j++)
							delete_row(j);
						return i;
					}
					return 0;
				}
			}
		}
		return 0;
	}


}