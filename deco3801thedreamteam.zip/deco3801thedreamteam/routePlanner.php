<section id="contentPanelWrapper">
	<div id="pageContentPanel">
		<div id="routeSetting">
			<div class="input-group">
			  <label for="timelimit">Time Limit (Minutes):</label>
			  <input id="timeLimit" type="number" class="form-control" aria-describedby="basic-addon1">
			</div>
			<div class="input-group">
			  <label for="startPoint">Start Point:</label>
			  <input class="form-control" rows="5" id="startPoint"/>
			  <p style="text-align:center;">
			    <button type="button" class="btn btn-default btn-lg" id="currentLocationButton" style="margin-top: 20px" onClick="setCurrentLocation()">Use Current Location</button>
			  </p>
			</div>
			<div class="input-group">
			  <label for="plannerSelect">Planner:</label>
			  <select name="planner" class="form-control">
			    <option value="mcts">MCTS</option>
			    <option value="naive_top_n">Naive Top N</option>
			    <option value="dp">DP</option>
			  </select>
			</div>
			</br>
			<p style="text-align:center;">
			<button id="routePlanner_calculate" type="button" class="btn btn-default btn-lg" onclick="getCaculateResult()">Calculate
			<img id="routeLoader" src="img/loader.gif" width="30" height="30" alt="loader" style="display: none;"/>
			</button>
			</p>
			<p style="text-align:center;">
			<a id="downloadButtonA">
			<button type="button" class="btn btn-default btn-lg" id="downloadButton">Download</button>
			</a>
			</p>
			<div id="routeListPanel"></div>
			
		</div>
		<div id="routeMap"></div>
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIhXGVQ9UIXHBW2bwJL8oJkEuwRWQUZGU&callback=initMap"></script>
	<p/>
	</div>
</section>
