<section id="contentPanelWrapper">
    <div id="pageContentPanel">
        <div style="display: none" class="loader" ><span><h2>Loading</h2><img src="img/loader.gif" /></span></div>
        <nav>
	        <div id="timeButtonsContainer">
	           <a id="selectPreviousLevels">Previous Levels</a><a id="selectCurrentLevels">Current Levels</a><a id="selectUpcomingLevels">Upcoming Levels</a>
	        </div>
        </nav>
        <div id="pagePurposeWrapper">
            <div id="timebarContainer">
                <h3>Results for:
	                 <span id="datesPicker"></span>
                </h3>
            </div>
            <div class="rightContentPanel <?= ($action != "") ? 'style="border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;"' : ''; ?>" id="printerInfoTableContainer">
             <table class="display" cellspacing="0" id="allPrinterList">
	                <thead>
			            <tr>
			                <th>ID</th>
			                <th>Building Name</th>
			                <th>Printer Name</th>
			                <th>Location</th>
			                <th>Trend</th>    
			            </tr>
        			</thead>
              </table> 
                
              
        </div>
		
        </div>
    </div>
    <div class="modal fade" id="printerOverviewOverlay" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
			<div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			        <h1 class="modal-title">Printer ID:</h1>
			      </div>
			      <div class="modal-body">
			        <div id="printerMapContainer"></div>
			        <div id="printerOverview">
		                <h2 class="PrinterBuilding"></h2>
		                <a style="text-align: center;" href="/?action=ViewPath">View in Route Planner</a>
		            </div>
		           
			&nbsp;
		            <div style="width: 100%;height: 300px;" id="lineChartContainer"></div>
			      </div>
			      
			</div>
	    </div>
	    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIhXGVQ9UIXHBW2bwJL8oJkEuwRWQUZGU&callback=initMap"></script>
    </div>
    
</section>
