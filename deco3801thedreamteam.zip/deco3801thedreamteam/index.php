<?php
require_once("api/authCheck.php");
require_once("includes.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<link href='https://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/reset.css" />
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/nouislider.css" />
<link rel="stylesheet" type="text/css" href="css/DateTimePicker.css" />

<script type="text/Javascript" src="js/ThirdParty/jquery.js"></script>
<!--<script type="text/javascript" src="js/ThirdParty/DateTimePicker.js"></script>-->
<!--<script type="text/Javascript" src="js/ThirdParty/chart.js"></script>-->
<script src="https://code.highcharts.com/highcharts.js"></script>
<!--<script type="text/Javascript" src="js/ThirdParty/underscore-min.js"></script>-->

<script type="text/JavaScript" src="js/Pathfinding/Node.js"></script>
<script type="text/JavaScript" src="js/Pathfinding/Edge.js"></script>
<!--<script type="text/Javascript" src="js/Visualisation/PaperVisualisation.js"></script>-->
<script type="text/JavaScript" src="js/Pathfinding/OptimalPathFinder.js"></script>

<!-- Route Planner -->
	<!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Route Planner -->
	<link href="css/routePlanner.css" rel="stylesheet">
	<script src="js/Pathfinding/routeMap.js"></script>
<!-- Printer List -->
	<!-- DatePicker -->
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<!-- DataTable -->
	<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<link rel="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
	<link rel="https://cdn.datatables.net/fixedheader/3.1.2/css/fixedHeader.dataTables.min.css"/>
	<script src="https://cdn.datatables.net/fixedheader/3.1.2/js/dataTables.fixedHeader.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
	<!-- Sparkline -->
    <script src="js/ThirdParty/jquery.sparkline.min.js"></script>
    <!-- AmChart -->
	<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
	<script src="https://www.amcharts.com/lib/3/serial.js"></script>
	<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
	<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
	<!-- Printer List -->
	<script type="text/Javascript" src="js/Visualisation/printerList.js"></script>

</head>
<body>

	<?php include_once("Header.php");?>
	<?php
	 
	$action = isset($_GET["action"]) ? $_GET["action"] : "";
	$action = $action == "index" ? "" : $action;
	
	$selectedTab = "class=\"selectedTab\" ";
	switch($action) {
	
	    case "ViewPath":
	    case "ViewPreviousPaths":
	        //include_once("OptimalPathView.php");
	        include_once("routePlanner.php");
	        break;
	
	
	    default:
	    case "":
	    case "PreviousLevels":
	    case "ForwardPrediction":
	        include_once("PaperVisualiserView2.php");
	        break;
	}
	?>
</body>
</html>
