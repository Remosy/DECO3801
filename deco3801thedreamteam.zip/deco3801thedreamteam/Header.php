
<aside id="backgroundOverlay">
    <form style="display: none" id="dateChangerForm" class="overlayForm" action="api/updateDate.php" method="POST">
        <div class="formItems">
            <img src="img/Logo_new.png" class="formHeader" />
            <h3>Date Changer</h3>
            <?php
                $timeParts = explode(" ", $_SESSION["currentDate"]);
            ?>
            <div class="formPair">
                <label for="formDate">Date: </label><input id="formDate" type="date" value="<?php echo $timeParts[0]; ?>" name="newDate"/>
            </div>
            <div class="formPair">
                <label for="formTime">Time: </label><input id="formTime" type="time" value="<?php echo $timeParts[1]; ?>" name="newTime" />
            </div>
            <div class="formFooter">
                <input type="submit" value="Update Settings" />
            </div>
        </div>
    </form>
</aside>
<aside id="sidebar">
    <ul>
      <li><img src="img/Logo_new.png" /></li>
      <li><h1>Paper Factory</h1></li>
      <nav id="mainNav">
          <li><a href="?action=">Printer List</a></li>
          <li><a href="?action=ViewPath">Route Planner</a></li>
	  <li><a href="/paperfactoryapi">API</a></li>
          <li><a>Code</a></li> 
          <li><a>Database</a></li>
          <!--<li><a disabled=disabled href="#">Nearest Printer</a></li>
          <li class="navBottom"><a href="#" id="changeDateButton">Emulate Date/Time</a></li>-->
      </nav>
      <!--
      <li id="navName"><h5>Effective as of <?= date("jS F, Y", strtotime($_SESSION["currentDate"])); ?></h5>
        <input type="text" id="dateEmulationPicker" data-field="datetime" data-format="yyyy-MM-dd hh:mm:ss" value="<?= date("Y-m-d H:i:s", strtotime($_SESSION["currentDate"])); ?>" readonly />
      </li>
      <li><h6><a href="latest-build.zip">Download Source Code</a></h6></li>-->
    </ul>
</aside>
<div id="dtBox"></div>
