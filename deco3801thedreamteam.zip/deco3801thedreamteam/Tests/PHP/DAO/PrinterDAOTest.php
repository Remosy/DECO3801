<?php
class PrinterDAOTest extends PHPUnit_Framework_TestCase {
        
    /**
    *   Tests cases that Printers can be inserted into the DB
    *   
    *   @test
    */
    public function insertPrinter() {
        $printerDAO = new PrinterDAO(true);
        $printer = new Printer();
        
        $printer->Printer = 605;
        $printer->Stamp = "2013-01-01 00:00:00";
        $printer->Location = "49-400";
        
        $this->assertTrue($printerDAO->create($printer));
        
        $retrievedPrinter = $printerDAO->getPrinterByStamp($printer);
        $this->assertEquals($printer, $retrievedPrinter);
        
        
        return $printer;
    }
    
    
    /**
    *   Tests that the Printers with invalid internal states cannot be inserted into the DB
    *
    *   @test
    *   @expectedException PDOException
    */
    public function insertBadPrinter() {
        $printerDAO = new PrinterDAO(true);
        $printer = new Printer();
        $printer->Printer = -500;
        $printer->Stamp = null;
        
        $printerDAO->create($printer);
    }
    
    /**
    *   Tests that Printers can be updated in the DB
    *
    *   @test
    *   @depends insertPrinter
    */
    public function updatePrinter(Printer $printer) {
        $printerDAO = new PrinterDAO(true);
        $printer->Location = "60-333";
        $this->assertTrue($printerDAO->update($printer));
        
        $retrievedPrinter = $printerDAO->getPrinterByStamp($printer);
        $this->assertEquals($printer->Location, $retrievedPrinter->Location);
        
        return $printer;
    }
    
    /**
    *   Tests that Printers can be deleted from DB
    *
    *   @test
    *   @depends updatePrinter
    */
    public function deletePrinter(Printer $printer) {
        $printerDAO = new PrinterDAO(true);
        
        $this->assertTrue($printerDAO->delete($printer));
        
        $retrievedPrinter = $printerDAO->getPrinterByStamp($printer);
        $this->assertNull($retrievedPrinter);
    }
    
    /**
    *   Tests that the correct result is returned when many printers exist in the DB
    *
    *   @test
    */
    public function getMultiplePrinterIDs() {
        $printerDAO = new PrinterDAO(true);
        
        $this->assertEquals(array(), $printerDAO->getAllPrinterIDs());
        
        $printer1 = new Printer();
        $printer2 = new Printer();
        $printer3 = new Printer();
        
        $printer1->Printer = 605;
        $printer1->Stamp = "2013-01-01 00:00:00";
        $printer1->Location = "49-400";
        
        $this->assertTrue($printerDAO->create($printer1));
        $this->assertEquals(array(0 => 605), $printerDAO->getAllPrinterIDs());
        
        $printer2->Printer = 80;
        $printer2->Stamp = "2014-01-01 00:00:00";
        $printer2->Location = "60-400";
        $this->assertTrue($printerDAO->create($printer2));
        
        $printer3->Printer = 20;
        $printer3->Stamp = "2016-01-01 00:00:00";
        $printer3->Location = "19-12";
        $this->assertTrue($printerDAO->create($printer3));
        
        $this->assertEquals(array(0 => 20, 1 => 80, 2 => 605), $printerDAO->getAllPrinterIDs());
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
        $this->assertTrue($printerDAO->delete($printer3));
        $this->assertEquals(array(), $printerDAO->getAllPrinterIDs());
    }
    
    /**
    *   Ensures the correct value is returned when no printers exist
    *
    *   @test
    */
    public function getNoPrintersBetweenDates() {
        $printerDAO = new PrinterDAO(true);
        $retrievedPrinter = $printerDAO->fetchPrinterBetweenDates('2014-01-01', '2014-03-01', 605);
        $this->assertEquals(array(), $retrievedPrinter);
    }
    /**
    *   Tests the the correct Printer is returned when there is only one Printer that exists between two dates
    *
    *   @test
    */
    public function getSinglePrinterBetweenDates() {
        $printerDAO = new PrinterDAO(true);
        
        $printer1 = new Printer();
        $printer1->Printer = 605;
        $printer1->Stamp = "2014-01-02 00:00:00";
        $printer1->Location = "49-400";
        $printer1->Status = "idle";
        
        $this->assertTrue($printerDAO->create($printer1));
        
        $printer2 = new Printer();
        $printer2->Printer = 107;
        $printer2->Stamp = "2013-01-02 00:00:00";
        $printer2->Location = "49-400";
        $printer2->Status = "idle";
        $this->assertTrue($printerDAO->create($printer2));
        
        $retrievedPrinter = $printerDAO->fetchPrinterBetweenDates('2014-01-01', '2014-03-01', 605);
        
        $this->assertEquals(1, count($retrievedPrinter));
        $this->assertEquals($printer1, $retrievedPrinter[0]);
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
    }
    
    
    /**
    *   Tests the the correct Printers are returned when there are multiple Printers that exists between two dates
    *
    *   @test
    */
    public function getMultiplePrintersBetweenDates() {
        $printerDAO = new PrinterDAO(true);
        
        $printer1 = new Printer();
        $printer1->Printer = 605;
        $printer1->Stamp = "2014-01-03 00:00:00";
        $printer1->Location = "49-400";
        $printer1->Status = "idle";
        $this->assertTrue($printerDAO->create($printer1));
        
        $printer2 = new Printer();
        $printer2->Printer = 605;
        $printer2->Stamp = "2014-02-01 00:00:00";
        $printer2->Location = "49-400";
        $printer2->Status = "idle";
        $this->assertTrue($printerDAO->create($printer2));
        
        $retrievedPrinter = $printerDAO->fetchPrinterBetweenDates('2014-01-01', '2014-03-01', 605);
        
        $this->assertEquals(2, count($retrievedPrinter));
        $this->assertEquals($printer1, $retrievedPrinter[0]);
        $this->assertEquals($printer2, $retrievedPrinter[1]);
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
    }
    
    /**
    *   Tests the the correct result is returned when there are no Printers that exists between two dates
    *
    *   @test
    */
    public function getNoPrintersLastKnownGoodState() {
        $printerDAO = new PrinterDAO(true);
        $this->assertEquals(array(), $printerDAO->fetchLastKnownGoodPrinterState('2011-01-01'));
    }
    
    /**
    *   Tests the the correct Printers are returned when there are many Printers that have a last known good state
    *
    *   @test
    */
    public function getMultiplePrintersLastKnownGoodState() {
        $printerDAO = new PrinterDAO(true);
        
        $printer1 = new Printer();
        $printer1->Printer = 605;
        $printer1->Stamp = "2014-01-20 00:00:00";
        $printer1->Location = "49-400";

        $this->assertTrue($printerDAO->create($printer1));
        
        $printer2 = new Printer();
        $printer2->Printer = 22;
        $printer2->Stamp = "2014-02-01 00:00:00";
        $printer2->Location = "49-400";
        $this->assertTrue($printerDAO->create($printer2));
        
        $retrievedPrinter = $printerDAO->fetchLastKnownGoodPrinterState('2017-01-01');

        $this->assertEquals(2, count($retrievedPrinter));
        
        $this->assertEquals($printer1, $retrievedPrinter[0]);
        $this->assertEquals($printer2, $retrievedPrinter[1]);
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
    }
}
?>