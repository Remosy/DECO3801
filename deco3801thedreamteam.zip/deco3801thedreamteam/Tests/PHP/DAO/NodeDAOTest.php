<?php
class NodeDAOTest extends PHPUnit_Framework_TestCase {
    
    /**
    *   Tests cases that a bad Node can't be inserted into the DB
    *   
    *   @test
    *   @expectedException PDOException
    */
    public function badInsert() {
        $nodeDAO = new NodeDAO(true);
        $node1 = new Node();
        $nodeDAO->create($node1);
    }
   
    /**
    *   Tests cases that all nodes are returned when there are none
    *   
    *   @test
    */
    public function getAllNodesWhenNone() {
        $nodeDAO = new NodeDAO(true);
        $this->assertEquals(array(), $nodeDAO->getAllNodes());
    }
    
    /**
    *   Test case to link non-existent nodes
    *   
    *   @test
    */
    public function badUpdateLinkNodes() {
        $nodeDAO = new NodeDAO(true);
        $node1 = new Node();
        $node1->id = 25;
        $nodes = array($node1);
        $nodeDAO->linkNodes($nodes);
        $this->assertEquals(count($node1->linkedTo), 0);
    }
    
    
    /**
    *   Test case to update a non-existent node
    *   
    *   @test
    */
    public function badUpdateNode() {
        $nodeDAO = new NodeDAO(true);
        $node1 = new Node();
        $this->assertTrue($nodeDAO->updateNode($node1));
    }
    
    /**
    *   Test case to update a non-existent NodeDistance
    *   
    *   @test
    */
    public function badUpdateNodeDistance() {
        $nodeDAO = new NodeDAO(true);
        $nodeDistance = new NodeDistance();

        $nodeDistance->startNode = 1;
        $nodeDistance->endNode = 2;
        
        $this->assertTrue($nodeDAO->updateNodeDistance($nodeDistance));
    }
    

    
    /**
    *   Tests cases that a Node can be inserted into the DB
    *   
    *   @test
    */
    public function insertNode() {
        $nodeDAO = new NodeDAO(true);
        
        $node1 = new Node();
        $node1->id = 1;
        $node1->buildingName = "48";
        $node1->printerName = "E";
        $node1->latitude = -20;
        $node1->longitude = 50;
        
        
        $node2 = new Node();
        $node2->id = 2;
        $node2->buildingName = "48";
        $node2->printerName = "336";
        $node2->latitude = -20;
        $node2->longitude = 50;

        
        $node3 = new Node();
        $node3->id = 3;
        $node3->buildingName = "50";
        $node3->printerName = "E";
        $node3->latitude = -20;
        $node3->longitude = 50;

        $node4 = new Node();
        $node4->id = 4;
        $node4->buildingName = "48";
        $node4->printerName = "123";
        $node4->latitude = -20;
        $node4->longitude = 50;
        
        $nodeDistance = new NodeDistance();
        $nodeDistance->startNode = $node1->id;
        $nodeDistance->endNode = $node3->id;
        $nodeDistance->distanceTime = 1;
        $nodeDistance->distanceMeters = 55;
        
        $nodeDistance2 = new NodeDistance();
        $nodeDistance2->startNode = $node1->id;
        $nodeDistance2->endNode = $node4->id;
        $nodeDistance2->distanceTime = 1;
        $nodeDistance2->distanceMeters = 55;
        


        $node1->linkedTo[] = $nodeDistance;
        $node3->linkedTo[] = $nodeDistance;
        
        $node4->linkedTo[] = $nodeDistance2;
        $node1->linkedTo[] = $nodeDistance2;
        
        $this->assertTrue($nodeDAO->create($node1));
        $this->assertTrue($nodeDAO->create($node2));
        $this->assertTrue($nodeDAO->create($node3));
        $this->assertTrue($nodeDAO->create($node4));
        
        $node1->linkedTo[0]->distanceTime = 2;
        $nodeDAO->updateNodeDistance($node1->linkedTo[0]);
    }
    
    /**
    *   Tests cases nodes can be deleted
    *   
    *   @test
    */
    public function deleteNodes() {
        $nodeDAO = new NodeDAO(true);
        
        $node1 = new Node();
        $node1->id = 1;
        $node1->buildingName = "48";
        $node1->printerName = "E";
        $node1->latitude = -20;
        $node1->longitude = 50;

        
        $node2 = new Node();
        $node2->id = 2;
        $node2->buildingName = "48";
        $node2->printerName = "336";
        $node2->latitude = -20;
        $node2->longitude = 50;

        
        $node3 = new Node();
        $node3->id = 3;
        $node3->buildingName = "50";
        $node3->printerName = "E";
        $node3->latitude = -20;
        $node3->longitude = 50;

        $node4 = new Node();
        $node4->id = 4;
        $node4->buildingName = "48";
        $node4->printerName = "123";
        $node4->latitude = -20;
        $node4->longitude = 50;
        
        $nodeDistance = new NodeDistance();
        $nodeDistance->startNode = $node1->id;
        $nodeDistance->endNode = $node3->id;
        $nodeDistance->distanceTime = 1;
        $nodeDistance->distanceMeters = 55;
        
        $nodeDistance2 = new NodeDistance();
        $nodeDistance2->startNode = $node1->id;
        $nodeDistance2->endNode = $node4->id;
        $nodeDistance2->distanceTime = 1;
        $nodeDistance2->distanceMeters = 55;
        
        $node1->linkedTo[] = $nodeDistance;
        $node3->linkedTo[] = $nodeDistance;
                $this->assertTrue($nodeDAO->deleteNodeDistance($nodeDistance2));
        $this->assertTrue($nodeDAO->deleteNodeDistance($nodeDistance));
        $this->assertTrue($nodeDAO->delete($node1));
        $this->assertTrue($nodeDAO->delete($node2));
        $this->assertTrue($nodeDAO->delete($node3));
        $this->assertTrue($nodeDAO->delete($node4));
    }
}
?>