<?php
class DAOTest extends PHPUnit_Framework_TestCase {
        
    /**
    *   Tests that the DAO can connect to the database
    *   
    *   @test
    */
    public function DAOConnectsToProduction() {
        $dao = new DAO();
        $this->assertTrue($dao !== null);
    }
    
    /**
    *   Tests that the DAO can connect to the test database
    *   
    *   @test
    */
    public function DAOConnectsToTest() {
        $dao = new DAO(true);
        $this->assertTrue($dao !== null);
    }
}
?>