<?php
class OptimalPathModelTest extends PHPUnit_Framework_TestCase {
    
    /**
    *   Tests that the date is set correctly when instantiating the class
    *   
    *   @test
    */
    public function setsDateCorrectly() {
        $_SESSION["currentDate"] = "2013-04-04 23:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        
        $this->assertEquals("2013-04-04 23:00:00", $optimalPathModel->getDate());
        
    }
    
    /**
    *   Tests that the date is set correctly when instantiating the class
    *   
    *   @test
    */
    public function setsDateCorrectlyForMethod() {
        $optimalPathModel = new OptimalPathModel(true);
        $optimalPathModel->setDate("2013-04-04 23:00:00");
        $this->assertEquals("2013-04-04 23:00:00", $optimalPathModel->getDate());
    }
    
    /**
    *   Tests that the correct date is returned
    *   
    *   @test
    */
    public function returnsCorrectDate() {
        $_SESSION["currentDate"] = "2013-09-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $this->assertEquals("2013-09-04 12:00:00", $optimalPathModel->getDate());
    }
    
    /**
    *   Tests that the correct array of Nodes are returned
    *   
    *   @test
    */
    public function getsCorrectNodes() {
        $_SESSION["currentDate"] = "2013-20-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $nodeDAO = new NodeDAO(true);
        $node1 = new Node();
        $node1->id = 1;
        $node1->buildingName = "48";
        $node1->printerName = "E";
        $node1->latitude = -20;
        $node1->longitude = 70;
        $nodeDAO->create($node1);
        
        $node2 = new Node();
        $node2->id = 2;
        $node2->buildingName = "33";
        $node2->printerName = "E";
        $node2->latitude = -20;
        $node2->longitude = 70;
        $nodeDAO->create($node2);
        
        $this->assertEquals(array($node1, $node2), $optimalPathModel->getTodaysNodes());
        $nodeDAO->delete($node1);
        $nodeDAO->delete($node2);
    }
    
    /**
    *   Tests that the correct array of Nodes are returned when a bad date is given
    *   
    *   @test
    */
    public function getsCorrectNodesForBadDate() {
        $_SESSION["currentDate"] = "2013--20-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $this->assertEquals(array(), $optimalPathModel->getTodaysNodes());
    }
    
    /**
    *   Tests that the correct array of Nodes are returned when the database is empty
    *   
    *   @test
    */
    public function getsCorrectNodesForEmptyDatabase() {
        $_SESSION["currentDate"] = "2013-09-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $this->assertEquals(array(), $optimalPathModel->getTodaysNodes());
        $this->assertEquals(array(), $optimalPathModel->getCachedResult());
    }
    
    /**
    *   Tests that the correct Edges are returned when the database is empty
    *   
    *   @test
    */
    public function getsWeightedEdgesForEmptyDatabase() {
        $_SESSION["currentDate"] = "2013-09-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $this->assertEquals(array(), $optimalPathModel->getWeightedEdges());
    }
    
    /**
    *   Tests that the correct Edges are returned
    *   
    *   @test
    */
    public function getsWeightedEdges() {
        $nodeDAO = new NodeDAO(true);
        $node1 = new Node();
        $node1->id = 1;
        $node1->buildingName = "48";
        $node1->printerName = "E";
        $node1->latitude = '-20';
        $node1->longitude = '70';
        
        $node2 = new Node();
        $node2->id = 2;
        $node2->buildingName = "48";
        $node2->printerName = "336";
        $node2->latitude = -23;
        $node2->longitude = 70;
        
        $node3 = new Node();
        $node3->id = 3;
        $node3->buildingName = "49";
        $node3->printerName = "E";
        $node3->latitude = '-26';
        $node3->longitude = '71';
        
        $optimalPathModel = new OptimalPathModel(true);
        
        
        
        $nd13 = new NodeDistance();
        $nd13->startNode = $node1->id;
        $nd13->endNode = $node3->id;
        $nd13->startNodeName = "48-E";
        $nd13->endNodeName = "49-E";
        $nd13->distanceTime = 1.0;
        $nd13->distanceMeters = 3.0;
        
        
        $nd31 = new NodeDistance();
        $nd31->startNode = $node3->id;
        $nd31->endNode = $node1->id;
        $nd31->startNodeName = "49-E";
        $nd31->endNodeName = "48-E";
        $nd31->distanceTime = 1.0;
        $nd31->distanceMeters = 3.0;
        
        $node1->linkedTo[] = $nd31;
        $node3->linkedTo[] = $nd31;
        
        $this->assertTrue($nodeDAO->create($node1));
        $this->assertTrue($nodeDAO->create($node2));
        $this->assertTrue($nodeDAO->create($node3));
        $node1->linkedTo[] = $nd13;
        $node3->linkedTo[] = $nd13;
        
        
        $todaysNodes =  $optimalPathModel->getTodaysNodes();
        $this->assertEquals(array($node1, $node3), $todaysNodes);
        $this->assertEquals(array('new Edge("49-E", "48-E", 3)', 'new Edge("48-E", "49-E", 3)', 'new Edge("49-E", "48-E", 3)', 'new Edge("48-E", "49-E", 3)'), $optimalPathModel->getWeightedEdges());
        

        $this->assertTrue($nodeDAO->delete($node1));
        $this->assertTrue($nodeDAO->delete($node2));
        $this->assertTrue($nodeDAO->delete($node3));
        
    }
    
    /**
    *   Tests that the correct Edges are returned for a bad date
    *   
    *   @test
    */
    public function getsWeightedEdgesForBadDate() {
        $_SESSION["currentDate"] = "2013--09-04 12:00:00";
        $optimalPathModel = new OptimalPathModel(true);
        $this->assertEquals(array(), $optimalPathModel->getWeightedEdges());
    }
}

?>