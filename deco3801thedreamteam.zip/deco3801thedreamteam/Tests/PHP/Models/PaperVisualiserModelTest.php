<?php
class PaperVisualiserModelTest extends PHPUnit_Framework_TestCase {
    
    /**
    *   Tests that the date is set correctly when instantiating the class
    *   
    *   @test
    */
    public function setsDateCorrectly() {
        $_SESSION["currentDate"] = "2013-04-04 23:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals("2013-04-04 23:00:00", $paperVisuliserModel->getDate());
        
    }
    
    /**
    *   Tests that the correct date is returned
    *   
    *   @test
    */
    public function returnsCorrectDate() {
        $_SESSION["currentDate"] = "2013-09-04 12:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals("2013-09-04 12:00:00", $paperVisuliserModel->getDate());
    }
    
    /**
    *   Tests that the correct array of printers are returned
    *   
    *   @test
    */
    public function getsCorrectPrinters() {
        $_SESSION["currentDate"] = "2013-04-04 23:00:00";
        $printerDAO = new PrinterDAO(true);
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals(array(), $paperVisuliserModel->getTodaysPrinters());
        
        $printer1 = new Printer();
        $printer1->Printer = 605;
        $printer1->Location = "49-400";
        $printer1->Stamp = "2013-04-04 12:00:00";
        $this->assertTrue($printerDAO->create($printer1));
        
        $this->assertEquals(array(0 => $printer1), $paperVisuliserModel->getTodaysPrinters());
        
        $printer2 = new Printer();
        $printer2->Printer = 25;
        $printer2->Location = "49-400";
        $printer2->Stamp = "2013-04-02 23:00:00";
        $this->assertTrue($printerDAO->create($printer2));
        
        $this->assertEquals(array(0 => $printer1), $paperVisuliserModel->getTodaysPrinters());
        
        $printer3 = new Printer();
        $printer3->Printer = 30;
        $printer3->Location = "49-400";
        $printer3->Stamp = "2013-04-04 16:00:00";
        $this->assertTrue($printerDAO->create($printer3));
        
        
        $this->assertEquals(array(1 => $printer1, 0 => $printer3), $paperVisuliserModel->getTodaysPrinters());
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
        $this->assertTrue($printerDAO->delete($printer3));
    }
    
    /**
    *   Tests that the correct array of printers are returned when a bad date is given
    *   
    *   @test
    */
    public function getsCorrectPrintersForBadDate() {
        $_SESSION["currentDate"] = "2013-17-04 26:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals(array(), $paperVisuliserModel->getTodaysPrinters());
    }
    
    

    
    /**
    *   Tests that the correct printers are returned
    *   
    *   @test
    */
    public function returnsCorrectPrinterIDs() {
        $_SESSION["currentDate"] = "2013-04-04 23:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $printerDAO = new PrinterDAO(true);
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals(array(), $paperVisuliserModel->getAllPrinterIDs());
        
        $printer1 = new Printer();
        $printer1->Printer = 605;
        $printer1->Location = "49-400";
        $printer1->Stamp = "2013-09-04 12:00:00";
        $this->assertTrue($printerDAO->create($printer1));
        
        $this->assertEquals(array(0 => 605), $paperVisuliserModel->getAllPrinterIDs());
        
        $printer2 = new Printer();
        $printer2->Printer = 25;
        $printer2->Location = "49-400";
        $printer2->Stamp = "2013-04-02 23:00:00";
        $this->assertTrue($printerDAO->create($printer2));
        
        $this->assertEquals(array(0 => 25, 1 => 605), $paperVisuliserModel->getAllPrinterIDs());
        
        $printer3 = new Printer();
        $printer3->Printer = 30;
        $printer3->Location = "49-400";
        $printer3->Stamp = "2013-04-04 16:00:00";
        $this->assertTrue($printerDAO->create($printer3));
        
        $this->assertEquals(array(0 => 25, 1 => 30, 2 => 605), $paperVisuliserModel->getAllPrinterIDs());
    
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
        $this->assertTrue($printerDAO->delete($printer3));
    }
    
    
    /**
    *   Tests that the correct printers are returned between two valid dates
    *   
    *   @test
    */
    public function getPrintersBetweenTwoValidDates() {
        $_SESSION["currentDate"] = "2013-04-04 23:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $printerDAO = new PrinterDAO(true);
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals(array(), $paperVisuliserModel->getPrintersUpToDate("2013-05-04 23:00:00", 25));
        
        $printer1 = new Printer();
        $printer1->Printer = 25;
        $printer1->Paper = 400;
        $printer1->Tray1 = 400;
        $printer1->Location = "49-400";
        $printer1->Stamp = "2013-04-06 12:00:00";
        $printer1->Status = "idle";
        $printer1->Uptime = 234234;
        $this->assertTrue($printerDAO->create($printer1));
        $printer1->Tray1 = null;
        $this->assertEquals(array(0 => $printer1), $paperVisuliserModel->getPrintersUpToDate("2013-05-04 23:00:00", 25));
        
        $printer2 = new Printer();
        $printer2->Printer = 30;
        $printer2->Paper = 50;
        $printer2->Location = "49-400";
        $printer2->Stamp = "2013-02-06 23:00:00";
        $printer2->Status = "idle";
        $this->assertTrue($printerDAO->create($printer2));
        
        $this->assertEquals(array(0 => $printer1), $paperVisuliserModel->getPrintersUpToDate("2013-05-04 23:00:00", 25));
        
        $printer3 = new Printer();
        $printer3->Printer = 25;
        $printer3->Location = "49-400";
        $printer3->Stamp = "2013-05-01 16:00:00";
        $printer3->Status = "idle";
        $this->assertTrue($printerDAO->create($printer3));
            
        $this->assertEquals(array(0 => $printer1, 1 => $printer3), $paperVisuliserModel->getPrintersUpToDate("2013-05-04 23:00:00", 25));
        
        
        $printer4 = new Printer();
        $printer4->Printer = 30;
        $printer4->Location = "49-400";
        $printer4->Stamp = "2013-05-01 16:00:00";
        $printer4->Status = "idle";
        $this->assertTrue($printerDAO->create($printer4));
            
        $this->assertEquals(array(0 => $printer4), $paperVisuliserModel->getPrintersUpToDate("2013-05-04 23:00:00", 30));
        
        $this->assertEquals('{"id": "25", "Location": "49-400", "Paper": "400", "PaperChange": "0", "Stamp": "2013-04-06 12:00:00", "Uptime": "234234", "Status": "idle"}', $printer1->toJSON());
        
        $this->assertTrue($printerDAO->delete($printer1));
        $this->assertTrue($printerDAO->delete($printer2));
        $this->assertTrue($printerDAO->delete($printer3));
        $this->assertTrue($printerDAO->delete($printer4));
        

        $this->assertEquals('{"id": "30", "Location": "49-400", "Paper": "50", "PaperChange": "-350", "Stamp": "2013-02-06 23:00:00", "Uptime": "", "Status": "idle"}', $printer2->toJSON($printer1));
        $this->assertEquals('{"id": "25", "Location": "49-400", "Paper": "", "PaperChange": "0", "Stamp": "2013-05-01 16:00:00", "Uptime": "", "Status": "idle"}', $printer3->toJSON());
        
    }
    
    /**
    *   Tests that the correct printers are returned between two invalid dates
    *   
    *   @test
    */
    public function getTodaysPrintersWithTrend() {
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $paperVisuliserModel->setDate("2013-09-04 12:00:00");
        $this->assertEquals(array(), $paperVisuliserModel->getTodaysPrintersWithTrend());
    }
    
    /**
    *   Tests that the correct printers are returned between two invalid dates
    *   
    *   @test
    */
    public function getTodaysPrintersWithTrendInvalidDates() {
        $paperVisuliserModel = new PaperVisualiserModel(true);
        $paperVisuliserModel->setDate("2014-25-01 00:00:00");
        $this->assertEquals(array(), $paperVisuliserModel->getTodaysPrintersWithTrend());
    }
    
    /**
    *   Tests that the correct printers are returned between two invalid dates
    *   
    *   @test
    */
    public function getPrintersBetweenTwoInvalidDates() {
        $paperVisuliserModel = new PaperVisualiserModel(true);
        $paperVisuliserModel->setDate("2013-09-04 12:00:00");
        $this->assertEquals(array(), $paperVisuliserModel->getPrintersUpToDate("2014-25-01 00:00:00", 8));
    }
    
    
    /**
    *   Tests that the result is cached properly
    *   
    *   @test
    */
    public function cachesProperly() {
        $_SESSION["currentDate"] = "2013-09-04 12:00:00";
        $paperVisuliserModel = new PaperVisualiserModel(true);
        
        $this->assertEquals(null, $paperVisuliserModel->getCachedResult());
    }
    
}

?>