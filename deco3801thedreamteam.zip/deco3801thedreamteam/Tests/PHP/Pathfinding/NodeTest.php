<?php
class NodeTest extends PHPUnit_Framework_TestCase {
    
    /**
    * Tests for the node class 
    */
	
	/**
	 * @test
	 */
    public function createNode_NoFields()
    {
		$newNode_Test = new Node();
		
		$this->assertNotNull($newNode_Test);
		$this->assertNotNull($newNode_Test->linkedTo);
		$this->assertEmpty($newNode_Test->linkedTo);
		
		return $newNode_Test;
    }
	
    /**
	 * @test
	 */
	public function createNode_Simple()
	{
		$simpleNode_Test = new Node();
		
		$simpleNode_Test->id = '45-104';
		$simpleNode_Test->buildingName = '45';
		$simpleNode_Test->printerName = '104';

		$this->assertNotNull($simpleNode_Test);
		$this->assertNotNull($simpleNode_Test->id);
		$this->assertNotNull($simpleNode_Test->buildingName);
		$this->assertNotNull($simpleNode_Test->printerName);
	
		return $simpleNode_Test;
	}
	
	/**
	 * @test
	 */
	public function createNode_Building() 
	{
		$buildingNode_Test = new Node();
		
		$buildingNode_Test->id = '45';
		$buildingNode_Test->buildingName = '45';
		$buildingNode_Test->printerName = 'E';
        
        $buildingNode_Test->latitude = -27.0505;
        $buildingNode_Test->longitude = 150.34534;

		$this->assertNotNull($buildingNode_Test);
		$this->assertNotNull($buildingNode_Test->id);
		$this->assertNotNull($buildingNode_Test->buildingName);
		$this->assertNotNull($buildingNode_Test->printerName);
		
		return $buildingNode_Test;
	}

	/**
	 * @test
     * @depends createNode_Simple
     */
    public function addSingleLink(Node $simpleNode_Test)
    {
		// Ignore that NodeDistance is empty for now
		$simpleNodeDistance_Test = new NodeDistance();
		// Create the link and then check that it is valid
		$simpleNode_Test->addLink($simpleNodeDistance_Test);
		
		$this->assertNotEmpty($simpleNode_Test->linkedTo);
    }

	/**
	 * @test
     * @depends createNode_Simple
     */
	public function addManyLinks(Node $simpleNode_Test)
    {
        // Ignore that NodeDistance is empty for now
		$simpleNodeDistanceOne_Test = new NodeDistance();
		$simpleNodeDistanceTwo_Test = new NodeDistance();
		$simpleNodeDistanceThree_Test = new NodeDistance();
		
		$links = array(
			0 => $simpleNodeDistanceOne_Test, 
			1 => $simpleNodeDistanceTwo_Test,
			2 => $simpleNodeDistanceThree_Test);
		
		// Create the link and then check that it is valid
		$simpleNode_Test->addLinks($links);
		
		$this->assertNotEmpty($simpleNode_Test->linkedTo);
		// NOTE: The size of linkedTo will be 3+1 as addSingleLink has already added 1
		$this->assertEquals(7, count($simpleNode_Test->linkedTo));
    }
	
    /**
    * Tests that the NodeDistance toString on an empty edge
    *
    * @depends createNode_Simple
    *  @test
    */
    public function NodeDistancetoString(Node $simpleNode_Test) {
        $simpleNodeDistanceOne_Test = new NodeDistance();
        $this->assertEquals('"", "", ', "" . $simpleNodeDistanceOne_Test);
    }
    
    /**
    * Tests that the NodeDistance toString on an empty edge
    *
    * @depends createNode_Simple
    *  @test
    */
    public function NodeDistancetoEdge(Node $simpleNode_Test) {
        $simpleNodeDistanceOne_Test = new NodeDistance();
        $this->assertEquals('new Edge("", "", )', $simpleNodeDistanceOne_Test->toEdge());
    }
	/**
	 * @test
     * @depends createNode_Building
     */
	public function isBuildingTrue(Node $buildingNode_Test)
	{
		$this->assertTrue($buildingNode_Test->isBuilding());
	}
	
	/**
	 * @test
	 * @depends createNode_Simple
	 */
	public function isBuildingFalse(Node $simpleNode_Test) 
	{
		$this->assertFalse($simpleNode_Test->isBuilding());
	}
	
	/**
	 * @test
     * @depends createNode_Simple
     */
	public function toString_Simple(Node $simpleNode_Test) 
	{
		$this->assertEquals("45-104", "" . $simpleNode_Test);
	}
	
	/**
	 * @test
     * @depends createNode_Building
     */
	public function toString_Building(Node $buildingNode_Test) 
	{
		$this->assertEquals("45-E", "" . $buildingNode_Test);
	}
	
	/**
	 * @test
	 * @depends createNode_NoFields
	 */
	public function toString_NoFields(Node $newNode_Test) 
	{
		$this->assertEquals("-", "" . $newNode_Test);
	}
    
    /**
    * Checks the toNode function correctly returns a JS object
    * 
    * @test
     * @depends createNode_Building
    */
    public function toNode_Building(Node $newNode_Test) {
        $this->assertEquals('"45-E": new Node("45-E", -27.0505, 150.34534)', $newNode_Test->toNode());
    }
    
    /**
    * Checks the toNode function correctly returns a JS object
    * 
    * @test
	 * @depends createNode_NoFields
    */
    public function toNode_NoFields(Node $newNode_Test) {
        $this->assertEquals('"-": new Node("-", , )', $newNode_Test->toNode());
    }
    
    /**
    * Checks the toJSON function correctly returns a JSON object
    * 
    * @test
     * @depends createNode_Building
    */
    public function toJSON_Building(Node $newNode_Test) {
        $this->assertEquals('"45-E": {"lat": -27.0505, "lng": 150.34534, "visited": false, "name": "45-E"}', $newNode_Test->toJSON());
    }
    
    /**
    * Checks the toJSON function correctly returns a JSON object
    * 
    * @test
	 * @depends createNode_NoFields
    */
    public function toJSON_NoFields(Node $newNode_Test) {
        $this->assertEquals('"-": {"lat": , "lng": , "visited": false, "name": "-"}', $newNode_Test->toJSON());
    }
}
?>