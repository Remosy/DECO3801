<?php
class NodeDistanceTest extends PHPUnit_Framework_TestCase {
    
    /**
    * Tests for the NodeDistance class
    */

	/**
	 * @test
	 */
    public function createNodeDistance_NoFields()
    {
		$newNodeDistance_Test = new NodeDistance();
		
		// Only a single not-null assert is required as there is no constructor
		$this->assertNotNull($newNodeDistance_Test);

		return $newNodeDistance_Test;
    }
	
    /**
	 * @test
	 */
	public function createNodeDistance_Simple()
	{
		$simpleNodeDistance_Test = new NodeDistance();
		
		$simpleNodeDistance_Test->startNode = 44;
		$simpleNodeDistance_Test->endNode = 45;
		$simpleNodeDistance_Test->distanceTime = 100;
		$simpleNodeDistance_Test->distanceMeters = 100;
		
		$this->assertNotNull($simpleNodeDistance_Test);
		$this->assertNotNull($simpleNodeDistance_Test->startNode);
		$this->assertNotNull($simpleNodeDistance_Test->endNode);
		$this->assertNotNull($simpleNodeDistance_Test->distanceTime);
		$this->assertNotNull($simpleNodeDistance_Test->distanceMeters);
		
		return $simpleNodeDistance_Test;
	}
	
	/**
	 * @test
	 * @depends createNodeDistance_Simple
	 */
	public function equalsTrueForwards(NodeDistance $simpleNodeDistance_Test) 
	{
		$simpleNodeDistanceTwo_Test = new NodeDistance();
		
		$simpleNodeDistanceTwo_Test->startNode = 44;
		$simpleNodeDistanceTwo_Test->endNode = 45;
		$simpleNodeDistanceTwo_Test->distanceTime = 100;
		$simpleNodeDistanceTwo_Test->distanceMeters = 100;
		
		$this->assertTrue($simpleNodeDistanceTwo_Test->equals($simpleNodeDistance_Test));
		$this->assertTrue($simpleNodeDistance_Test->equals($simpleNodeDistanceTwo_Test));
	}
	
	/**
	 * @test
	 * @depends createNodeDistance_Simple
	 */
	public function equalsTrueBackwards(NodeDistance $simpleNodeDistance_Test) 
	{
		$simpleNodeDistanceTwo_Test = new NodeDistance();
		
		$simpleNodeDistanceTwo_Test->startNode = 45;
		$simpleNodeDistanceTwo_Test->endNode = 44;
		$simpleNodeDistanceTwo_Test->distanceTime = 100;
		$simpleNodeDistanceTwo_Test->distanceMeters = 100;
		
		$this->assertTrue($simpleNodeDistanceTwo_Test->equals($simpleNodeDistance_Test));
		$this->assertTrue($simpleNodeDistance_Test->equals($simpleNodeDistanceTwo_Test));
	}
	
	/**
	 * @test
	 * @depends createNodeDistance_NoFields
	 * @depends createNodeDistance_Simple
	 */
	public function equalsFalse(NodeDistance $simpleNodeDistance_Test, 
								NodeDistance $newNodeDistance_Test)
	{
		$this->assertFalse($newNodeDistance_Test->equals($simpleNodeDistance_Test));
		$this->assertFalse($simpleNodeDistance_Test->equals($newNodeDistance_Test));
	}
	
	/**
	 * @test
	 * @depends createNodeDistance_Simple
	 */
	public function insideArrayTrue(NodeDistance $simpleNodeDistance_Test) 
	{
		$nodeDistanceList_Test = array();
		array_push($nodeDistanceList_Test, $simpleNodeDistance_Test);
		
		$this->assertTrue($simpleNodeDistance_Test->insideArray($nodeDistanceList_Test));
	}
	
	/**
	 * @test
	 * @depends createNodeDistance_Simple
	 */
	public function insideArrayFalse(NodeDistance $simpleNodeDistance_Test) 
	{
		$nodeDistanceList_Test = array();
		
		$this->assertFalse($simpleNodeDistance_Test->insideArray($nodeDistanceList_Test));
	}
}
?>