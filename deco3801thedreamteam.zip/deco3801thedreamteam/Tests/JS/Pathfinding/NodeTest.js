/**
*   Tests the Constructor
*/
QUnit.test("Constructor", function() {
    //QUnit.config.current.ignoreGlobalErrors = true;
    var node = new Node();
    assert.equal(node.id, undefined);
    assert.equal(node.lat, undefined);
    assert.equal(node.lng, undefined);
    
    node = new Node("48-E", 20, 40);
    assert.equal(node.id, "48-E");
    assert.equal(node.lat, 20);
    assert.equal(node.lng, 40);
});

/**
*   Tests the isBuilding method
*/
QUnit.test("indexIn", function() {
    
    var node = new Node("48-E", 20, 40);
    assert.equal(node.isBuilding(), true);
    
    node = new Node("22-S458", 20, 40);
    assert.equal(node.isBuilding(), false);
    
    node = new Node("48-S347E", 20, 40);
    assert.equal(node.isBuilding(), false);
});

/**
*   Tests the equals method
*/
QUnit.test("equals", function() {
    
    var node1 = new Node("48-E", 20, 40);
    var node2 = new Node("48-S34E", 20, 40);
    var node3 = new Node("34-CS2", 20, 40);
    var node4 = new Node("48-E", 56, 22);
    
    assert.equal(node1.equals(node4), true);
    assert.equal(node2.equals(node3), false);
    assert.equal(node4.equals(node4), true);
    assert.equal(node2.equals(node4), false);
    
    
});

/**
*   Tests the inArray method
*/
QUnit.test("inArray", function() {
    
    var node1 = new Node("48-E", 20, 40);
    var node2 = new Node("48-S34E", 20, 40);
    var node3 = new Node("34-CS2", 20, 40);
    var node4 = new Node("55-E", 56, 22);
    
    var nodes = [node1, node3, node4];
    var node5 = new Node("34-CS2", 20, 40);
    
    assert.equal(node5.inArray(nodes), true);
    assert.equal(node2.inArray(nodes), false);
});

/**
*   Tests the indexIn method
*/
QUnit.test("indexIn", function() {
    
    var node1 = new Node("48-E", 20, 40);
    var node2 = new Node("48-S34E", 20, 40);
    var node3 = new Node("34-CS2", 20, 40);
    var node4 = new Node("55-E", 56, 22);
    
    var nodes = [node1, node3, node4];
    var node5 = new Node("34-CS2", 20, 40);
    
    assert.equal(node5.indexIn(nodes) === 1, true);
    assert.equal(node2.indexIn(nodes) === -1, true);
});