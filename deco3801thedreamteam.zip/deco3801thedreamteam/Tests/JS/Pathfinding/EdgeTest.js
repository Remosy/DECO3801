/**
*   Tests the Constructor with id's
*/
QUnit.test("ConstructorID", function() {
    var edge = new Edge("49-E", "50-E", 2);
    
    assert.equal(edge.source.equals(new Node("49-E")), true);
    assert.equal(edge.destination.equals(new Node("50-E")), true);
    assert.equal(edge.distance, 2);
    
});

/**
*   Tests the Constructor with objects
*/
QUnit.test("ConstructorObjects", function() {

    var node1 = new Node("48-E", 20, 40);
    var node2 = new Node("50-E", 20, 40);
    
    var edge = new Edge(node1, node2, 3);
    assert.equal(edge.source.equals(new Node("48-E", 20, 40)), true);
    assert.equal(edge.destination.equals(new Node("50-E", 20, 40)), true);
    assert.equal(edge.distance, 3);
});

/**
*   Tests the indexIn method
*/
QUnit.test("indexIn", function() {
    var node1 = new Node("48-E", 10, 40);
    var node2 = new Node("50-E", 27, 11);
    var node3 = new Node("50-E", 26, 200);
    var node4 = new Node("50-E", 50, 46);
    
    var edge1 = new Edge(node1, node2, 3);
    assert.equal(edge1.source.equals(new Node("48-E", 20, 40)), true);
    assert.equal(edge1.destination.equals(new Node("50-E", 20, 40)), true);
    assert.equal(edge1.distance, 3);
    
    var edge2 = new Edge(node1, node3, 5);
    var edge3 = new Edge(node1, node4, 9);
    var edge4 = new Edge(node2, node3, 6);
    
    var edges = [edge1, edge2, edge4];
    
    assert.equal(edge2.indexIn(edges), 1);
    assert.equal(edge3.indexIn(edges), -1);
});