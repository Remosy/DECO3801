/* Some globals for the tests */
var nodes = {"43-E": new Node("43-E", -27.499333, 153.013413), "44-E": new Node("44-E", -27.499019, 153.013897), "45-E": new Node("45-E", -27.499607, 153.013892), "47-E": new Node("47-E", -27.500060, 153.014555), "49-E": new Node("49-E", -27.499607, 153.014690), "50-E": new Node("50-E", -27.500076, 153.013624), "51-E": new Node("51-E", -27.498947, 153.014532), "60-E": new Node("60-E", -27.499932, 153.012176), "74-E": new Node("74-E", -27.500272, 153.013891), "78-E": new Node("78-E", -27.500105, 153.014784)};
var weightedEdges = [new Edge("43-E", "44-E", 57),new Edge("44-E", "43-E", 57),new Edge("43-E", "45-E", 50),new Edge("45-E", "43-E", 50),new Edge("43-E", "47-E", 230),new Edge("47-E", "43-E", 230),new Edge("43-E", "49-E", 230),new Edge("49-E", "43-E", 230),new Edge("43-E", "50-E", 43),new Edge("50-E", "43-E", 43),new Edge("43-E", "51-E", 140),new Edge("51-E", "43-E", 140),new Edge("43-E", "60-E", 200),new Edge("60-E", "43-E", 200),new Edge("43-E", "74-E", 180),new Edge("74-E", "43-E", 180),new Edge("43-E", "78-E", 240),new Edge("78-E", "43-E", 240),new Edge("43-E", "44-E", 57),new Edge("44-E", "43-E", 57),new Edge("44-E", "45-E", 40),new Edge("45-E", "44-E", 40),new Edge("44-E", "47-E", 170),new Edge("47-E", "44-E", 170),new Edge("44-E", "49-E", 160),new Edge("49-E", "44-E", 160),new Edge("44-E", "50-E", 60),new Edge("50-E", "44-E", 60),new Edge("44-E", "51-E", 110),new Edge("51-E", "44-E", 110),new Edge("44-E", "60-E", 190),new Edge("60-E", "44-E", 190),new Edge("44-E", "74-E", 180),new Edge("74-E", "44-E", 180),new Edge("44-E", "78-E", 350),new Edge("78-E", "44-E", 350),new Edge("43-E", "45-E", 50),new Edge("45-E", "43-E", 50),new Edge("44-E", "45-E", 40),new Edge("45-E", "44-E", 40),new Edge("45-E", "47-E", 110),new Edge("47-E", "45-E", 110),new Edge("45-E", "49-E", 23),new Edge("49-E", "45-E", 23),new Edge("45-E", "50-E", 200),new Edge("50-E", "45-E", 200),new Edge("45-E", "51-E", 150),new Edge("51-E", "45-E", 150),new Edge("45-E", "60-E", 240),new Edge("60-E", "45-E", 240),new Edge("45-E", "74-E", 180),new Edge("74-E", "45-E", 180),new Edge("45-E", "78-E", 110),new Edge("78-E", "45-E", 110),new Edge("43-E", "47-E", 230),new Edge("47-E", "43-E", 230),new Edge("44-E", "47-E", 170),new Edge("47-E", "44-E", 170),new Edge("45-E", "47-E", 110),new Edge("47-E", "45-E", 110),new Edge("47-E", "49-E", 50),new Edge("49-E", "47-E", 50),new Edge("47-E", "50-E", 100),new Edge("50-E", "47-E", 100),new Edge("47-E", "51-E", 170),new Edge("51-E", "47-E", 170),new Edge("47-E", "60-E", 350),new Edge("60-E", "47-E", 350),new Edge("47-E", "74-E", 140),new Edge("74-E", "47-E", 140),new Edge("47-E", "78-E", 50),new Edge("78-E", "47-E", 50),new Edge("43-E", "49-E", 230),new Edge("49-E", "43-E", 230),new Edge("44-E", "49-E", 160),new Edge("49-E", "44-E", 160),new Edge("45-E", "49-E", 23),new Edge("49-E", "45-E", 23),new Edge("47-E", "49-E", 50),new Edge("49-E", "47-E", 50),new Edge("49-E", "50-E", 120),new Edge("50-E", "49-E", 120),new Edge("49-E", "51-E", 100),new Edge("51-E", "49-E", 100),new Edge("49-E", "60-E", 350),new Edge("60-E", "49-E", 350),new Edge("49-E", "74-E", 140),new Edge("74-E", "49-E", 140),new Edge("49-E", "78-E", 43),new Edge("78-E", "49-E", 43),new Edge("43-E", "50-E", 43),new Edge("50-E", "43-E", 43),new Edge("44-E", "50-E", 60),new Edge("50-E", "44-E", 60),new Edge("45-E", "50-E", 200),new Edge("50-E", "45-E", 200),new Edge("47-E", "50-E", 100),new Edge("50-E", "47-E", 100),new Edge("49-E", "50-E", 120),new Edge("50-E", "49-E", 120),new Edge("50-E", "51-E", 170),new Edge("51-E", "50-E", 170),new Edge("50-E", "60-E", 290),new Edge("60-E", "50-E", 290),new Edge("50-E", "74-E", 100),new Edge("74-E", "50-E", 100),new Edge("50-E", "78-E", 210),new Edge("78-E", "50-E", 210),new Edge("43-E", "51-E", 140),new Edge("51-E", "43-E", 140),new Edge("44-E", "51-E", 110),new Edge("51-E", "44-E", 110),new Edge("45-E", "51-E", 150),new Edge("51-E", "45-E", 150),new Edge("47-E", "51-E", 170),new Edge("51-E", "47-E", 170),new Edge("49-E", "51-E", 100),new Edge("51-E", "49-E", 100),new Edge("50-E", "51-E", 170),new Edge("51-E", "50-E", 170),new Edge("51-E", "60-E", 400),new Edge("60-E", "51-E", 400),new Edge("51-E", "74-E", 280),new Edge("74-E", "51-E", 280),new Edge("51-E", "78-E", 190),new Edge("78-E", "51-E", 190),new Edge("43-E", "60-E", 200),new Edge("60-E", "43-E", 200),new Edge("44-E", "60-E", 190),new Edge("60-E", "44-E", 190),new Edge("45-E", "60-E", 240),new Edge("60-E", "45-E", 240),new Edge("47-E", "60-E", 350),new Edge("60-E", "47-E", 350),new Edge("49-E", "60-E", 350),new Edge("60-E", "49-E", 350),new Edge("50-E", "60-E", 290),new Edge("60-E", "50-E", 290),new Edge("51-E", "60-E", 400),new Edge("60-E", "51-E", 400),new Edge("60-E", "74-E", 210),new Edge("74-E", "60-E", 210),new Edge("60-E", "78-E", 230),new Edge("78-E", "60-E", 230),new Edge("43-E", "74-E", 180),new Edge("74-E", "43-E", 180),new Edge("44-E", "74-E", 180),new Edge("74-E", "44-E", 180),new Edge("45-E", "74-E", 180),new Edge("74-E", "45-E", 180),new Edge("47-E", "74-E", 140),new Edge("74-E", "47-E", 140),new Edge("49-E", "74-E", 140),new Edge("74-E", "49-E", 140),new Edge("50-E", "74-E", 100),new Edge("74-E", "50-E", 100),new Edge("51-E", "74-E", 280),new Edge("74-E", "51-E", 280),new Edge("60-E", "74-E", 210),new Edge("74-E", "60-E", 210),new Edge("74-E", "78-E", 140),new Edge("78-E", "74-E", 140),new Edge("43-E", "78-E", 240),new Edge("78-E", "43-E", 240),new Edge("44-E", "78-E", 350),new Edge("78-E", "44-E", 350),new Edge("45-E", "78-E", 110),new Edge("78-E", "45-E", 110),new Edge("47-E", "78-E", 50),new Edge("78-E", "47-E", 50),new Edge("49-E", "78-E", 43),new Edge("78-E", "49-E", 43),new Edge("50-E", "78-E", 210),new Edge("78-E", "50-E", 210),new Edge("51-E", "78-E", 190),new Edge("78-E", "51-E", 190),new Edge("60-E", "78-E", 230),new Edge("78-E", "60-E", 230),new Edge("74-E", "78-E", 140),new Edge("78-E", "74-E", 140)];

    
/**
*   Tests the Constructor
*/
QUnit.test("ConstructorID", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    
    assert.equal(controller.nodes, nodes);
    assert.equal(controller.selectBox.value, "43-E");
    
});

/**
*   Tests the startOptimalPath method
*/
QUnit.test("startOptimalPath", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    
    assert.equal(controller.nodes, nodes);
    
});

/**
*   Tests the newSourceNode
*/
QUnit.test("newSourceNode", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    
    controller.markerArray = {"48-E": {setMap: function(){}}};
    controller.newSourceNode();
    assert.equal(controller.nodes, nodes);
});

/**
*   Tests the visiting of a node
*/
QUnit.test("visitNode", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    
    controller.markerArray = {"48-E": {setMap: function(){}}, "43-E": {setMap: function(){}}};
    controller.visitNode({data: function() { return "43-E"}});
    assert.equal(controller.nodes["43-E"].visited, true);
    
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    controller.markerArray = {};
    for(var i in nodes) {
        controller.markerArray[i] = {setMap: function() {}}
    }
    
    controller.visitNode({data: function() { return "60-E"}});
    assert.equal(controller.nodes["60-E"].visited, true);
    
    controller.visitNode({data: function() { return "44-E"}});
    assert.equal(controller.nodes["44-E"].visited, true);
    controller.visitNode({data: function() { return "43-E"}});
    assert.equal(controller.nodes["43-E"].visited, true);
    controller.visitNode({data: function() { return "45-E"}});
    assert.equal(controller.nodes["45-E"].visited, true);
    controller.visitNode({data: function() { return "47-E"}});
    assert.equal(controller.nodes["47-E"].visited, true);
    controller.visitNode({data: function() { return "49-E"}});
    assert.equal(controller.nodes["49-E"].visited, true);
    controller.visitNode({data: function() { return "50-E"}});
    assert.equal(controller.nodes["50-E"].visited, true);
    controller.visitNode({data: function() { return "51-E"}});
    assert.equal(controller.nodes["51-E"].visited, true);
    controller.visitNode({data: function() { return "74-E"}});
    assert.equal(controller.nodes["74-E"].visited, true);
    controller.visitNode({data: function() { return "78-E"}});
    assert.equal(controller.nodes["78-E"].visited, true);
    
});

/**
*   Tests the un-visiting of a node
*/
QUnit.test("undoVisit", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    controller.markerArray = {};
    for(var i in nodes) {
        controller.markerArray[i] = {setMap: function() {}}
    }
    
    controller.visitNode({data: function() { return "43-E"}});
    assert.equal(controller.nodes["43-E"].visited, true);
    controller.undoVisit({data: function() { return "43-E"}});
    assert.equal(controller.nodes["43-E"].visited, false);
    
    controller.visitNode({data: function() { return "60-E"}});
    assert.equal(controller.nodes["60-E"].visited, true);
    controller.undoVisit({data: function() { return "60-E"}});
    assert.equal(controller.nodes["60-E"].visited, false);
    

    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    controller.markerArray = {};
    for(var i in nodes) {
        controller.markerArray[i] = {setMap: function() {}}
    }

    controller.visitNode({data: function() { return controller.nextUnvisitedNode(0).id}});
    controller.undoVisit({data: function() { return controller.nextUnvisitedNode(0).id}});
    
});



/**
*   Tests the indexToNode method
*/
QUnit.test("indexToNode", function() {
    var controller = new OptimalPathFinder(nodes, weightedEdges, '');
    controller.startOptimalPath(controller.selectBox.value);
    controller.initMap();
    assert.equal(controller.indexToNode(500) == null, true);
    
});
