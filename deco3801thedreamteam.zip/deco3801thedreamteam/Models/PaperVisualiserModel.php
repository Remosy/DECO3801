<?php
class PaperVisualiserModel {
    
    private $printerDAO;
    private $date;
    private $lastSQLResult;
    
    public function __construct($debug = false) {
        date_default_timezone_set("Australia/Brisbane");
        $this->printerDAO = new PrinterDAO($debug);
        if(isset($_SESSION["currentDate"])) {
            $this->date = $_SESSION["currentDate"];
        } else {
            $this->date = "2000-01-01";
        }
    }
    
    /**
    * Returns an array of printers for the current internal date, or null on error.
    */
    public function getTodaysPrinters() {
        $this->lastSQLResult = $this->printerDAO->getPrintersForDay($this->date);
        return $this->lastSQLResult;
    }
    
    /**
    * Returns an array of printers with the last 3 days worth of data for the current internal date, or null on error.
    */
    public function getTodaysPrintersWithTrend() {
        $this->lastSQLResult = $this->printerDAO->getPrintersWithTrend($this->date);
        return $this->lastSQLResult;
    }
    
    /*
    *   Returns an array of printers between the current internal date and the $endDate for the given printer ID. Returns null on error.
    */
    public function getPrintersUpToDate($endDate, $printer) {
        $this->lastSQLResult = $this->printerDAO->fetchPrinterBetweenDates($this->date, $endDate, $printer);
        return $this->lastSQLResult;
    }
    /*
    *   Returns the current date of the Model. Defaults to todays date.
    */
    public function getDate() {
        return $this->date;
    }
    
    public function getAllPrinterIDs() {
        return $this->printerDAO->getAllPrinterIDs();
    }
    /*
    *   Sets the internal date to be $date
    */
    public function setDate($date) {
        $this->date = $date;
    }
    
    public function getCachedResult() {
        return $this->lastSQLResult;
    }
}
?>