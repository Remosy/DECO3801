<?php
class OptimalPathModel {
    
    private $printerDAO;
    private $nodeDAO;
    private $lastSQLResult;
    private $todaysNodes;
    
    
    public function __construct($debug = false) {
        $this->printerDAO = new PrinterDAO($debug);
        $this->nodeDAO = new NodeDAO($debug);
        if(isset($_SESSION["currentDate"])) {
            $this->date = $_SESSION["currentDate"];
        } else {
            $this->date = "2000-01-01";
        }
        
    }
    
    public function getTodaysNodes() {
        $this->lastSQLResult = $this->nodeDAO->getAllBuildings();
        $this->nodeDAO->linkNodes($this->lastSQLResult);
        $this->todaysNodes = $this->lastSQLResult;
        return $this->lastSQLResult;
    }
    
    
    /*
    *   Returns a a reflective array of weighted edges of the form [[startNode, endNode, distance], [startNode, endNode, distance], etc. ]
    *
    */
    public function getWeightedEdges() {
        $foundWeights = array();
        if(!isset($this->todaysNodes)) {
            $this->getTodaysNodes();
        }
        
        foreach($this->todaysNodes as $nodes) {
            foreach($nodes->linkedTo as $nodeDistance) {
                    $foundWeights[] = $nodeDistance->toEdge();
            }
        }
        
        return $foundWeights;
    }
    
    
    public function getCachedResult() {
        return $this->lastSQLResult;
    }
    
    /*
    *   Returns the current date of the Model. Defaults to todays date.
    */
    public function getDate() {
        return $this->date;
    }
    
    /*
    *   Sets the internal date to be $date
    */
    public function setDate($date) {
        $this->date = $date;
    }
}

?>